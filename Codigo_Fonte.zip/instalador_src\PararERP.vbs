Set WshShell = CreateObject("WScript.Shell")

' Kill the API
WshShell.Run "cmd /c taskkill /IM AutoPecas.API.exe /F > nul 2>&1", 0, True

MsgBox "O ERP Auto Peças foi encerrado com sucesso.", 64, "ERP Auto Peças"
