import { useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { Lock, User } from 'lucide-react';
import toast from 'react-hot-toast';

export default function Login() {
  const { login } = useAuth();
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!username || !password) return;
    
    setLoading(true);
    try {
      const response = await fetch('http://localhost:5000/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ login: username, senha: password })
      });
      
      const data = await response.json();
      
      if (response.ok) {
        toast.success(`Bem-vindo, ${data.user.nome}!`);
        login(data.token, data.user);
      } else {
        toast.error(data.message || 'Credenciais inválidas.');
      }
    } catch {
      toast.error('Erro de conexão ao tentar logar.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={{
      minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center',
      background: 'var(--bg-base)'
    }}>
      <div className="card" style={{ 
        maxWidth: '400px', width: '100%', padding: '48px', 
        display: 'flex', flexDirection: 'column', gap: '24px',
        boxShadow: 'var(--shadow-lg)'
      }}>
        <div style={{ textAlign: 'center', marginBottom: '8px' }}>
          <div style={{ 
            width: '56px', height: '56px', borderRadius: '16px', background: 'var(--primary-light)', 
            display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 16px'
          }}>
            <Lock size={28} color="var(--primary)" />
          </div>
          <h1 style={{ fontSize: '24px', fontWeight: 700, color: 'var(--text-primary)', marginBottom: '4px' }}>
            Acesso ao Sistema
          </h1>
          <p style={{ color: 'var(--text-muted)', fontSize: '14px' }}>
            Digite suas credenciais para continuar
          </p>
        </div>

        <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
          <div className="form-group">
            <label>Usuário</label>
            <div style={{ position: 'relative' }}>
              <User size={18} color="var(--text-muted)" style={{ position: 'absolute', left: '16px', top: '50%', transform: 'translateY(-50%)' }} />
              <input 
                type="text" 
                className="input-field" 
                placeholder="admin" 
                value={username} onChange={e => setUsername(e.target.value)}
                style={{ paddingLeft: '44px', width: '100%' }}
              />
            </div>
          </div>
          
          <div className="form-group">
            <label>Senha</label>
            <div style={{ position: 'relative' }}>
              <Lock size={18} color="var(--text-muted)" style={{ position: 'absolute', left: '16px', top: '50%', transform: 'translateY(-50%)' }} />
              <input 
                type="password" 
                className="input-field" 
                placeholder="••••••••" 
                value={password} onChange={e => setPassword(e.target.value)}
                style={{ paddingLeft: '44px', width: '100%' }}
              />
            </div>
          </div>

          <button 
            type="submit" 
            className="btn btn-primary" 
            style={{ padding: '14px', fontSize: '16px', marginTop: '12px' }}
            disabled={loading}
          >
            {loading ? 'Entrando...' : 'Entrar'}
          </button>
        </form>
      </div>
    </div>
  );
}
