using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
using AutoPecas.Domain.Entities;
using Microsoft.Extensions.Logging;

namespace AutoPecas.Fiscal.Services;

/// <summary>
/// Serviço responsável por carregar e gerenciar certificados digitais A1 (arquivo PFX)
/// e A3 (token USB / cartão via MS-CAPI / Windows Certificate Store).
///
/// IMPORTANTE PARA A3:
/// - O token USB deve estar conectado e com o driver instalado no Windows.
/// - O driver do token registra o certificado no Repositório do Windows (MS-CAPI).
/// - Este serviço acessa o certificado via X509Store, sem precisar de software adicional.
/// - O PIN do token é solicitado pelo driver no momento da assinatura (popup do Windows).
/// - Para suprimir o popup (serviço sem UI), o PIN pode ser pré-configurado no driver
///   do token (consulte a documentação do fabricante: SafeNet, eToken, etc.).
/// </summary>
public class CertificadoService
{
    private readonly ILogger<CertificadoService> _logger;

    public CertificadoService(ILogger<CertificadoService> logger)
    {
        _logger = logger;
    }

    // =========================================================
    //  CARREGAMENTO DO CERTIFICADO
    // =========================================================

    /// <summary>
    /// Carrega um certificado X509 a partir das configurações salvas no banco de dados.
    /// Suporta A1 (PFX em disco) e A3 (Windows Certificate Store via MS-CAPI).
    /// </summary>
    /// <param name="config">Registro do certificado no banco.</param>
    /// <param name="senhaPfxA1">
    ///   Senha do PFX para certificado A1. 
    ///   NUNCA salve a senha em texto no banco; forneça-a em tempo de execução.
    /// </param>
    /// <returns>Instância de X509Certificate2 pronta para assinar XML.</returns>
    public X509Certificate2 CarregarCertificado(CertificadoDigital config, string? senhaPfxA1 = null)
    {
        return config.Tipo switch
        {
            TipoCertificado.A1 => CarregarCertificadoA1(config, senhaPfxA1),
            TipoCertificado.A3 => CarregarCertificadoA3(config),
            _ => throw new InvalidOperationException($"Tipo de certificado desconhecido: {config.Tipo}")
        };
    }

    // =========================================================
    //  A1 — Arquivo PFX
    // =========================================================

    /// <summary>
    /// Carrega certificado A1 a partir de um arquivo .pfx no sistema de arquivos local.
    /// </summary>
    private X509Certificate2 CarregarCertificadoA1(CertificadoDigital config, string? senha)
    {
        if (string.IsNullOrWhiteSpace(config.CaminhoPfx))
            throw new InvalidOperationException("Caminho do arquivo PFX não configurado para o certificado A1.");

        if (!File.Exists(config.CaminhoPfx))
            throw new FileNotFoundException($"Arquivo de certificado A1 não encontrado: {config.CaminhoPfx}");

        if (string.IsNullOrWhiteSpace(senha))
            throw new ArgumentNullException(nameof(senha), "A senha do certificado A1 é obrigatória.");

        _logger.LogInformation("Carregando certificado A1 de: {Caminho}", config.CaminhoPfx);

        try
        {
            // X509KeyStorageFlags.Exportable: necessário para assinar com DFe.NET
            // X509KeyStorageFlags.MachineKeySet: garante acesso quando rodando como serviço
            // X509KeyStorageFlags.PersistKeySet: mantém a chave na memória durante a vida do objeto
            var cert = new X509Certificate2(
                config.CaminhoPfx,
                senha,
                X509KeyStorageFlags.Exportable |
                X509KeyStorageFlags.MachineKeySet |
                X509KeyStorageFlags.PersistKeySet
            );

            ValidarCertificado(cert);
            _logger.LogInformation("Certificado A1 carregado com sucesso. Subject: {Subject}, Válido até: {Validade}",
                cert.Subject, cert.NotAfter);

            return cert;
        }
        catch (CryptographicException ex)
        {
            _logger.LogError(ex, "Falha ao carregar certificado A1. Senha incorreta ou arquivo corrompido.");
            throw new InvalidOperationException("Não foi possível carregar o certificado A1. Verifique a senha e o arquivo PFX.", ex);
        }
    }

    // =========================================================
    //  A3 — Windows Certificate Store (MS-CAPI / Token USB)
    // =========================================================

    /// <summary>
    /// Carrega certificado A3 do repositório de certificados do Windows (MS-CAPI).
    /// O token USB/cartão deve estar conectado e o driver instalado.
    /// O certificado é identificado pelo Thumbprint salvo no banco.
    /// </summary>
    private X509Certificate2 CarregarCertificadoA3(CertificadoDigital config)
    {
        if (string.IsNullOrWhiteSpace(config.Thumbprint))
            throw new InvalidOperationException("Thumbprint não configurado para o certificado A3.");

        var storeLocation = ParseStoreLocation(config.StoreLocation ?? "CurrentUser");
        var storeName = ParseStoreName(config.StoreName ?? "My");

        _logger.LogInformation("Buscando certificado A3 no Windows Store. Location: {Location}, Store: {Store}, Thumbprint: {Thumbprint}",
            storeLocation, storeName, config.Thumbprint);

        using var store = new X509Store(storeName, storeLocation);
        store.Open(OpenFlags.ReadOnly | OpenFlags.OpenExistingOnly);

        // Busca pelo thumbprint — identificador único do certificado
        var thumbprint = config.Thumbprint.Replace(" ", "").ToUpperInvariant();
        var certs = store.Certificates.Find(
            X509FindType.FindByThumbprint,
            thumbprint,
            validOnly: false   // false = inclui expirados (para diagnóstico)
        );

        if (certs.Count == 0)
        {
            _logger.LogError("Certificado A3 não encontrado no Windows Store. Thumbprint: {Thumbprint}", thumbprint);
            throw new InvalidOperationException(
                $"Certificado A3 não encontrado no repositório Windows.\n" +
                $"Thumbprint: {thumbprint}\n" +
                $"Verifique se o token USB está conectado e o driver instalado."
            );
        }

        var cert = certs[0];
        ValidarCertificado(cert);

        // Verifica se a chave privada está acessível (token conectado)
        if (!cert.HasPrivateKey)
        {
            throw new InvalidOperationException(
                "O certificado A3 foi encontrado mas não possui chave privada acessível. " +
                "Verifique se o token USB está conectado."
            );
        }

        _logger.LogInformation("Certificado A3 carregado com sucesso. Subject: {Subject}, Válido até: {Validade}",
            cert.Subject, cert.NotAfter);

        return cert;
    }

    // =========================================================
    //  LISTAGEM DE CERTIFICADOS DISPONÍVEIS (A3)
    // =========================================================

    /// <summary>
    /// Lista todos os certificados com chave privada disponíveis no repositório Windows.
    /// Útil para que o usuário selecione qual certificado A3 usar na interface.
    /// </summary>
    public IEnumerable<CertificadoInfo> ListarCertificadosA3Disponiveis()
    {
        var resultado = new List<CertificadoInfo>();
        var locations = new[] { StoreLocation.CurrentUser, StoreLocation.LocalMachine };

        foreach (var location in locations)
        {
            try
            {
                using var store = new X509Store(StoreName.My, location);
                store.Open(OpenFlags.ReadOnly | OpenFlags.OpenExistingOnly);

                foreach (var cert in store.Certificates)
                {
                    // Filtra apenas certificados com chave privada (A3 ou A1 instalado)
                    if (!cert.HasPrivateKey) continue;

                    // Filtra por CNPJ no Subject (padrão ICP-Brasil)
                    // Certificados ICP-Brasil têm o CNPJ ou CPF no campo CN
                    var cnpj = ExtrairCnpjDoCertificado(cert);
                    if (cnpj == null) continue;

                    resultado.Add(new CertificadoInfo
                    {
                        Thumbprint = cert.Thumbprint,
                        Subject = cert.Subject,
                        EmitidoPor = cert.Issuer,
                        ValidoDe = cert.NotBefore,
                        ValidoAte = cert.NotAfter,
                        CnpjCpf = cnpj,
                        StoreLocation = location.ToString(),
                        StoreName = "My",
                        Expirado = cert.NotAfter < DateTime.Now,
                        DiasParaVencer = (int)(cert.NotAfter - DateTime.Now).TotalDays
                    });
                }
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "Não foi possível acessar o store {Location}", location);
            }
        }

        return resultado.OrderByDescending(c => c.ValidoAte);
    }

    // =========================================================
    //  VALIDAÇÃO DO CERTIFICADO
    // =========================================================

    /// <summary>
    /// Valida se o certificado está dentro do prazo de validade e emite alertas.
    /// </summary>
    private void ValidarCertificado(X509Certificate2 cert)
    {
        var agora = DateTime.Now;

        if (agora < cert.NotBefore)
            throw new InvalidOperationException($"O certificado ainda não é válido. Válido a partir de: {cert.NotBefore:dd/MM/yyyy}");

        if (agora > cert.NotAfter)
            throw new InvalidOperationException($"O certificado está EXPIRADO desde {cert.NotAfter:dd/MM/yyyy HH:mm}. Renove o certificado.");

        var diasParaVencer = (cert.NotAfter - agora).TotalDays;

        if (diasParaVencer <= 30)
            _logger.LogWarning("⚠️  ATENÇÃO: O certificado digital vence em {Dias} dias ({Data:dd/MM/yyyy})!",
                (int)diasParaVencer, cert.NotAfter);
    }

    /// <summary>
    /// Valida o certificado sem carregar do banco — útil para validação de upload de PFX.
    /// </summary>
    public CertificadoInfo ValidarArquivoPfx(byte[] pfxBytes, string senha)
    {
        X509Certificate2 cert;
        try
        {
            cert = new X509Certificate2(pfxBytes, senha,
                X509KeyStorageFlags.Exportable | X509KeyStorageFlags.EphemeralKeySet);
        }
        catch (CryptographicException ex)
        {
            throw new InvalidOperationException("Senha incorreta ou arquivo PFX inválido.", ex);
        }

        ValidarCertificado(cert);

        return new CertificadoInfo
        {
            Thumbprint = cert.Thumbprint,
            Subject = cert.Subject,
            EmitidoPor = cert.Issuer,
            ValidoDe = cert.NotBefore,
            ValidoAte = cert.NotAfter,
            CnpjCpf = ExtrairCnpjDoCertificado(cert) ?? string.Empty,
            DiasParaVencer = (int)(cert.NotAfter - DateTime.Now).TotalDays
        };
    }

    // =========================================================
    //  HELPERS
    // =========================================================

    /// <summary>
    /// Extrai o CNPJ ou CPF do Subject do certificado ICP-Brasil.
    /// Padrão: CN=NOME EMPRESA:12345678000199
    /// </summary>
    private static string? ExtrairCnpjDoCertificado(X509Certificate2 cert)
    {
        if (string.IsNullOrEmpty(cert.Subject)) return null;

        // ICP-Brasil embute CNPJ no Subject após dois-pontos no CN
        // Exemplo: CN=EMPRESA TESTE LTDA:12345678000199
        var partes = cert.Subject.Split(',');
        foreach (var parte in partes)
        {
            var kv = parte.Trim();
            if (!kv.StartsWith("CN=", StringComparison.OrdinalIgnoreCase)) continue;

            var valor = kv[3..]; // Remove "CN="
            var idx = valor.LastIndexOf(':');
            if (idx < 0) continue;

            var identificador = valor[(idx + 1)..].Trim();
            // CNPJ = 14 dígitos, CPF = 11 dígitos
            if (identificador.Length is 14 or 11 && identificador.All(char.IsDigit))
                return identificador;
        }
        return null;
    }

    private static StoreLocation ParseStoreLocation(string location) =>
        location.Equals("LocalMachine", StringComparison.OrdinalIgnoreCase)
            ? StoreLocation.LocalMachine
            : StoreLocation.CurrentUser;

    private static StoreName ParseStoreName(string name) =>
        name.Equals("My", StringComparison.OrdinalIgnoreCase)
            ? StoreName.My
            : Enum.Parse<StoreName>(name, ignoreCase: true);
}

/// <summary>
/// DTO com informações resumidas de um certificado digital.
/// </summary>
public record CertificadoInfo
{
    public string Thumbprint { get; init; } = string.Empty;
    public string Subject { get; init; } = string.Empty;
    public string EmitidoPor { get; init; } = string.Empty;
    public DateTime ValidoDe { get; init; }
    public DateTime ValidoAte { get; init; }
    public string CnpjCpf { get; init; } = string.Empty;
    public string? StoreLocation { get; init; }
    public string? StoreName { get; init; }
    public bool Expirado { get; init; }
    public int DiasParaVencer { get; init; }
}
