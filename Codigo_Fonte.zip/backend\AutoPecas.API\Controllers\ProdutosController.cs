using System.Globalization;
using System.Xml.Linq;
using AutoPecas.Domain.Entities;
using AutoPecas.Infrastructure.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace AutoPecas.API.Controllers;

/// <summary>
/// Controller de Produtos — módulo de Estoque.
/// Gerencia o cadastro de peças automotivas (linha leve e pesada).
/// </summary>
[ApiController]
[Route("api/[controller]")]
[Produces("application/json")]
public class ProdutosController : ControllerBase
{
    private readonly AutoPecasDbContext _db;
    private readonly ILogger<ProdutosController> _logger;

    public ProdutosController(AutoPecasDbContext db, ILogger<ProdutosController> logger)
    {
        _db = db;
        _logger = logger;
    }

    // =========================================================
    //  GET /api/produtos — Lista com filtros e paginação
    // =========================================================
    /// <summary>Retorna lista paginada de produtos com filtros opcionais.</summary>
    [HttpGet]
    [ProducesResponseType<PagedResult<ProdutoListDto>>(200)]
    public async Task<IActionResult> Listar(
        [FromQuery] string? busca = null,
        [FromQuery] Guid? categoriaId = null,
        [FromQuery] bool? ativo = true,
        [FromQuery] string? statusEstoque = null,   // SEM_ESTOQUE | ABAIXO_MINIMO | NORMAL
        [FromQuery] int pagina = 1,
        [FromQuery] int tamanhoPagina = 20)
    {
        tamanhoPagina = Math.Clamp(tamanhoPagina, 1, 100);
        pagina = Math.Max(1, pagina);

        var query = _db.Produtos
            .Include(p => p.Categoria)
            .Include(p => p.Saldos)
            .AsNoTracking();

        if (ativo.HasValue)
            query = query.Where(p => p.Ativo == ativo.Value);

        if (categoriaId.HasValue)
            query = query.Where(p => p.CategoriaId == categoriaId);

        if (!string.IsNullOrWhiteSpace(busca))
        {
            var termo = busca.ToLower();
            query = query.Where(p =>
                p.Descricao.ToLower().Contains(termo) ||
                p.Sku.ToLower().Contains(termo) ||
                (p.CodigoBarras != null && p.CodigoBarras.Contains(termo))
            );
        }

        var total = await query.CountAsync();

        var items = await query
            .OrderBy(p => p.Descricao)
            .Skip((pagina - 1) * tamanhoPagina)
            .Take(tamanhoPagina)
            .Select(p => new ProdutoListDto
            {
                Id = p.Id,
                Sku = p.Sku,
                CodigoBarras = p.CodigoBarras,
                Descricao = p.Descricao,
                Marca = p.Marca,
                Categoria = p.Categoria != null ? p.Categoria.Nome : null,
                PrecoVenda = p.PrecoVenda,
                PrecoCustoMedio = p.PrecoCustoMedio,
                EstoqueMinimo = p.EstoqueMinimo,
                QuantidadeTotal = p.Saldos.Sum(s => (decimal?)s.Quantidade) ?? 0,
                UnidadeMedida = p.UnidadeMedida ?? "PC",
                Ativo = p.Ativo
            })
            .ToListAsync();

        // Filtro por status de estoque (pós-query para simplicidade)
        if (!string.IsNullOrWhiteSpace(statusEstoque))
        {
            items = statusEstoque.ToUpper() switch
            {
                "SEM_ESTOQUE"   => items.Where(p => p.QuantidadeTotal <= 0).ToList(),
                "ABAIXO_MINIMO" => items.Where(p => p.QuantidadeTotal > 0 && p.QuantidadeTotal < p.EstoqueMinimo).ToList(),
                "NORMAL"        => items.Where(p => p.QuantidadeTotal >= p.EstoqueMinimo).ToList(),
                _ => items
            };
        }

        return Ok(new PagedResult<ProdutoListDto>
        {
            Items = items,
            Total = total,
            Pagina = pagina,
            TamanhoPagina = tamanhoPagina,
            TotalPaginas = (int)Math.Ceiling(total / (double)tamanhoPagina)
        });
    }

    // =========================================================
    //  GET /api/produtos/{id}
    // =========================================================
    /// <summary>Retorna detalhes completos de um produto, incluindo aplicações e códigos equivalentes.</summary>
    [HttpGet("{id:guid}")]
    [ProducesResponseType<ProdutoDetalheDto>(200)]
    [ProducesResponseType(404)]
    public async Task<IActionResult> ObterPorId(Guid id)
    {
        var produto = await _db.Produtos
            .Include(p => p.Categoria)
            .Include(p => p.CodigosEquivalentes)
            .Include(p => p.Aplicacoes).ThenInclude(a => a.Modelo).ThenInclude(m => m!.Marca)
            .Include(p => p.Saldos).ThenInclude(s => s.Localizacao)
            .AsNoTracking()
            .FirstOrDefaultAsync(p => p.Id == id);

        if (produto is null) return NotFound(new { mensagem = "Produto não encontrado." });

        return Ok(MapearDetalhe(produto));
    }

    // =========================================================
    //  GET /api/produtos/buscar-por-codigo?codigo=xxx
    // =========================================================
    /// <summary>
    /// Busca produto por SKU, código de barras ou código equivalente.
    /// Usado no PDV para leitura de código de barras.
    /// </summary>
    [HttpGet("buscar-por-codigo")]
    [ProducesResponseType<ProdutoListDto>(200)]
    [ProducesResponseType(404)]
    public async Task<IActionResult> BuscarPorCodigo([FromQuery] string codigo)
    {
        if (string.IsNullOrWhiteSpace(codigo))
            return BadRequest(new { mensagem = "Código não informado." });

        var produto = await _db.Produtos
            .Include(p => p.Saldos)
            .Include(p => p.CodigosEquivalentes)
            .AsNoTracking()
            .FirstOrDefaultAsync(p =>
                p.Sku == codigo ||
                p.CodigoBarras == codigo ||
                p.CodigosEquivalentes.Any(c => c.Codigo == codigo)
            );

        if (produto is null) return NotFound(new { mensagem = $"Produto com código '{codigo}' não encontrado." });

        return Ok(new ProdutoListDto
        {
            Id = produto.Id,
            Sku = produto.Sku,
            CodigoBarras = produto.CodigoBarras,
            Descricao = produto.Descricao,
            Marca = produto.Marca,
            PrecoVenda = produto.PrecoVenda,
            PrecoCustoMedio = produto.PrecoCustoMedio,
            EstoqueMinimo = produto.EstoqueMinimo,
            QuantidadeTotal = produto.Saldos.Sum(s => s.Quantidade),
            UnidadeMedida = produto.UnidadeMedida,
            Ativo = produto.Ativo
        });
    }

    // =========================================================
    //  POST /api/produtos
    // =========================================================
    /// <summary>Cria um novo produto no catálogo.</summary>
    [HttpPost]
    [ProducesResponseType<ProdutoDetalheDto>(201)]
    [ProducesResponseType(400)]
    public async Task<IActionResult> Criar([FromBody] CriarProdutoRequest request)
    {
        if (await _db.Produtos.AnyAsync(p => p.Sku == request.Sku))
            return BadRequest(new { mensagem = $"SKU '{request.Sku}' já está em uso." });

        var produto = new Produto
        {
            Sku = request.Sku.ToUpper().Trim(),
            CodigoBarras = request.CodigoBarras?.Trim(),
            Descricao = request.Descricao.Trim(),
            DescricaoComplementar = request.DescricaoComplementar,
            Marca = request.Marca?.Trim(),
            CategoriaId = request.CategoriaId,
            Ncm = request.Ncm?.Replace(".", "").Trim() ?? "87089990",
            Cest = request.Cest?.Replace(".", "-").Trim(),
            Origem = request.Origem,
            UnidadeMedida = request.UnidadeMedida?.ToUpper() ?? "PC",
            CstIcmsSn = request.CstIcmsSn ?? "400",
            TemSt = request.TemSt,
            MvaSt = request.MvaSt,
            PrecoCusto = request.PrecoCusto,
            PrecoCustoMedio = request.PrecoCusto,
            PrecoVenda = request.PrecoVenda,
            EstoqueMinimo = request.EstoqueMinimo,
            EstoqueMaximo = request.EstoqueMaximo,
            Ativo = true
        };

        // Calcula margem de lucro
        if (produto.PrecoCusto > 0 && produto.PrecoVenda > 0)
            produto.MargemLucro = Math.Round(
                (produto.PrecoVenda - produto.PrecoCusto) / produto.PrecoCusto * 100, 4);

        if (request.QuantidadeInicial > 0)
        {
            var loc = await _db.EstoqueLocalizacoes.FirstOrDefaultAsync(l => l.Ativo);
            if (loc != null)
            {
                produto.Saldos = new List<EstoqueSaldo>
                {
                    new EstoqueSaldo
                    {
                        LocalizacaoId = loc.Id,
                        Quantidade = request.QuantidadeInicial,
                        CustoMedio = produto.PrecoCustoMedio
                    }
                };
            }
        }

        _db.Produtos.Add(produto);
        await _db.SaveChangesAsync();

        _logger.LogInformation("Produto criado: {Sku} — {Descricao}", produto.Sku, produto.Descricao);
        return CreatedAtAction(nameof(ObterPorId), new { id = produto.Id }, MapearDetalhe(produto));
    }

    // =========================================================
    //  PUT /api/produtos/{id}
    // =========================================================
    /// <summary>Atualiza dados de um produto existente.</summary>
    [HttpPut("{id:guid}")]
    [ProducesResponseType<ProdutoDetalheDto>(200)]
    [ProducesResponseType(400)]
    [ProducesResponseType(404)]
    public async Task<IActionResult> Atualizar(Guid id, [FromBody] AtualizarProdutoRequest request)
    {
        var produto = await _db.Produtos.FindAsync(id);
        if (produto is null) return NotFound(new { mensagem = "Produto não encontrado." });

        if (await _db.Produtos.AnyAsync(p => p.Sku == request.Sku && p.Id != id))
            return BadRequest(new { mensagem = $"SKU '{request.Sku}' já está em uso por outro produto." });

        produto.Sku = request.Sku.ToUpper().Trim();
        produto.CodigoBarras = request.CodigoBarras?.Trim();
        produto.Descricao = request.Descricao.Trim();
        produto.DescricaoComplementar = request.DescricaoComplementar;
        produto.Marca = request.Marca?.Trim();
        produto.CategoriaId = request.CategoriaId;
        produto.Ncm = request.Ncm?.Replace(".", "").Trim() ?? produto.Ncm;
        produto.Cest = request.Cest?.Trim();
        produto.Origem = request.Origem;
        produto.UnidadeMedida = request.UnidadeMedida?.ToUpper() ?? produto.UnidadeMedida;
        produto.CstIcmsSn = request.CstIcmsSn ?? produto.CstIcmsSn;
        produto.TemSt = request.TemSt;
        produto.MvaSt = request.MvaSt;
        produto.PrecoCusto = request.PrecoCusto;
        produto.PrecoVenda = request.PrecoVenda;
        produto.EstoqueMinimo = request.EstoqueMinimo;
        produto.EstoqueMaximo = request.EstoqueMaximo;
        produto.AtualizadoEm = DateTime.UtcNow;

        if (produto.PrecoCusto > 0 && produto.PrecoVenda > 0)
            produto.MargemLucro = Math.Round(
                (produto.PrecoVenda - produto.PrecoCusto) / produto.PrecoCusto * 100, 4);

        await _db.SaveChangesAsync();
        return Ok(MapearDetalhe(produto));
    }

    // =========================================================
    //  DELETE /api/produtos/{id} — Soft delete
    // =========================================================
    /// <summary>Inativa um produto (soft delete — não exclui do banco).</summary>
    [HttpDelete("{id:guid}")]
    [ProducesResponseType(204)]
    [ProducesResponseType(404)]
    public async Task<IActionResult> Inativar(Guid id)
    {
        var produto = await _db.Produtos.FindAsync(id);
        if (produto is null) return NotFound(new { mensagem = "Produto não encontrado." });

        produto.Ativo = false;
        produto.AtualizadoEm = DateTime.UtcNow;
        await _db.SaveChangesAsync();

        return NoContent();
    }

    // =========================================================
    //  POST /api/produtos/importar-xml
    // =========================================================
    /// <summary>Lê um XML de NFe e importa os produtos.</summary>
    [HttpPost("importar-xml")]
    [ProducesResponseType(200)]
    [ProducesResponseType(400)]
    [ProducesResponseType(500)]
    public async Task<IActionResult> ImportarXml(IFormFile arquivo)
    {
        if (arquivo == null || arquivo.Length == 0)
            return BadRequest(new { mensagem = "Nenhum arquivo enviado." });

        if (!arquivo.FileName.EndsWith(".xml", StringComparison.OrdinalIgnoreCase))
            return BadRequest(new { mensagem = "O arquivo deve ser um XML." });

        try
        {
            using var stream = arquivo.OpenReadStream();
            var doc = XDocument.Load(stream);
            
            XNamespace ns = "http://www.portalfiscal.inf.br/nfe";
            var dets = doc.Descendants(ns + "det").ToList();
            
            if (!dets.Any())
                return BadRequest(new { mensagem = "Nenhum produto encontrado neste XML." });

            int importados = 0;
            int atualizados = 0;

            foreach (var det in dets)
            {
                var prod = det.Element(ns + "prod");
                if (prod == null) continue;

                var cProd = prod.Element(ns + "cProd")?.Value;
                var xProd = prod.Element(ns + "xProd")?.Value;
                var ncm = prod.Element(ns + "NCM")?.Value;
                var cest = prod.Element(ns + "CEST")?.Value;
                var uCom = prod.Element(ns + "uCom")?.Value;
                var qComStr = prod.Element(ns + "qCom")?.Value;
                var vUnComStr = prod.Element(ns + "vUnCom")?.Value;
                var cEAN = prod.Element(ns + "cEAN")?.Value;
                
                if (cEAN == "SEM GTIN") cEAN = null;

                if (string.IsNullOrWhiteSpace(cProd) || string.IsNullOrWhiteSpace(xProd))
                    continue;

                decimal.TryParse(qComStr, NumberStyles.Any, CultureInfo.InvariantCulture, out var qCom);
                decimal.TryParse(vUnComStr, NumberStyles.Any, CultureInfo.InvariantCulture, out var vUnCom);

                var produto = await _db.Produtos
                    .Include(p => p.Saldos)
                    .FirstOrDefaultAsync(p => p.Sku == cProd || (cEAN != null && p.CodigoBarras == cEAN));

                if (produto == null)
                {
                    produto = new Produto
                    {
                        Sku = cProd.ToUpper().Trim(),
                        CodigoBarras = cEAN,
                        Descricao = xProd.Trim(),
                        Ncm = ncm ?? "87089990",
                        Cest = cest,
                        UnidadeMedida = uCom?.ToUpper() ?? "UN",
                        PrecoCusto = vUnCom,
                        PrecoCustoMedio = vUnCom,
                        PrecoVenda = vUnCom * 1.5m,
                        Ativo = true,
                        Origem = 0,
                        CstIcmsSn = "400",
                        MargemLucro = 50
                    };
                    
                    var local = await _db.EstoqueLocalizacoes.FirstOrDefaultAsync();
                    if (local != null)
                    {
                        produto.Saldos.Add(new EstoqueSaldo 
                        { 
                            LocalizacaoId = local.Id, 
                            Quantidade = qCom, 
                            CustoMedio = vUnCom 
                        });
                    }

                    _db.Produtos.Add(produto);
                    importados++;
                }
                else
                {
                    produto.PrecoCusto = vUnCom;
                    produto.PrecoCustoMedio = vUnCom;
                    produto.AtualizadoEm = DateTime.UtcNow;
                    
                    var saldo = produto.Saldos.FirstOrDefault();
                    if (saldo != null)
                    {
                        saldo.Quantidade += qCom;
                        saldo.CustoMedio = vUnCom;
                    }
                    atualizados++;
                }
            }

            await _db.SaveChangesAsync();
            return Ok(new { mensagem = $"XML Processado! {importados} novos, {atualizados} atualizados." });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Erro ao importar XML");
            return StatusCode(500, new { mensagem = "Erro interno ao ler XML da NFe." });
        }
    }
    [HttpPost("importar-csv")]
    public async Task<IActionResult> ImportarCsv(IFormFile arquivo)
    {
        if (arquivo == null || arquivo.Length == 0)
            return BadRequest(new { mensagem = "Nenhum arquivo enviado." });

        try
        {
            var loc = await _db.EstoqueLocalizacoes.FirstOrDefaultAsync(l => l.Ativo);
            if (loc == null) return BadRequest(new { mensagem = "Nenhuma localização de estoque ativa." });

            using var reader = new StreamReader(arquivo.OpenReadStream());
            string? headerLine = await reader.ReadLineAsync();
            if (string.IsNullOrWhiteSpace(headerLine)) return BadRequest(new { mensagem = "Arquivo vazio." });

            var headers = headerLine.Split(';').Select(h => h.Trim()).ToList();
            int idxCodigo = headers.IndexOf("Código de Barras");
            int idxDescricao = headers.IndexOf("Descrição");
            int idxCusto = headers.IndexOf("Preço de Custo");
            int idxVenda = headers.IndexOf("Preço Venda Varejo");
            int idxEstoqueMin = headers.IndexOf("Estoque mínimo");
            int idxQtd = headers.IndexOf("Quantidade em Estoque");
            int idxNcm = headers.IndexOf("NCM");
            int idxCest = headers.IndexOf("CEST");
            int idxMarca = headers.IndexOf("Marca");

            if (idxDescricao < 0)
                return BadRequest(new { mensagem = "A coluna 'Descrição' é obrigatória no CSV." });

            int importados = 0;
            int atualizados = 0;

            while (!reader.EndOfStream)
            {
                var line = await reader.ReadLineAsync();
                if (string.IsNullOrWhiteSpace(line)) continue;

                var cols = line.Split(';');
                var descricao = cols.Length > idxDescricao ? cols[idxDescricao].Trim() : "";
                if (string.IsNullOrEmpty(descricao)) continue;

                var codBarras = idxCodigo >= 0 && cols.Length > idxCodigo ? cols[idxCodigo].Trim() : "";
                var sku = string.IsNullOrEmpty(codBarras) ? "CSV-" + Guid.NewGuid().ToString().Substring(0, 6).ToUpper() : codBarras;

                decimal.TryParse(idxCusto >= 0 && cols.Length > idxCusto ? cols[idxCusto].Replace(".", ",") : "0", out var pCusto);
                decimal.TryParse(idxVenda >= 0 && cols.Length > idxVenda ? cols[idxVenda].Replace(".", ",") : "0", out var pVenda);
                decimal.TryParse(idxEstoqueMin >= 0 && cols.Length > idxEstoqueMin ? cols[idxEstoqueMin].Replace(".", ",") : "0", out var estMin);
                decimal.TryParse(idxQtd >= 0 && cols.Length > idxQtd ? cols[idxQtd].Replace(".", ",") : "0", out var qtd);

                var ncm = idxNcm >= 0 && cols.Length > idxNcm ? cols[idxNcm].Trim() : "87089990";
                if (string.IsNullOrEmpty(ncm)) ncm = "87089990";
                var cest = idxCest >= 0 && cols.Length > idxCest ? cols[idxCest].Trim() : "";
                var marca = idxMarca >= 0 && cols.Length > idxMarca ? cols[idxMarca].Trim() : "";

                var produto = await _db.Produtos.Include(p => p.Saldos)
                    .FirstOrDefaultAsync(p => p.Sku == sku || (codBarras != "" && p.CodigoBarras == codBarras));

                if (produto == null)
                {
                    produto = new Produto
                    {
                        Sku = sku,
                        CodigoBarras = codBarras,
                        Descricao = descricao,
                        Marca = marca,
                        PrecoCusto = pCusto,
                        PrecoCustoMedio = pCusto,
                        PrecoVenda = pVenda,
                        EstoqueMinimo = estMin,
                        Ncm = ncm,
                        Cest = cest,
                        Origem = 0,
                        UnidadeMedida = "UN",
                        CstIcmsSn = "400",
                        Ativo = true,
                        Saldos = new List<EstoqueSaldo>()
                    };

                    if (qtd > 0)
                    {
                        produto.Saldos.Add(new EstoqueSaldo
                        {
                            LocalizacaoId = loc.Id,
                            Quantidade = qtd,
                            CustoMedio = pCusto
                        });
                    }

                    _db.Produtos.Add(produto);
                    importados++;
                }
                else
                {
                    produto.PrecoCusto = pCusto;
                    produto.PrecoVenda = pVenda > 0 ? pVenda : produto.PrecoVenda;
                    produto.Marca = !string.IsNullOrEmpty(marca) ? marca : produto.Marca;
                    produto.Ncm = !string.IsNullOrEmpty(ncm) ? ncm : produto.Ncm;
                    
                    var saldo = produto.Saldos.FirstOrDefault();
                    if (saldo != null)
                    {
                        saldo.Quantidade += qtd;
                        saldo.CustoMedio = pCusto > 0 ? pCusto : saldo.CustoMedio;
                    }
                    else if (qtd > 0)
                    {
                        produto.Saldos.Add(new EstoqueSaldo
                        {
                            LocalizacaoId = loc.Id,
                            Quantidade = qtd,
                            CustoMedio = pCusto
                        });
                    }

                    atualizados++;
                }
            }

            await _db.SaveChangesAsync();
            return Ok(new { mensagem = $"Planilha Processada! {importados} novos, {atualizados} atualizados." });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Erro ao importar CSV");
            return StatusCode(500, new { mensagem = "Erro interno ao ler a planilha." });
        }
    }

    // =========================================================
    //  Mapper privado
    // =========================================================
    private static ProdutoDetalheDto MapearDetalhe(Produto p) => new()
    {
        Id = p.Id,
        Sku = p.Sku,
        CodigoBarras = p.CodigoBarras,
        Descricao = p.Descricao,
        DescricaoComplementar = p.DescricaoComplementar,
        Marca = p.Marca,
        CategoriaId = p.CategoriaId,
        Ncm = p.Ncm,
        Cest = p.Cest,
        Origem = p.Origem,
        UnidadeMedida = p.UnidadeMedida,
        CstIcmsSn = p.CstIcmsSn,
        TemSt = p.TemSt,
        MvaSt = p.MvaSt,
        PrecoCusto = p.PrecoCusto,
        PrecoCustoMedio = p.PrecoCustoMedio,
        PrecoVenda = p.PrecoVenda,
        MargemLucro = p.MargemLucro,
        EstoqueMinimo = p.EstoqueMinimo,
        EstoqueMaximo = p.EstoqueMaximo,
        Ativo = p.Ativo,
        CriadoEm = p.CriadoEm,
        CodigosEquivalentes = p.CodigosEquivalentes.Select(c => new CodigoEquivalenteDto
        {
            Tipo = c.Tipo,
            Codigo = c.Codigo,
            Fabricante = c.Fabricante
        }).ToList(),
        Aplicacoes = p.Aplicacoes.Select(a => new AplicacaoDto
        {
            Marca = a.Modelo?.Marca?.Nome,
            Modelo = a.Modelo?.Nome,
            AnoInicio = a.AnoInicio,
            AnoFim = a.AnoFim,
            Motorizacao = a.Motorizacao
        }).ToList(),
        Saldos = p.Saldos.Select(s => new SaldoDto
        {
            Localizacao = s.Localizacao?.Codigo ?? "GERAL",
            Quantidade = s.Quantidade,
            CustoMedio = s.CustoMedio
        }).ToList()
    };
}

// =========================================================
//  DTOs
// =========================================================
public record ProdutoListDto
{
    public Guid Id { get; init; }
    public string Sku { get; init; } = string.Empty;
    public string? CodigoBarras { get; init; }
    public string Descricao { get; init; } = string.Empty;
    public string? Marca { get; init; }
    public string? Categoria { get; init; }
    public decimal PrecoVenda { get; init; }
    public decimal PrecoCustoMedio { get; init; }
    public decimal EstoqueMinimo { get; init; }
    public decimal QuantidadeTotal { get; init; }
    public string UnidadeMedida { get; init; } = "PC";
    public bool Ativo { get; init; }
    public string StatusEstoque => QuantidadeTotal <= 0 ? "SEM_ESTOQUE"
                                 : QuantidadeTotal < EstoqueMinimo ? "ABAIXO_MINIMO"
                                 : "NORMAL";
}

public record ProdutoDetalheDto : ProdutoListDto
{
    public string? DescricaoComplementar { get; init; }
    public Guid? CategoriaId { get; init; }
    public string Ncm { get; init; } = string.Empty;
    public string? Cest { get; init; }
    public int Origem { get; init; }
    public string CstIcmsSn { get; init; } = string.Empty;
    public bool TemSt { get; init; }
    public decimal? MvaSt { get; init; }
    public decimal PrecoCusto { get; init; }
    public decimal? MargemLucro { get; init; }
    public decimal EstoqueMaximo { get; init; }
    public DateTime CriadoEm { get; init; }
    public List<CodigoEquivalenteDto> CodigosEquivalentes { get; init; } = [];
    public List<AplicacaoDto> Aplicacoes { get; init; } = [];
    public List<SaldoDto> Saldos { get; init; } = [];
}

public record CodigoEquivalenteDto
{
    public string Tipo { get; init; } = string.Empty;
    public string Codigo { get; init; } = string.Empty;
    public string? Fabricante { get; init; }
}

public record AplicacaoDto
{
    public string? Marca { get; init; }
    public string? Modelo { get; init; }
    public short? AnoInicio { get; init; }
    public short? AnoFim { get; init; }
    public string? Motorizacao { get; init; }
}

public record SaldoDto
{
    public string Localizacao { get; init; } = string.Empty;
    public decimal Quantidade { get; init; }
    public decimal CustoMedio { get; init; }
}

public record PagedResult<T>
{
    public List<T> Items { get; init; } = [];
    public int Total { get; init; }
    public int Pagina { get; init; }
    public int TamanhoPagina { get; init; }
    public int TotalPaginas { get; init; }
}

public record CriarProdutoRequest
{
    public string Sku { get; init; } = string.Empty;
    public string? CodigoBarras { get; init; }
    public string Descricao { get; init; } = string.Empty;
    public string? DescricaoComplementar { get; init; }
    public string? Marca { get; init; }
    public Guid? CategoriaId { get; init; }
    public string? Ncm { get; init; }
    public string? Cest { get; init; }
    public int Origem { get; init; }
    public string? UnidadeMedida { get; init; }
    public string? CstIcmsSn { get; init; }
    public bool TemSt { get; init; }
    public decimal? MvaSt { get; init; }
    public decimal PrecoCusto { get; init; }
    public decimal PrecoVenda { get; init; }
    public decimal EstoqueMinimo { get; init; }
    public decimal EstoqueMaximo { get; init; }
    public decimal QuantidadeInicial { get; init; }
}

public record AtualizarProdutoRequest : CriarProdutoRequest;
