﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace AutoPecas.Infrastructure.Migrations
{
    /// <inheritdoc />
    public partial class InitialCreateSqlite : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.EnsureSchema(
                name: "financeiro");

            migrationBuilder.EnsureSchema(
                name: "estoque");

            migrationBuilder.EnsureSchema(
                name: "fiscal");

            migrationBuilder.EnsureSchema(
                name: "vendas");

            migrationBuilder.CreateTable(
                name: "caixas",
                schema: "financeiro",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "TEXT", nullable: false),
                    Nome = table.Column<string>(type: "TEXT", nullable: false),
                    Tipo = table.Column<string>(type: "TEXT", nullable: false),
                    Banco = table.Column<string>(type: "TEXT", nullable: true),
                    Agencia = table.Column<string>(type: "TEXT", nullable: true),
                    Conta = table.Column<string>(type: "TEXT", nullable: true),
                    SaldoInicial = table.Column<decimal>(type: "TEXT", nullable: false),
                    SaldoAtual = table.Column<decimal>(type: "TEXT", nullable: false),
                    Ativo = table.Column<bool>(type: "INTEGER", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_caixas", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "categorias",
                schema: "estoque",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "TEXT", nullable: false),
                    PaiId = table.Column<Guid>(type: "TEXT", nullable: true),
                    Nome = table.Column<string>(type: "TEXT", nullable: false),
                    Descricao = table.Column<string>(type: "TEXT", nullable: true),
                    Ativo = table.Column<bool>(type: "INTEGER", nullable: false),
                    CriadoEm = table.Column<DateTime>(type: "TEXT", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_categorias", x => x.Id);
                    table.ForeignKey(
                        name: "FK_categorias_categorias_PaiId",
                        column: x => x.PaiId,
                        principalSchema: "estoque",
                        principalTable: "categorias",
                        principalColumn: "Id");
                });

            migrationBuilder.CreateTable(
                name: "clientes",
                schema: "vendas",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "TEXT", nullable: false),
                    TipoPessoa = table.Column<char>(type: "TEXT", nullable: false),
                    NomeRazao = table.Column<string>(type: "TEXT", maxLength: 150, nullable: false),
                    NomeFantasia = table.Column<string>(type: "TEXT", nullable: true),
                    CpfCnpj = table.Column<string>(type: "TEXT", nullable: true),
                    RgIe = table.Column<string>(type: "TEXT", nullable: true),
                    Cep = table.Column<string>(type: "TEXT", nullable: true),
                    Logradouro = table.Column<string>(type: "TEXT", nullable: true),
                    Numero = table.Column<string>(type: "TEXT", nullable: true),
                    Complemento = table.Column<string>(type: "TEXT", nullable: true),
                    Bairro = table.Column<string>(type: "TEXT", nullable: true),
                    Municipio = table.Column<string>(type: "TEXT", nullable: true),
                    CodigoIbge = table.Column<string>(type: "TEXT", nullable: true),
                    Uf = table.Column<string>(type: "TEXT", nullable: false),
                    Telefone = table.Column<string>(type: "TEXT", nullable: true),
                    Celular = table.Column<string>(type: "TEXT", nullable: true),
                    Email = table.Column<string>(type: "TEXT", nullable: true),
                    LimiteCredito = table.Column<decimal>(type: "TEXT", nullable: false),
                    SaldoCredito = table.Column<decimal>(type: "TEXT", nullable: false),
                    ContribuinteIcms = table.Column<bool>(type: "INTEGER", nullable: false),
                    Ativo = table.Column<bool>(type: "INTEGER", nullable: false),
                    Observacao = table.Column<string>(type: "TEXT", nullable: true),
                    CriadoEm = table.Column<DateTime>(type: "TEXT", nullable: false),
                    AtualizadoEm = table.Column<DateTime>(type: "TEXT", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_clientes", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "empresas",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "TEXT", nullable: false),
                    RazaoSocial = table.Column<string>(type: "TEXT", maxLength: 150, nullable: false),
                    NomeFantasia = table.Column<string>(type: "TEXT", nullable: true),
                    Cnpj = table.Column<string>(type: "TEXT", maxLength: 14, nullable: false),
                    InscricaoEstadual = table.Column<string>(type: "TEXT", nullable: true),
                    InscricaoMunicipal = table.Column<string>(type: "TEXT", nullable: true),
                    Cep = table.Column<string>(type: "TEXT", nullable: false),
                    Logradouro = table.Column<string>(type: "TEXT", nullable: false),
                    Numero = table.Column<string>(type: "TEXT", nullable: false),
                    Complemento = table.Column<string>(type: "TEXT", nullable: true),
                    Bairro = table.Column<string>(type: "TEXT", nullable: false),
                    Municipio = table.Column<string>(type: "TEXT", nullable: false),
                    CodigoIbge = table.Column<string>(type: "TEXT", nullable: true),
                    Uf = table.Column<string>(type: "TEXT", maxLength: 2, nullable: false, defaultValue: "SP"),
                    Telefone = table.Column<string>(type: "TEXT", nullable: true),
                    Email = table.Column<string>(type: "TEXT", nullable: true),
                    RegimeTributario = table.Column<int>(type: "INTEGER", nullable: false),
                    CnaePrincipal = table.Column<string>(type: "TEXT", nullable: true),
                    Ativo = table.Column<bool>(type: "INTEGER", nullable: false),
                    CriadoEm = table.Column<DateTime>(type: "TEXT", nullable: false),
                    AtualizadoEm = table.Column<DateTime>(type: "TEXT", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_empresas", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "fornecedores",
                schema: "estoque",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "TEXT", nullable: false),
                    TipoPessoa = table.Column<char>(type: "TEXT", nullable: false),
                    RazaoSocial = table.Column<string>(type: "TEXT", nullable: false),
                    NomeFantasia = table.Column<string>(type: "TEXT", nullable: true),
                    CnpjCpf = table.Column<string>(type: "TEXT", nullable: false),
                    InscricaoEstadual = table.Column<string>(type: "TEXT", nullable: true),
                    Cep = table.Column<string>(type: "TEXT", nullable: true),
                    Logradouro = table.Column<string>(type: "TEXT", nullable: true),
                    Numero = table.Column<string>(type: "TEXT", nullable: true),
                    Complemento = table.Column<string>(type: "TEXT", nullable: true),
                    Bairro = table.Column<string>(type: "TEXT", nullable: true),
                    Municipio = table.Column<string>(type: "TEXT", nullable: true),
                    Uf = table.Column<string>(type: "TEXT", nullable: true),
                    Telefone = table.Column<string>(type: "TEXT", nullable: true),
                    Email = table.Column<string>(type: "TEXT", nullable: true),
                    Contato = table.Column<string>(type: "TEXT", nullable: true),
                    PrazoPagamentoDias = table.Column<int>(type: "INTEGER", nullable: false),
                    DescontoPadrao = table.Column<decimal>(type: "TEXT", nullable: false),
                    Ativo = table.Column<bool>(type: "INTEGER", nullable: false),
                    Observacao = table.Column<string>(type: "TEXT", nullable: true),
                    CriadoEm = table.Column<DateTime>(type: "TEXT", nullable: false),
                    AtualizadoEm = table.Column<DateTime>(type: "TEXT", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_fornecedores", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "localizacoes",
                schema: "estoque",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "TEXT", nullable: false),
                    Codigo = table.Column<string>(type: "TEXT", nullable: false),
                    Descricao = table.Column<string>(type: "TEXT", nullable: true),
                    Ativo = table.Column<bool>(type: "INTEGER", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_localizacoes", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "marcas_veiculo",
                schema: "estoque",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "TEXT", nullable: false),
                    Nome = table.Column<string>(type: "TEXT", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_marcas_veiculo", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "movimentos_caixa",
                schema: "financeiro",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "TEXT", nullable: false),
                    CaixaId = table.Column<Guid>(type: "TEXT", nullable: false),
                    Tipo = table.Column<char>(type: "TEXT", nullable: false),
                    Valor = table.Column<decimal>(type: "TEXT", nullable: false),
                    Descricao = table.Column<string>(type: "TEXT", nullable: false),
                    SaldoAnterior = table.Column<decimal>(type: "TEXT", nullable: false),
                    SaldoPosterior = table.Column<decimal>(type: "TEXT", nullable: false),
                    ContaReceberId = table.Column<Guid>(type: "TEXT", nullable: true),
                    ContaPagarId = table.Column<Guid>(type: "TEXT", nullable: true),
                    UsuarioId = table.Column<Guid>(type: "TEXT", nullable: true),
                    DataMovimento = table.Column<DateTime>(type: "TEXT", nullable: false),
                    CriadoEm = table.Column<DateTime>(type: "TEXT", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_movimentos_caixa", x => x.Id);
                    table.ForeignKey(
                        name: "FK_movimentos_caixa_caixas_CaixaId",
                        column: x => x.CaixaId,
                        principalSchema: "financeiro",
                        principalTable: "caixas",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "produtos",
                schema: "estoque",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "TEXT", nullable: false),
                    CategoriaId = table.Column<Guid>(type: "TEXT", nullable: true),
                    FornecedorPrincipalId = table.Column<Guid>(type: "TEXT", nullable: true),
                    Sku = table.Column<string>(type: "TEXT", maxLength: 50, nullable: false),
                    CodigoBarras = table.Column<string>(type: "TEXT", maxLength: 30, nullable: true),
                    Descricao = table.Column<string>(type: "TEXT", maxLength: 200, nullable: false),
                    DescricaoComplementar = table.Column<string>(type: "TEXT", nullable: true),
                    Marca = table.Column<string>(type: "TEXT", nullable: true),
                    Ncm = table.Column<string>(type: "TEXT", maxLength: 8, nullable: false, defaultValue: "87089990"),
                    Cest = table.Column<string>(type: "TEXT", nullable: true),
                    Origem = table.Column<int>(type: "INTEGER", nullable: false),
                    UnidadeMedida = table.Column<string>(type: "TEXT", maxLength: 6, nullable: false, defaultValue: "PC"),
                    CstIcmsSn = table.Column<string>(type: "TEXT", nullable: false),
                    AliquotaIcms = table.Column<decimal>(type: "TEXT", nullable: false),
                    CstIpi = table.Column<string>(type: "TEXT", nullable: false),
                    AliquotaIpi = table.Column<decimal>(type: "TEXT", nullable: false),
                    CstPis = table.Column<string>(type: "TEXT", nullable: false),
                    AliquotaPis = table.Column<decimal>(type: "TEXT", nullable: false),
                    CstCofins = table.Column<string>(type: "TEXT", nullable: false),
                    AliquotaCofins = table.Column<decimal>(type: "TEXT", nullable: false),
                    TemSt = table.Column<bool>(type: "INTEGER", nullable: false),
                    MvaSt = table.Column<decimal>(type: "TEXT", nullable: true),
                    PrecoCusto = table.Column<decimal>(type: "TEXT", precision: 12, scale: 4, nullable: false),
                    PrecoCustoMedio = table.Column<decimal>(type: "TEXT", precision: 12, scale: 4, nullable: false),
                    PrecoVenda = table.Column<decimal>(type: "TEXT", precision: 12, scale: 2, nullable: false),
                    MargemLucro = table.Column<decimal>(type: "TEXT", nullable: true),
                    EstoqueMinimo = table.Column<decimal>(type: "TEXT", precision: 10, scale: 3, nullable: false),
                    EstoqueMaximo = table.Column<decimal>(type: "TEXT", precision: 10, scale: 3, nullable: false),
                    PesoKg = table.Column<decimal>(type: "TEXT", nullable: true),
                    LarguraCm = table.Column<decimal>(type: "TEXT", nullable: true),
                    AlturaCm = table.Column<decimal>(type: "TEXT", nullable: true),
                    ComprimentoCm = table.Column<decimal>(type: "TEXT", nullable: true),
                    Ativo = table.Column<bool>(type: "INTEGER", nullable: false),
                    Observacao = table.Column<string>(type: "TEXT", nullable: true),
                    ImagemUrl = table.Column<string>(type: "TEXT", nullable: true),
                    CriadoEm = table.Column<DateTime>(type: "TEXT", nullable: false),
                    AtualizadoEm = table.Column<DateTime>(type: "TEXT", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_produtos", x => x.Id);
                    table.ForeignKey(
                        name: "FK_produtos_categorias_CategoriaId",
                        column: x => x.CategoriaId,
                        principalSchema: "estoque",
                        principalTable: "categorias",
                        principalColumn: "Id");
                });

            migrationBuilder.CreateTable(
                name: "contas_receber",
                schema: "financeiro",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "TEXT", nullable: false),
                    ClienteId = table.Column<Guid>(type: "TEXT", nullable: true),
                    PedidoId = table.Column<Guid>(type: "TEXT", nullable: true),
                    NotaFiscalId = table.Column<Guid>(type: "TEXT", nullable: true),
                    NumeroParcela = table.Column<short>(type: "INTEGER", nullable: false),
                    TotalParcelas = table.Column<short>(type: "INTEGER", nullable: false),
                    Descricao = table.Column<string>(type: "TEXT", nullable: false),
                    ValorOriginal = table.Column<decimal>(type: "TEXT", nullable: false),
                    ValorPago = table.Column<decimal>(type: "TEXT", nullable: false),
                    ValorDesconto = table.Column<decimal>(type: "TEXT", nullable: false),
                    ValorJuros = table.Column<decimal>(type: "TEXT", nullable: false),
                    ValorMulta = table.Column<decimal>(type: "TEXT", nullable: false),
                    DataEmissao = table.Column<DateOnly>(type: "TEXT", nullable: false),
                    DataVencimento = table.Column<DateOnly>(type: "TEXT", nullable: false),
                    DataPagamento = table.Column<DateOnly>(type: "TEXT", nullable: true),
                    Status = table.Column<string>(type: "TEXT", nullable: false),
                    FormaPagamento = table.Column<string>(type: "TEXT", nullable: true),
                    UsuarioId = table.Column<Guid>(type: "TEXT", nullable: true),
                    Observacao = table.Column<string>(type: "TEXT", nullable: true),
                    CriadoEm = table.Column<DateTime>(type: "TEXT", nullable: false),
                    AtualizadoEm = table.Column<DateTime>(type: "TEXT", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_contas_receber", x => x.Id);
                    table.ForeignKey(
                        name: "FK_contas_receber_clientes_ClienteId",
                        column: x => x.ClienteId,
                        principalSchema: "vendas",
                        principalTable: "clientes",
                        principalColumn: "Id");
                });

            migrationBuilder.CreateTable(
                name: "pedidos",
                schema: "vendas",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "TEXT", nullable: false),
                    Numero = table.Column<long>(type: "INTEGER", nullable: false),
                    Tipo = table.Column<string>(type: "TEXT", nullable: false),
                    Status = table.Column<string>(type: "TEXT", nullable: false),
                    ClienteId = table.Column<Guid>(type: "TEXT", nullable: false),
                    UsuarioId = table.Column<Guid>(type: "TEXT", nullable: true),
                    DataPedido = table.Column<DateTime>(type: "TEXT", nullable: false),
                    DataFaturamento = table.Column<DateTime>(type: "TEXT", nullable: true),
                    ValorProdutos = table.Column<decimal>(type: "TEXT", nullable: false),
                    ValorDesconto = table.Column<decimal>(type: "TEXT", nullable: false),
                    ValorAcrescimo = table.Column<decimal>(type: "TEXT", nullable: false),
                    ValorFrete = table.Column<decimal>(type: "TEXT", nullable: false),
                    ValorTotal = table.Column<decimal>(type: "TEXT", precision: 14, scale: 2, nullable: false),
                    NotaFiscalId = table.Column<Guid>(type: "TEXT", nullable: true),
                    Observacao = table.Column<string>(type: "TEXT", nullable: true),
                    ObservacaoFiscal = table.Column<string>(type: "TEXT", nullable: true),
                    CriadoEm = table.Column<DateTime>(type: "TEXT", nullable: false),
                    AtualizadoEm = table.Column<DateTime>(type: "TEXT", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_pedidos", x => x.Id);
                    table.ForeignKey(
                        name: "FK_pedidos_clientes_ClienteId",
                        column: x => x.ClienteId,
                        principalSchema: "vendas",
                        principalTable: "clientes",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "certificados_digitais",
                schema: "fiscal",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "TEXT", nullable: false),
                    EmpresaId = table.Column<Guid>(type: "TEXT", nullable: false),
                    Tipo = table.Column<string>(type: "TEXT", nullable: false),
                    Thumbprint = table.Column<string>(type: "TEXT", maxLength: 40, nullable: false),
                    Subject = table.Column<string>(type: "TEXT", nullable: true),
                    EmitidoPor = table.Column<string>(type: "TEXT", nullable: true),
                    ValidoDe = table.Column<DateTime>(type: "TEXT", nullable: false),
                    ValidoAte = table.Column<DateTime>(type: "TEXT", nullable: false),
                    CnpjCertificado = table.Column<string>(type: "TEXT", nullable: false),
                    CaminhoPfx = table.Column<string>(type: "TEXT", nullable: true),
                    SenhaPfxHash = table.Column<string>(type: "TEXT", nullable: true),
                    StoreLocation = table.Column<string>(type: "TEXT", nullable: true),
                    StoreName = table.Column<string>(type: "TEXT", nullable: true),
                    Ativo = table.Column<bool>(type: "INTEGER", nullable: false),
                    Padrao = table.Column<bool>(type: "INTEGER", nullable: false),
                    Observacao = table.Column<string>(type: "TEXT", nullable: true),
                    CriadoEm = table.Column<DateTime>(type: "TEXT", nullable: false),
                    AtualizadoEm = table.Column<DateTime>(type: "TEXT", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_certificados_digitais", x => x.Id);
                    table.ForeignKey(
                        name: "FK_certificados_digitais_empresas_EmpresaId",
                        column: x => x.EmpresaId,
                        principalTable: "empresas",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "notas_fiscais",
                schema: "fiscal",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "TEXT", nullable: false),
                    EmpresaId = table.Column<Guid>(type: "TEXT", nullable: false),
                    PedidoId = table.Column<Guid>(type: "TEXT", nullable: true),
                    ChaveAcesso = table.Column<string>(type: "TEXT", nullable: true),
                    Numero = table.Column<long>(type: "INTEGER", nullable: false),
                    Serie = table.Column<string>(type: "TEXT", nullable: false),
                    Modelo = table.Column<string>(type: "TEXT", nullable: false),
                    Status = table.Column<string>(type: "TEXT", nullable: false),
                    NaturezaOperacao = table.Column<string>(type: "TEXT", nullable: false),
                    TipoOperacao = table.Column<string>(type: "TEXT", nullable: false),
                    Finalidade = table.Column<int>(type: "INTEGER", nullable: false),
                    DataEmissao = table.Column<DateTime>(type: "TEXT", nullable: false),
                    DataSaidaEntrada = table.Column<DateTime>(type: "TEXT", nullable: true),
                    DestinatarioCpfCnpj = table.Column<string>(type: "TEXT", nullable: true),
                    DestinatarioNome = table.Column<string>(type: "TEXT", nullable: true),
                    DestinatarioUf = table.Column<string>(type: "TEXT", nullable: true),
                    ModalidadeFrete = table.Column<int>(type: "INTEGER", nullable: false),
                    ValorProdutos = table.Column<decimal>(type: "TEXT", nullable: false),
                    ValorFrete = table.Column<decimal>(type: "TEXT", nullable: false),
                    ValorDesconto = table.Column<decimal>(type: "TEXT", nullable: false),
                    ValorIpi = table.Column<decimal>(type: "TEXT", nullable: false),
                    ValorSt = table.Column<decimal>(type: "TEXT", nullable: false),
                    ValorPis = table.Column<decimal>(type: "TEXT", nullable: false),
                    ValorCofins = table.Column<decimal>(type: "TEXT", nullable: false),
                    ValorTotal = table.Column<decimal>(type: "TEXT", nullable: false),
                    ValorTributosAprox = table.Column<decimal>(type: "TEXT", nullable: false),
                    ProtocoloAutorizacao = table.Column<string>(type: "TEXT", nullable: true),
                    DataAutorizacao = table.Column<DateTime>(type: "TEXT", nullable: true),
                    CodigoRetornoSefaz = table.Column<string>(type: "TEXT", nullable: true),
                    MotivoRetornoSefaz = table.Column<string>(type: "TEXT", nullable: true),
                    Ambiente = table.Column<int>(type: "INTEGER", nullable: false),
                    XmlNfe = table.Column<string>(type: "TEXT", nullable: true),
                    XmlProtocolo = table.Column<string>(type: "TEXT", nullable: true),
                    UrlQrcode = table.Column<string>(type: "TEXT", nullable: true),
                    CertificadoId = table.Column<Guid>(type: "TEXT", nullable: true),
                    UsuarioId = table.Column<Guid>(type: "TEXT", nullable: true),
                    CriadoEm = table.Column<DateTime>(type: "TEXT", nullable: false),
                    AtualizadoEm = table.Column<DateTime>(type: "TEXT", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_notas_fiscais", x => x.Id);
                    table.ForeignKey(
                        name: "FK_notas_fiscais_empresas_EmpresaId",
                        column: x => x.EmpresaId,
                        principalTable: "empresas",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "contas_pagar",
                schema: "financeiro",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "TEXT", nullable: false),
                    FornecedorId = table.Column<Guid>(type: "TEXT", nullable: true),
                    CompraId = table.Column<Guid>(type: "TEXT", nullable: true),
                    NumeroParcela = table.Column<short>(type: "INTEGER", nullable: false),
                    TotalParcelas = table.Column<short>(type: "INTEGER", nullable: false),
                    Descricao = table.Column<string>(type: "TEXT", nullable: false),
                    NumeroDocumento = table.Column<string>(type: "TEXT", nullable: true),
                    ValorOriginal = table.Column<decimal>(type: "TEXT", nullable: false),
                    ValorPago = table.Column<decimal>(type: "TEXT", nullable: false),
                    ValorDesconto = table.Column<decimal>(type: "TEXT", nullable: false),
                    ValorJuros = table.Column<decimal>(type: "TEXT", nullable: false),
                    DataEmissao = table.Column<DateOnly>(type: "TEXT", nullable: false),
                    DataVencimento = table.Column<DateOnly>(type: "TEXT", nullable: false),
                    DataPagamento = table.Column<DateOnly>(type: "TEXT", nullable: true),
                    Status = table.Column<string>(type: "TEXT", nullable: false),
                    FormaPagamento = table.Column<string>(type: "TEXT", nullable: true),
                    UsuarioId = table.Column<Guid>(type: "TEXT", nullable: true),
                    Observacao = table.Column<string>(type: "TEXT", nullable: true),
                    CriadoEm = table.Column<DateTime>(type: "TEXT", nullable: false),
                    AtualizadoEm = table.Column<DateTime>(type: "TEXT", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_contas_pagar", x => x.Id);
                    table.ForeignKey(
                        name: "FK_contas_pagar_fornecedores_FornecedorId",
                        column: x => x.FornecedorId,
                        principalSchema: "estoque",
                        principalTable: "fornecedores",
                        principalColumn: "Id");
                });

            migrationBuilder.CreateTable(
                name: "modelos_veiculo",
                schema: "estoque",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "TEXT", nullable: false),
                    MarcaId = table.Column<Guid>(type: "TEXT", nullable: false),
                    Nome = table.Column<string>(type: "TEXT", nullable: false),
                    Tipo = table.Column<char>(type: "TEXT", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_modelos_veiculo", x => x.Id);
                    table.ForeignKey(
                        name: "FK_modelos_veiculo_marcas_veiculo_MarcaId",
                        column: x => x.MarcaId,
                        principalSchema: "estoque",
                        principalTable: "marcas_veiculo",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "produto_codigos_equivalentes",
                schema: "estoque",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "TEXT", nullable: false),
                    ProdutoId = table.Column<Guid>(type: "TEXT", nullable: false),
                    Tipo = table.Column<string>(type: "TEXT", nullable: false),
                    Codigo = table.Column<string>(type: "TEXT", nullable: false),
                    Fabricante = table.Column<string>(type: "TEXT", nullable: true),
                    Observacao = table.Column<string>(type: "TEXT", nullable: true),
                    CriadoEm = table.Column<DateTime>(type: "TEXT", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_produto_codigos_equivalentes", x => x.Id);
                    table.ForeignKey(
                        name: "FK_produto_codigos_equivalentes_produtos_ProdutoId",
                        column: x => x.ProdutoId,
                        principalSchema: "estoque",
                        principalTable: "produtos",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "saldos",
                schema: "estoque",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "TEXT", nullable: false),
                    ProdutoId = table.Column<Guid>(type: "TEXT", nullable: false),
                    LocalizacaoId = table.Column<Guid>(type: "TEXT", nullable: true),
                    Quantidade = table.Column<decimal>(type: "TEXT", precision: 12, scale: 3, nullable: false),
                    CustoMedio = table.Column<decimal>(type: "TEXT", precision: 12, scale: 4, nullable: false),
                    AtualizadoEm = table.Column<DateTime>(type: "TEXT", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_saldos", x => x.Id);
                    table.ForeignKey(
                        name: "FK_saldos_localizacoes_LocalizacaoId",
                        column: x => x.LocalizacaoId,
                        principalSchema: "estoque",
                        principalTable: "localizacoes",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_saldos_produtos_ProdutoId",
                        column: x => x.ProdutoId,
                        principalSchema: "estoque",
                        principalTable: "produtos",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "itens_pedido",
                schema: "vendas",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "TEXT", nullable: false),
                    PedidoId = table.Column<Guid>(type: "TEXT", nullable: false),
                    ProdutoId = table.Column<Guid>(type: "TEXT", nullable: false),
                    Sequencia = table.Column<short>(type: "INTEGER", nullable: false),
                    Descricao = table.Column<string>(type: "TEXT", nullable: false),
                    Ncm = table.Column<string>(type: "TEXT", nullable: false),
                    Cest = table.Column<string>(type: "TEXT", nullable: true),
                    UnidadeMedida = table.Column<string>(type: "TEXT", nullable: false),
                    Quantidade = table.Column<decimal>(type: "TEXT", nullable: false),
                    PrecoUnitario = table.Column<decimal>(type: "TEXT", nullable: false),
                    DescontoPercentual = table.Column<decimal>(type: "TEXT", nullable: false),
                    DescontoValor = table.Column<decimal>(type: "TEXT", nullable: false),
                    ValorTotal = table.Column<decimal>(type: "TEXT", nullable: false),
                    Csosn = table.Column<string>(type: "TEXT", nullable: true),
                    Cfop = table.Column<string>(type: "TEXT", nullable: true),
                    ValorSt = table.Column<decimal>(type: "TEXT", nullable: false),
                    ValorIpi = table.Column<decimal>(type: "TEXT", nullable: false),
                    ValorPis = table.Column<decimal>(type: "TEXT", nullable: false),
                    ValorCofins = table.Column<decimal>(type: "TEXT", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_itens_pedido", x => x.Id);
                    table.ForeignKey(
                        name: "FK_itens_pedido_pedidos_PedidoId",
                        column: x => x.PedidoId,
                        principalSchema: "vendas",
                        principalTable: "pedidos",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_itens_pedido_produtos_ProdutoId",
                        column: x => x.ProdutoId,
                        principalSchema: "estoque",
                        principalTable: "produtos",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "pagamentos_pedido",
                schema: "vendas",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "TEXT", nullable: false),
                    PedidoId = table.Column<Guid>(type: "TEXT", nullable: false),
                    FormaPagamento = table.Column<string>(type: "TEXT", nullable: false),
                    CodigoNfe = table.Column<string>(type: "TEXT", nullable: false),
                    Valor = table.Column<decimal>(type: "TEXT", nullable: false),
                    Parcelas = table.Column<short>(type: "INTEGER", nullable: false),
                    Nsu = table.Column<string>(type: "TEXT", nullable: true),
                    Autorizacao = table.Column<string>(type: "TEXT", nullable: true),
                    Bandeira = table.Column<string>(type: "TEXT", nullable: true),
                    DataVencimento = table.Column<DateTime>(type: "TEXT", nullable: true),
                    Status = table.Column<string>(type: "TEXT", nullable: false),
                    ConfirmadoEm = table.Column<DateTime>(type: "TEXT", nullable: true),
                    CriadoEm = table.Column<DateTime>(type: "TEXT", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_pagamentos_pedido", x => x.Id);
                    table.ForeignKey(
                        name: "FK_pagamentos_pedido_pedidos_PedidoId",
                        column: x => x.PedidoId,
                        principalSchema: "vendas",
                        principalTable: "pedidos",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "itens_nota_fiscal",
                schema: "fiscal",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "TEXT", nullable: false),
                    NotaFiscalId = table.Column<Guid>(type: "TEXT", nullable: false),
                    Sequencia = table.Column<short>(type: "INTEGER", nullable: false),
                    ProdutoId = table.Column<Guid>(type: "TEXT", nullable: true),
                    CodigoProduto = table.Column<string>(type: "TEXT", nullable: false),
                    Ean = table.Column<string>(type: "TEXT", nullable: true),
                    Descricao = table.Column<string>(type: "TEXT", nullable: false),
                    Ncm = table.Column<string>(type: "TEXT", nullable: false),
                    Cest = table.Column<string>(type: "TEXT", nullable: true),
                    Cfop = table.Column<string>(type: "TEXT", nullable: false),
                    UnidadeComercial = table.Column<string>(type: "TEXT", nullable: false),
                    Quantidade = table.Column<decimal>(type: "TEXT", nullable: false),
                    ValorUnitario = table.Column<decimal>(type: "TEXT", nullable: false),
                    ValorTotal = table.Column<decimal>(type: "TEXT", nullable: false),
                    Csosn = table.Column<string>(type: "TEXT", nullable: true),
                    Origem = table.Column<int>(type: "INTEGER", nullable: false),
                    CstIpi = table.Column<string>(type: "TEXT", nullable: true),
                    ValorIpi = table.Column<decimal>(type: "TEXT", nullable: false),
                    CstPis = table.Column<string>(type: "TEXT", nullable: true),
                    ValorPis = table.Column<decimal>(type: "TEXT", nullable: false),
                    CstCofins = table.Column<string>(type: "TEXT", nullable: true),
                    ValorCofins = table.Column<decimal>(type: "TEXT", nullable: false),
                    ValorSt = table.Column<decimal>(type: "TEXT", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_itens_nota_fiscal", x => x.Id);
                    table.ForeignKey(
                        name: "FK_itens_nota_fiscal_notas_fiscais_NotaFiscalId",
                        column: x => x.NotaFiscalId,
                        principalSchema: "fiscal",
                        principalTable: "notas_fiscais",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "produto_aplicacoes",
                schema: "estoque",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "TEXT", nullable: false),
                    ProdutoId = table.Column<Guid>(type: "TEXT", nullable: false),
                    ModeloId = table.Column<Guid>(type: "TEXT", nullable: false),
                    AnoInicio = table.Column<short>(type: "INTEGER", nullable: true),
                    AnoFim = table.Column<short>(type: "INTEGER", nullable: true),
                    Motorizacao = table.Column<string>(type: "TEXT", nullable: true),
                    Observacao = table.Column<string>(type: "TEXT", nullable: true),
                    CriadoEm = table.Column<DateTime>(type: "TEXT", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_produto_aplicacoes", x => x.Id);
                    table.ForeignKey(
                        name: "FK_produto_aplicacoes_modelos_veiculo_ModeloId",
                        column: x => x.ModeloId,
                        principalSchema: "estoque",
                        principalTable: "modelos_veiculo",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_produto_aplicacoes_produtos_ProdutoId",
                        column: x => x.ProdutoId,
                        principalSchema: "estoque",
                        principalTable: "produtos",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_caixas_Nome",
                schema: "financeiro",
                table: "caixas",
                column: "Nome",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_categorias_PaiId",
                schema: "estoque",
                table: "categorias",
                column: "PaiId");

            migrationBuilder.CreateIndex(
                name: "IX_certificados_digitais_EmpresaId_Thumbprint",
                schema: "fiscal",
                table: "certificados_digitais",
                columns: new[] { "EmpresaId", "Thumbprint" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_contas_pagar_FornecedorId",
                schema: "financeiro",
                table: "contas_pagar",
                column: "FornecedorId");

            migrationBuilder.CreateIndex(
                name: "IX_contas_receber_ClienteId",
                schema: "financeiro",
                table: "contas_receber",
                column: "ClienteId");

            migrationBuilder.CreateIndex(
                name: "IX_empresas_Cnpj",
                table: "empresas",
                column: "Cnpj",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_fornecedores_CnpjCpf",
                schema: "estoque",
                table: "fornecedores",
                column: "CnpjCpf",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_itens_nota_fiscal_NotaFiscalId",
                schema: "fiscal",
                table: "itens_nota_fiscal",
                column: "NotaFiscalId");

            migrationBuilder.CreateIndex(
                name: "IX_itens_pedido_PedidoId",
                schema: "vendas",
                table: "itens_pedido",
                column: "PedidoId");

            migrationBuilder.CreateIndex(
                name: "IX_itens_pedido_ProdutoId",
                schema: "vendas",
                table: "itens_pedido",
                column: "ProdutoId");

            migrationBuilder.CreateIndex(
                name: "IX_modelos_veiculo_MarcaId",
                schema: "estoque",
                table: "modelos_veiculo",
                column: "MarcaId");

            migrationBuilder.CreateIndex(
                name: "IX_movimentos_caixa_CaixaId",
                schema: "financeiro",
                table: "movimentos_caixa",
                column: "CaixaId");

            migrationBuilder.CreateIndex(
                name: "IX_notas_fiscais_EmpresaId",
                schema: "fiscal",
                table: "notas_fiscais",
                column: "EmpresaId");

            migrationBuilder.CreateIndex(
                name: "IX_pagamentos_pedido_PedidoId",
                schema: "vendas",
                table: "pagamentos_pedido",
                column: "PedidoId");

            migrationBuilder.CreateIndex(
                name: "IX_pedidos_ClienteId",
                schema: "vendas",
                table: "pedidos",
                column: "ClienteId");

            migrationBuilder.CreateIndex(
                name: "IX_produto_aplicacoes_ModeloId",
                schema: "estoque",
                table: "produto_aplicacoes",
                column: "ModeloId");

            migrationBuilder.CreateIndex(
                name: "IX_produto_aplicacoes_ProdutoId",
                schema: "estoque",
                table: "produto_aplicacoes",
                column: "ProdutoId");

            migrationBuilder.CreateIndex(
                name: "IX_produto_codigos_equivalentes_Codigo",
                schema: "estoque",
                table: "produto_codigos_equivalentes",
                column: "Codigo");

            migrationBuilder.CreateIndex(
                name: "IX_produto_codigos_equivalentes_ProdutoId_Tipo_Codigo",
                schema: "estoque",
                table: "produto_codigos_equivalentes",
                columns: new[] { "ProdutoId", "Tipo", "Codigo" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_produtos_CategoriaId",
                schema: "estoque",
                table: "produtos",
                column: "CategoriaId");

            migrationBuilder.CreateIndex(
                name: "IX_produtos_Sku",
                schema: "estoque",
                table: "produtos",
                column: "Sku",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_saldos_LocalizacaoId",
                schema: "estoque",
                table: "saldos",
                column: "LocalizacaoId");

            migrationBuilder.CreateIndex(
                name: "IX_saldos_ProdutoId_LocalizacaoId",
                schema: "estoque",
                table: "saldos",
                columns: new[] { "ProdutoId", "LocalizacaoId" },
                unique: true);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "certificados_digitais",
                schema: "fiscal");

            migrationBuilder.DropTable(
                name: "contas_pagar",
                schema: "financeiro");

            migrationBuilder.DropTable(
                name: "contas_receber",
                schema: "financeiro");

            migrationBuilder.DropTable(
                name: "itens_nota_fiscal",
                schema: "fiscal");

            migrationBuilder.DropTable(
                name: "itens_pedido",
                schema: "vendas");

            migrationBuilder.DropTable(
                name: "movimentos_caixa",
                schema: "financeiro");

            migrationBuilder.DropTable(
                name: "pagamentos_pedido",
                schema: "vendas");

            migrationBuilder.DropTable(
                name: "produto_aplicacoes",
                schema: "estoque");

            migrationBuilder.DropTable(
                name: "produto_codigos_equivalentes",
                schema: "estoque");

            migrationBuilder.DropTable(
                name: "saldos",
                schema: "estoque");

            migrationBuilder.DropTable(
                name: "fornecedores",
                schema: "estoque");

            migrationBuilder.DropTable(
                name: "notas_fiscais",
                schema: "fiscal");

            migrationBuilder.DropTable(
                name: "caixas",
                schema: "financeiro");

            migrationBuilder.DropTable(
                name: "pedidos",
                schema: "vendas");

            migrationBuilder.DropTable(
                name: "modelos_veiculo",
                schema: "estoque");

            migrationBuilder.DropTable(
                name: "localizacoes",
                schema: "estoque");

            migrationBuilder.DropTable(
                name: "produtos",
                schema: "estoque");

            migrationBuilder.DropTable(
                name: "empresas");

            migrationBuilder.DropTable(
                name: "clientes",
                schema: "vendas");

            migrationBuilder.DropTable(
                name: "marcas_veiculo",
                schema: "estoque");

            migrationBuilder.DropTable(
                name: "categorias",
                schema: "estoque");
        }
    }
}
