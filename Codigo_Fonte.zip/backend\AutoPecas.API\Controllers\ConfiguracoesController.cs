using AutoPecas.Domain.Entities;
using AutoPecas.Infrastructure.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace AutoPecas.API.Controllers;

[ApiController]
[Route("api/[controller]")]
public class ConfiguracoesController : ControllerBase
{
    private readonly AutoPecasDbContext _context;

    public ConfiguracoesController(AutoPecasDbContext context)
    {
        _context = context;
    }

    [HttpGet("empresa")]
    public async Task<IActionResult> GetEmpresa()
    {
        var empresa = await _context.Empresas.FirstOrDefaultAsync();
        if (empresa == null)
            return Ok(new Empresa());
        return Ok(empresa);
    }

    [HttpPost("empresa")]
    public async Task<IActionResult> SaveEmpresa([FromBody] Empresa dto)
    {
        var empresa = await _context.Empresas.FirstOrDefaultAsync();
        if (empresa == null)
        {
            dto.Id = Guid.NewGuid();
            _context.Empresas.Add(dto);
        }
        else
        {
            empresa.RazaoSocial = dto.RazaoSocial;
            empresa.NomeFantasia = dto.NomeFantasia;
            empresa.Cnpj = dto.Cnpj;
            empresa.InscricaoEstadual = dto.InscricaoEstadual;
            empresa.InscricaoMunicipal = dto.InscricaoMunicipal;
            empresa.Cep = dto.Cep;
            empresa.Logradouro = dto.Logradouro;
            empresa.Numero = dto.Numero;
            empresa.Complemento = dto.Complemento;
            empresa.Bairro = dto.Bairro;
            empresa.Municipio = dto.Municipio;
            empresa.Uf = dto.Uf;
            empresa.Telefone = dto.Telefone;
            empresa.Email = dto.Email;
            
            _context.Empresas.Update(empresa);
        }

        await _context.SaveChangesAsync();
        return Ok(empresa ?? dto);
    }
}
