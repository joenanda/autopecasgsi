namespace AutoPecas.Domain.Entities;

public class Cliente
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public char TipoPessoa { get; set; } = 'F';
    public string NomeRazao { get; set; } = string.Empty;
    public string? NomeFantasia { get; set; }
    public string? CpfCnpj { get; set; }
    public string? RgIe { get; set; }
    public string? Cep { get; set; }
    public string? Logradouro { get; set; }
    public string? Numero { get; set; }
    public string? Complemento { get; set; }
    public string? Bairro { get; set; }
    public string? Municipio { get; set; }
    public string? CodigoIbge { get; set; }
    public string Uf { get; set; } = "SP";
    public string? Telefone { get; set; }
    public string? Celular { get; set; }
    public string? Email { get; set; }
    public decimal LimiteCredito { get; set; }
    public decimal SaldoCredito { get; set; }
    public bool ContribuinteIcms { get; set; }
    public bool Ativo { get; set; } = true;
    public string? Observacao { get; set; }
    public DateTime CriadoEm { get; set; } = DateTime.UtcNow;
    public DateTime AtualizadoEm { get; set; } = DateTime.UtcNow;
}

public class Fornecedor
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public char TipoPessoa { get; set; } = 'J';
    public string RazaoSocial { get; set; } = string.Empty;
    public string? NomeFantasia { get; set; }
    public string CnpjCpf { get; set; } = string.Empty;
    public string? InscricaoEstadual { get; set; }
    public string? Cep { get; set; }
    public string? Logradouro { get; set; }
    public string? Numero { get; set; }
    public string? Complemento { get; set; }
    public string? Bairro { get; set; }
    public string? Municipio { get; set; }
    public string? Uf { get; set; }
    public string? Telefone { get; set; }
    public string? Email { get; set; }
    public string? Contato { get; set; }
    public int PrazoPagamentoDias { get; set; } = 30;
    public decimal DescontoPadrao { get; set; }
    public bool Ativo { get; set; } = true;
    public string? Observacao { get; set; }
    public DateTime CriadoEm { get; set; } = DateTime.UtcNow;
    public DateTime AtualizadoEm { get; set; } = DateTime.UtcNow;
}

public class PedidoVenda
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public long Numero { get; set; }
    public string Tipo { get; set; } = "PDV";
    public string Status { get; set; } = "ORCAMENTO";
    public Guid ClienteId { get; set; }
    public Guid? UsuarioId { get; set; }
    public DateTime DataPedido { get; set; } = DateTime.UtcNow;
    public DateTime? DataFaturamento { get; set; }
    public decimal ValorProdutos { get; set; }
    public decimal ValorDesconto { get; set; }
    public decimal ValorAcrescimo { get; set; }
    public decimal ValorFrete { get; set; }
    public decimal ValorTotal { get; set; }
    public Guid? NotaFiscalId { get; set; }
    public string? Observacao { get; set; }
    public string? ObservacaoFiscal { get; set; }
    public DateTime CriadoEm { get; set; } = DateTime.UtcNow;
    public DateTime AtualizadoEm { get; set; } = DateTime.UtcNow;
    public virtual Cliente? Cliente { get; set; }
    public virtual ICollection<ItemPedidoVenda> Itens { get; set; } = [];
    public virtual ICollection<PagamentoPedido> Pagamentos { get; set; } = [];
}

public class ItemPedidoVenda
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public Guid PedidoId { get; set; }
    public Guid ProdutoId { get; set; }
    public short Sequencia { get; set; }
    public string Descricao { get; set; } = string.Empty;
    public string Ncm { get; set; } = string.Empty;
    public string? Cest { get; set; }
    public string UnidadeMedida { get; set; } = "PC";
    public decimal Quantidade { get; set; }
    public decimal PrecoUnitario { get; set; }
    public decimal DescontoPercentual { get; set; }
    public decimal DescontoValor { get; set; }
    public decimal ValorTotal { get; set; }
    public string? Csosn { get; set; }
    public string? Cfop { get; set; }
    public decimal ValorSt { get; set; }
    public decimal ValorIpi { get; set; }
    public decimal ValorPis { get; set; }
    public decimal ValorCofins { get; set; }
    public virtual PedidoVenda? Pedido { get; set; }
    public virtual Produto? Produto { get; set; }
}

public class PagamentoPedido
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public Guid PedidoId { get; set; }
    public string FormaPagamento { get; set; } = string.Empty;
    public string CodigoNfe { get; set; } = "01";
    public decimal Valor { get; set; }
    public short Parcelas { get; set; } = 1;
    public string? Nsu { get; set; }
    public string? Autorizacao { get; set; }
    public string? Bandeira { get; set; }
    public DateTime? DataVencimento { get; set; }
    public string Status { get; set; } = "PENDENTE";
    public DateTime? ConfirmadoEm { get; set; }
    public DateTime CriadoEm { get; set; } = DateTime.UtcNow;
    public virtual PedidoVenda? Pedido { get; set; }
}

public class ContaReceber
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public Guid? ClienteId { get; set; }
    public Guid? PedidoId { get; set; }
    public Guid? NotaFiscalId { get; set; }
    public short NumeroParcela { get; set; } = 1;
    public short TotalParcelas { get; set; } = 1;
    public string Descricao { get; set; } = string.Empty;
    public decimal ValorOriginal { get; set; }
    public decimal ValorPago { get; set; }
    public decimal ValorDesconto { get; set; }
    public decimal ValorJuros { get; set; }
    public decimal ValorMulta { get; set; }
    public DateOnly DataEmissao { get; set; } = DateOnly.FromDateTime(DateTime.Today);
    public DateOnly DataVencimento { get; set; }
    public DateOnly? DataPagamento { get; set; }
    public string Status { get; set; } = "ABERTO";
    public string? FormaPagamento { get; set; }
    public Guid? UsuarioId { get; set; }
    public string? Observacao { get; set; }
    public DateTime CriadoEm { get; set; } = DateTime.UtcNow;
    public DateTime AtualizadoEm { get; set; } = DateTime.UtcNow;
    public virtual Cliente? Cliente { get; set; }
    public decimal Saldo => ValorOriginal - ValorPago + ValorJuros + ValorMulta - ValorDesconto;
}

public class ContaPagar
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public Guid? FornecedorId { get; set; }
    public Guid? CompraId { get; set; }
    public short NumeroParcela { get; set; } = 1;
    public short TotalParcelas { get; set; } = 1;
    public string Descricao { get; set; } = string.Empty;
    public string? NumeroDocumento { get; set; }
    public decimal ValorOriginal { get; set; }
    public decimal ValorPago { get; set; }
    public decimal ValorDesconto { get; set; }
    public decimal ValorJuros { get; set; }
    public DateOnly DataEmissao { get; set; } = DateOnly.FromDateTime(DateTime.Today);
    public DateOnly DataVencimento { get; set; }
    public DateOnly? DataPagamento { get; set; }
    public string Status { get; set; } = "ABERTO";
    public string? FormaPagamento { get; set; }
    public Guid? UsuarioId { get; set; }
    public string? Observacao { get; set; }
    public DateTime CriadoEm { get; set; } = DateTime.UtcNow;
    public DateTime AtualizadoEm { get; set; } = DateTime.UtcNow;
    public virtual Fornecedor? Fornecedor { get; set; }
    public decimal Saldo => ValorOriginal - ValorPago + ValorJuros - ValorDesconto;
}

public class Caixa
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public string Nome { get; set; } = string.Empty;
    public string Tipo { get; set; } = "CAIXA";
    public string? Banco { get; set; }
    public string? Agencia { get; set; }
    public string? Conta { get; set; }
    public decimal SaldoInicial { get; set; }
    public decimal SaldoAtual { get; set; }
    public bool Ativo { get; set; } = true;
}

public class MovimentoCaixa
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public Guid CaixaId { get; set; }
    public char Tipo { get; set; }
    public decimal Valor { get; set; }
    public string Descricao { get; set; } = string.Empty;
    public decimal SaldoAnterior { get; set; }
    public decimal SaldoPosterior { get; set; }
    public Guid? ContaReceberId { get; set; }
    public Guid? ContaPagarId { get; set; }
    public Guid? UsuarioId { get; set; }
    public DateTime DataMovimento { get; set; } = DateTime.UtcNow;
    public DateTime CriadoEm { get; set; } = DateTime.UtcNow;
    public virtual Caixa? Caixa { get; set; }
}

public class NotaFiscal
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public Guid EmpresaId { get; set; }
    public Guid? PedidoId { get; set; }
    public string? ChaveAcesso { get; set; }
    public long Numero { get; set; }
    public string Serie { get; set; } = "001";
    public string Modelo { get; set; } = "55";
    public string Status { get; set; } = "DIGITACAO";
    public string NaturezaOperacao { get; set; } = "VENDA DE MERCADORIA";
    public string TipoOperacao { get; set; } = "1";
    public int Finalidade { get; set; } = 1;
    public DateTime DataEmissao { get; set; } = DateTime.UtcNow;
    public DateTime? DataSaidaEntrada { get; set; }
    public string? DestinatarioCpfCnpj { get; set; }
    public string? DestinatarioNome { get; set; }
    public string? DestinatarioUf { get; set; }
    public int ModalidadeFrete { get; set; } = 9;
    public decimal ValorProdutos { get; set; }
    public decimal ValorFrete { get; set; }
    public decimal ValorDesconto { get; set; }
    public decimal ValorIpi { get; set; }
    public decimal ValorSt { get; set; }
    public decimal ValorPis { get; set; }
    public decimal ValorCofins { get; set; }
    public decimal ValorTotal { get; set; }
    public decimal ValorTributosAprox { get; set; }
    public string? ProtocoloAutorizacao { get; set; }
    public DateTime? DataAutorizacao { get; set; }
    public string? CodigoRetornoSefaz { get; set; }
    public string? MotivoRetornoSefaz { get; set; }
    public int Ambiente { get; set; } = 2;
    public string? XmlNfe { get; set; }
    public string? XmlProtocolo { get; set; }
    public string? UrlQrcode { get; set; }
    public Guid? CertificadoId { get; set; }
    public Guid? UsuarioId { get; set; }
    public DateTime CriadoEm { get; set; } = DateTime.UtcNow;
    public DateTime AtualizadoEm { get; set; } = DateTime.UtcNow;
    public virtual Empresa? Empresa { get; set; }
    public virtual ICollection<ItemNotaFiscal> Itens { get; set; } = [];
}

public class ItemNotaFiscal
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public Guid NotaFiscalId { get; set; }
    public short Sequencia { get; set; }
    public Guid? ProdutoId { get; set; }
    public string CodigoProduto { get; set; } = string.Empty;
    public string? Ean { get; set; }
    public string Descricao { get; set; } = string.Empty;
    public string Ncm { get; set; } = string.Empty;
    public string? Cest { get; set; }
    public string Cfop { get; set; } = "5102";
    public string UnidadeComercial { get; set; } = "PC";
    public decimal Quantidade { get; set; }
    public decimal ValorUnitario { get; set; }
    public decimal ValorTotal { get; set; }
    public string? Csosn { get; set; }
    public int Origem { get; set; }
    public string? CstIpi { get; set; }
    public decimal ValorIpi { get; set; }
    public string? CstPis { get; set; }
    public decimal ValorPis { get; set; }
    public string? CstCofins { get; set; }
    public decimal ValorCofins { get; set; }
    public decimal ValorSt { get; set; }
    public virtual NotaFiscal? NotaFiscal { get; set; }
}
