using AutoPecas.Domain.Entities;
using AutoPecas.Infrastructure.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace AutoPecas.API.Controllers;

[ApiController]
[Route("api/[controller]")]
[Produces("application/json")]
public class ClientesController : ControllerBase
{
    private readonly AutoPecasDbContext _db;
    public ClientesController(AutoPecasDbContext db) => _db = db;

    [HttpGet]
    public async Task<IActionResult> Listar(
        [FromQuery] string? busca, [FromQuery] int pagina = 1, [FromQuery] int tamanho = 20)
    {
        tamanho = Math.Clamp(tamanho, 1, 100);
        var q = _db.Set<Cliente>().AsNoTracking();

        if (!string.IsNullOrWhiteSpace(busca))
        {
            var t = busca.ToLower();
            q = q.Where(c => c.NomeRazao.ToLower().Contains(t) ||
                             (c.CpfCnpj != null && c.CpfCnpj.Contains(t)));
        }

        var total = await q.CountAsync();
        var items = await q.OrderBy(c => c.NomeRazao)
            .Skip((pagina - 1) * tamanho).Take(tamanho).ToListAsync();

        return Ok(new { items, total, pagina, tamanho });
    }

    [HttpGet("{id:guid}")]
    public async Task<IActionResult> ObterPorId(Guid id)
    {
        var c = await _db.Set<Cliente>().FindAsync(id);
        return c == null ? NotFound() : Ok(c);
    }

    [HttpPost]
    public async Task<IActionResult> Criar([FromBody] ClienteRequest req)
    {
        var c = new Cliente
        {
            TipoPessoa = req.TipoPessoa, NomeRazao = req.NomeRazao, NomeFantasia = req.NomeFantasia,
            CpfCnpj = req.CpfCnpj?.Replace(".", "").Replace("/", "").Replace("-", ""),
            RgIe = req.RgIe, Cep = req.Cep, Logradouro = req.Logradouro, Numero = req.Numero,
            Complemento = req.Complemento, Bairro = req.Bairro, Municipio = req.Municipio,
            CodigoIbge = req.CodigoIbge, Uf = req.Uf ?? "SP", Telefone = req.Telefone,
            Celular = req.Celular, Email = req.Email, LimiteCredito = req.LimiteCredito,
            ContribuinteIcms = req.ContribuinteIcms, Ativo = true
        };
        _db.Set<Cliente>().Add(c);
        await _db.SaveChangesAsync();
        return CreatedAtAction(nameof(ObterPorId), new { id = c.Id }, c);
    }

    [HttpPut("{id:guid}")]
    public async Task<IActionResult> Atualizar(Guid id, [FromBody] ClienteRequest req)
    {
        var c = await _db.Set<Cliente>().FindAsync(id);
        if (c == null) return NotFound();
        c.NomeRazao = req.NomeRazao; c.NomeFantasia = req.NomeFantasia;
        c.CpfCnpj = req.CpfCnpj?.Replace(".", "").Replace("/", "").Replace("-", "");
        c.Telefone = req.Telefone; c.Celular = req.Celular; c.Email = req.Email;
        c.Logradouro = req.Logradouro; c.Numero = req.Numero; c.Bairro = req.Bairro;
        c.Municipio = req.Municipio; c.Uf = req.Uf ?? c.Uf; c.Cep = req.Cep;
        c.LimiteCredito = req.LimiteCredito; c.ContribuinteIcms = req.ContribuinteIcms;
        c.AtualizadoEm = DateTime.UtcNow;
        await _db.SaveChangesAsync();
        return Ok(c);
    }

    [HttpDelete("{id:guid}")]
    public async Task<IActionResult> Inativar(Guid id)
    {
        var c = await _db.Set<Cliente>().FindAsync(id);
        if (c == null) return NotFound();
        c.Ativo = false; c.AtualizadoEm = DateTime.UtcNow;
        await _db.SaveChangesAsync();
        return NoContent();
    }
}

public record ClienteRequest
{
    public char TipoPessoa { get; init; } = 'F';
    public string NomeRazao { get; init; } = string.Empty;
    public string? NomeFantasia { get; init; }
    public string? CpfCnpj { get; init; }
    public string? RgIe { get; init; }
    public string? Cep { get; init; }
    public string? Logradouro { get; init; }
    public string? Numero { get; init; }
    public string? Complemento { get; init; }
    public string? Bairro { get; init; }
    public string? Municipio { get; init; }
    public string? CodigoIbge { get; init; }
    public string? Uf { get; init; }
    public string? Telefone { get; init; }
    public string? Celular { get; init; }
    public string? Email { get; init; }
    public decimal LimiteCredito { get; init; }
    public bool ContribuinteIcms { get; init; }
}
