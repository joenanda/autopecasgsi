import { useState, useRef } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Plus, Search, Edit, Package, X, Check, BookOpen, FileText } from 'lucide-react';
import toast from 'react-hot-toast';
import { produtosApi, categoriasApi } from '../services/api';

interface NcmItem { codigo: string; descricao: string; }

const fmtBRL = (v: number) => Number(v).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });

interface Produto {
  id: string; sku: string; codigoBarras?: string; descricao: string;
  marca?: string; categoria?: string; precoVenda: number; preciCustoMedio: number;
  quantidadeTotal: number; unidadeMedida: string; statusEstoque: string; ativo: boolean;
  ncm: string; cest?: string; cstIcmsSn: string; temSt: boolean; mvaSt?: number;
  precoCusto: number; estoqueMinimo: number; estoqueMaximo: number;
}

interface Categoria { id: string; nome: string; }

const statusBadge: Record<string, string> = {
  NORMAL: 'badge-success',
  ABAIXO_MINIMO: 'badge-warning',
  SEM_ESTOQUE: 'badge-danger',
};
const statusLabel: Record<string, string> = {
  NORMAL: 'Em estoque',
  ABAIXO_MINIMO: 'Abaixo mín.',
  SEM_ESTOQUE: 'Sem estoque',
};

const emptyForm = {
  sku: '', codigoBarras: '', descricao: '', marca: '', categoriaId: '',
  ncm: '87089990', cest: '', origem: 0, unidadeMedida: 'PC',
  cstIcmsSn: '400', temSt: false, mvaSt: '',
  precoCusto: '', precoVenda: '', estoqueMinimo: '', estoqueMaximo: '', quantidadeInicial: '',
};

export default function Estoque() {
  const qc = useQueryClient();
  const [busca, setBusca] = useState('');
  const [pagina, setPagina] = useState(1);
  const [showModal, setShowModal] = useState(false);
  const [editId, setEditId] = useState<string | null>(null);
  const [form, setForm] = useState(emptyForm);

  // ── NCM search ────────────────────────────────────────────
  const [showNcmModal, setShowNcmModal] = useState(false);
  const [ncmBusca, setNcmBusca] = useState('');
  const [ncmResultados, setNcmResultados] = useState<NcmItem[]>([]);
  const [ncmCarregando, setNcmCarregando] = useState(false);
  const ncmTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  async function pesquisarNcm(termo: string) {
    setNcmBusca(termo);
    if (ncmTimer.current) clearTimeout(ncmTimer.current);
    if (termo.length < 3) { setNcmResultados([]); return; }
    ncmTimer.current = setTimeout(async () => {
      setNcmCarregando(true);
      try {
        const res = await fetch(`https://brasilapi.com.br/api/ncm/v1?search=${encodeURIComponent(termo)}`);
        if (!res.ok) throw new Error();
        const data: NcmItem[] = await res.json();
        setNcmResultados(data.slice(0, 30));
      } catch {
        toast.error('Erro ao buscar NCM. Verifique sua conexão.');
      } finally {
        setNcmCarregando(false);
      }
    }, 500);
  }

  function selecionarNcm(item: NcmItem) {
    setForm(p => ({ ...p, ncm: item.codigo }));
    setShowNcmModal(false);
    setNcmBusca('');
    setNcmResultados([]);
    toast.success(`NCM ${item.codigo} selecionado!`);
  }

  const { data, isLoading } = useQuery({
    queryKey: ['produtos', busca, pagina],
    queryFn: () => produtosApi.listar({ busca, pagina, tamanhoPagina: 20 }).then(r => r.data),
    placeholderData: prev => prev,
  });

  const { data: categorias = [] } = useQuery<Categoria[]>({
    queryKey: ['categorias'],
    queryFn: () => categoriasApi.listar().then(r => r.data),
  });

  const salvarMutation = useMutation({
    mutationFn: (d: unknown) => editId ? produtosApi.atualizar(editId, d) : produtosApi.criar(d),
    onSuccess: () => {
      toast.success(editId ? 'Produto atualizado!' : 'Produto cadastrado!');
      qc.invalidateQueries({ queryKey: ['produtos'] });
      setShowModal(false);
    },
    onError: (e: { response?: { data?: { mensagem?: string } } }) => toast.error(e.response?.data?.mensagem ?? 'Erro ao salvar produto'),
  });

  function openNew() {
    setEditId(null);
    setForm(emptyForm);
    setShowModal(true);
  }

  function openEdit(p: Produto) {
    setEditId(p.id);
    setForm({
      sku: p.sku, codigoBarras: p.codigoBarras ?? '', descricao: p.descricao,
      marca: p.marca ?? '', categoriaId: '',
      ncm: p.ncm, cest: p.cest ?? '', origem: 0, unidadeMedida: p.unidadeMedida,
      cstIcmsSn: p.cstIcmsSn, temSt: p.temSt, mvaSt: String(p.mvaSt ?? ''),
      precoCusto: String(p.precoCusto), precoVenda: String(p.precoVenda),
      estoqueMinimo: String(p.estoqueMinimo), estoqueMaximo: String(p.estoqueMaximo),
      quantidadeInicial: '',
    });
    setShowModal(true);
  }

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    salvarMutation.mutate({
      ...form,
      origem: Number(form.origem),
      precoCusto: parseFloat(String(form.precoCusto).replace(',', '.')) || 0,
      precoVenda: parseFloat(String(form.precoVenda).replace(',', '.')) || 0,
      estoqueMinimo: parseFloat(String(form.estoqueMinimo)) || 0,
      estoqueMaximo: parseFloat(String(form.estoqueMaximo)) || 0,
      quantidadeInicial: parseFloat(String(form.quantidadeInicial)) || 0,
      mvaSt: form.mvaSt ? parseFloat(String(form.mvaSt)) : null,
      categoriaId: form.categoriaId || null,
    });
  }

  async function handleImportXML(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    const toastId = toast.loading('Processando XML...');
    try {
      const res = await produtosApi.importarXml(file);
      toast.success(res.data.mensagem || 'XML importado com sucesso!', { id: toastId });
      qc.invalidateQueries({ queryKey: ['produtos'] });
    } catch (err: any) {
      toast.error(err.response?.data?.mensagem || 'Erro ao importar XML', { id: toastId });
    }
    e.target.value = ''; // Reset
  }

  async function handleImportCSV(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    const toastId = toast.loading('Processando Planilha CSV...');
    try {
      const res = await produtosApi.importarCsv(file);
      toast.success(res.data.mensagem || 'Planilha importada com sucesso!', { id: toastId, duration: 5000 });
      qc.invalidateQueries({ queryKey: ['produtos'] });
    } catch (err: any) {
      toast.error(err.response?.data?.mensagem || 'Erro ao importar Planilha', { id: toastId });
    }
    e.target.value = ''; // Reset
  }

  const produtos: Produto[] = data?.items ?? [];
  const total = data?.total ?? 0;
  const totalPaginas = data?.totalPaginas ?? 1;

  return (
    <div>
      <div className="flex-between mb-20">
        <div>
          <p className="section-title">Estoque de Peças</p>
          <p className="section-subtitle">{total} produtos cadastrados</p>
        </div>
        <div style={{ display: 'flex', gap: 10 }}>
          <label className="btn btn-outline" style={{ cursor: 'pointer', margin: 0, backgroundColor: '#10b981', color: 'white', borderColor: '#10b981' }}>
            <FileText size={15} style={{ marginRight: 6 }} /> Importar Planilha (CSV)
            <input type="file" accept=".csv,.txt" style={{ display: 'none' }} onChange={handleImportCSV} />
          </label>
          <label className="btn btn-outline" style={{ cursor: 'pointer', margin: 0 }}>
            <Package size={15} style={{ marginRight: 6 }} /> Importar XML
            <input type="file" accept=".xml" style={{ display: 'none' }} onChange={handleImportXML} />
          </label>
          <button className="btn btn-primary" onClick={openNew}>
            <Plus size={15} /> Novo Produto
          </button>
        </div>
      </div>

      <div className="data-table-wrap">
        <div className="table-header">
          <span className="table-title">Produtos</span>
          <div className="search-wrap" style={{ width: 320 }}>
            <Search size={15} />
            <input className="form-control" placeholder="Buscar por descrição, SKU, código..." value={busca}
              onChange={e => { setBusca(e.target.value); setPagina(1); }} />
          </div>
        </div>

        {isLoading ? (
          <div className="empty-state"><div className="spinner" style={{ width: 32, height: 32 }} /></div>
        ) : produtos.length === 0 ? (
          <div className="empty-state">
            <Package size={40} />
            <p>Nenhum produto encontrado</p>
            <button className="btn btn-primary" style={{ marginTop: 12 }} onClick={openNew}>
              <Plus size={14} /> Cadastrar primeiro produto
            </button>
          </div>
        ) : (
          <>
            <table className="data-table">
              <thead>
                <tr>
                  <th>SKU / Cód. Barras</th>
                  <th>Descrição</th>
                  <th>Marca</th>
                  <th style={{ textAlign: 'right' }}>Preço Venda</th>
                  <th style={{ textAlign: 'center' }}>Estoque</th>
                  <th style={{ textAlign: 'center' }}>Status</th>
                  <th style={{ textAlign: 'center' }}>Ações</th>
                </tr>
              </thead>
              <tbody>
                {produtos.map(p => (
                  <tr key={p.id}>
                    <td>
                      <div style={{ fontWeight: 600, fontSize: 13 }}>{p.sku}</div>
                      {p.codigoBarras && <div style={{ fontSize: 11, color: 'var(--text-muted)' }}>{p.codigoBarras}</div>}
                    </td>
                    <td>
                      <div style={{ fontWeight: 500 }}>{p.descricao}</div>
                      {p.categoria && <div style={{ fontSize: 11, color: 'var(--text-muted)' }}>{p.categoria}</div>}
                    </td>
                    <td style={{ fontSize: 13 }}>{p.marca ?? '—'}</td>
                    <td style={{ textAlign: 'right', fontWeight: 700, color: 'var(--primary)' }}>
                      {fmtBRL(p.precoVenda)}
                    </td>
                    <td style={{ textAlign: 'center', fontSize: 14, fontWeight: 700 }}>
                      {p.quantidadeTotal} {p.unidadeMedida}
                    </td>
                    <td style={{ textAlign: 'center' }}>
                      <span className={`badge ${statusBadge[p.statusEstoque] ?? 'badge-default'}`}>
                        {statusLabel[p.statusEstoque] ?? p.statusEstoque}
                      </span>
                    </td>
                    <td style={{ textAlign: 'center' }}>
                      <button className="btn btn-outline btn-sm" onClick={() => openEdit(p)}>
                        <Edit size={13} />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>

            {/* Paginação */}
            {totalPaginas > 1 && (
              <div style={{ display: 'flex', justifyContent: 'center', gap: 8, padding: '12px 16px', borderTop: '1px solid var(--border)' }}>
                <button className="btn btn-outline btn-sm" disabled={pagina <= 1} onClick={() => setPagina(p => p - 1)}>← Anterior</button>
                <span style={{ fontSize: 13, lineHeight: '30px' }}>Pág. {pagina} de {totalPaginas}</span>
                <button className="btn btn-outline btn-sm" disabled={pagina >= totalPaginas} onClick={() => setPagina(p => p + 1)}>Próxima →</button>
              </div>
            )}
          </>
        )}
      </div>

      {/* Modal de Produto */}
      {showModal && (
        <div className="modal-overlay" onClick={e => { if (e.target === e.currentTarget) setShowModal(false); }}>
          <div className="modal" style={{ maxWidth: 700 }}>
            <div className="modal-header">
              <span className="modal-title">{editId ? 'Editar Produto' : 'Novo Produto'}</span>
              <button className="btn btn-outline btn-sm" onClick={() => setShowModal(false)}><X size={14} /></button>
            </div>
            <form onSubmit={handleSubmit}>
              <div className="modal-body">
                <div className="form-grid form-grid-2">
                  <div className="form-group">
                    <label className="form-label">SKU *</label>
                    <input className="form-control" required value={form.sku} onChange={e => setForm(p => ({ ...p, sku: e.target.value }))} placeholder="Ex: FILTRO-123" />
                  </div>
                  <div className="form-group">
                    <label className="form-label">Código de Barras (EAN)</label>
                    <input className="form-control" value={form.codigoBarras} onChange={e => setForm(p => ({ ...p, codigoBarras: e.target.value }))} placeholder="7891234567890" />
                  </div>
                </div>
                <div className="form-group">
                  <label className="form-label">Descrição *</label>
                  <input className="form-control" required value={form.descricao} onChange={e => setForm(p => ({ ...p, descricao: e.target.value }))} placeholder="Nome completo do produto" />
                </div>
                <div className="form-grid form-grid-3">
                  <div className="form-group">
                    <label className="form-label">Marca</label>
                    <input className="form-control" value={form.marca} onChange={e => setForm(p => ({ ...p, marca: e.target.value }))} />
                  </div>
                  <div className="form-group">
                    <label className="form-label">Categoria</label>
                    <select className="form-control" value={form.categoriaId} onChange={e => setForm(p => ({ ...p, categoriaId: e.target.value }))}>
                      <option value="">— Selecione —</option>
                      {categorias.map((c: Categoria) => <option key={c.id} value={c.id}>{c.nome}</option>)}
                    </select>
                  </div>
                  <div className="form-group">
                    <label className="form-label">Unidade</label>
                    <select className="form-control" value={form.unidadeMedida} onChange={e => setForm(p => ({ ...p, unidadeMedida: e.target.value }))}>
                      {['PC', 'UN', 'KG', 'LT', 'MT', 'CX', 'PAR', 'JG'].map(u => <option key={u}>{u}</option>)}
                    </select>
                  </div>
                </div>

                {/* Fiscal */}
                <div style={{ background: 'var(--bg-base)', padding: '12px 16px', borderRadius: 'var(--radius)', marginBottom: 16 }}>
                  <div style={{ fontSize: 12, fontWeight: 700, color: 'var(--text-secondary)', marginBottom: 12, textTransform: 'uppercase' }}>🧾 Dados Fiscais</div>
                  <div className="form-grid form-grid-3">
                    <div className="form-group" style={{ margin: 0 }}>
                      <label className="form-label" style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                        NCM *
                        <button type="button" className="btn btn-outline btn-sm"
                          style={{ padding: '2px 8px', fontSize: 11 }}
                          onClick={() => { setShowNcmModal(true); setNcmBusca(''); setNcmResultados([]); }}>
                          <BookOpen size={11} /> Pesquisar
                        </button>
                      </label>
                      <input className="form-control" required value={form.ncm}
                        onChange={e => setForm(p => ({ ...p, ncm: e.target.value }))}
                        placeholder="87089990" maxLength={8} />
                    </div>
                    <div className="form-group" style={{ margin: 0 }}>
                      <label className="form-label">CEST (ST)</label>
                      <input className="form-control" value={form.cest} onChange={e => setForm(p => ({ ...p, cest: e.target.value }))} placeholder="1010100" maxLength={7} />
                    </div>
                    <div className="form-group" style={{ margin: 0 }}>
                      <label className="form-label">CSOSN</label>
                      <select className="form-control" value={form.cstIcmsSn} onChange={e => setForm(p => ({ ...p, cstIcmsSn: e.target.value }))}>
                        <option value="400">400 — Tributado SN</option>
                        <option value="500">500 — ST retida anterior</option>
                        <option value="102">102 — Isenta</option>
                        <option value="300">300 — Imune</option>
                      </select>
                    </div>
                  </div>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginTop: 12 }}>
                    <input type="checkbox" id="temSt" checked={form.temSt} onChange={e => setForm(p => ({ ...p, temSt: e.target.checked }))} />
                    <label htmlFor="temSt" style={{ fontSize: 13, cursor: 'pointer' }}>Produto com Substituição Tributária (ST)</label>
                    {form.temSt && (
                      <input className="form-control" style={{ width: 120, marginLeft: 8 }} placeholder="MVA %" value={form.mvaSt}
                        onChange={e => setForm(p => ({ ...p, mvaSt: e.target.value }))} />
                    )}
                  </div>
                </div>

                <div className="form-grid form-grid-2">
                  <div className="form-group">
                    <label className="form-label">Preço de Custo (R$)</label>
                    <input className="form-control" type="number" step="0.01" min="0" value={form.precoCusto}
                      onChange={e => setForm(p => ({ ...p, precoCusto: e.target.value }))} />
                  </div>
                  <div className="form-group">
                    <label className="form-label">Preço de Venda (R$) *</label>
                    <input className="form-control" type="number" step="0.01" min="0" required value={form.precoVenda}
                      onChange={e => setForm(p => ({ ...p, precoVenda: e.target.value }))} />
                  </div>
                  <div className="form-group">
                    <label className="form-label">Estoque Mínimo</label>
                    <input className="form-control" type="number" min="0" value={form.estoqueMinimo}
                      onChange={e => setForm(p => ({ ...p, estoqueMinimo: e.target.value }))} />
                  </div>
                    <div className="form-group" style={{ margin: 0 }}>
                      <label className="form-label">Estoque Max.</label>
                      <input type="number" className="form-control" value={form.estoqueMaximo}
                        onChange={e => setForm(p => ({ ...p, estoqueMaximo: e.target.value }))} />
                    </div>
                    {!editId && (
                      <div className="form-group" style={{ margin: 0 }}>
                        <label className="form-label" style={{ color: 'var(--primary)' }}>Qtd. Inicial *</label>
                        <input type="number" className="form-control" value={form.quantidadeInicial} required
                          onChange={e => setForm(p => ({ ...p, quantidadeInicial: e.target.value }))} />
                      </div>
                    )}
                </div>
              </div>
              <div className="modal-footer">
                <button type="button" className="btn btn-outline" onClick={() => setShowModal(false)}>Cancelar</button>
                <button type="submit" className="btn btn-primary" disabled={salvarMutation.isPending}>
                  {salvarMutation.isPending ? <div className="spinner" /> : <><Check size={14} /> Salvar Produto</>}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal de Pesquisa de NCM */}
      {showNcmModal && (
        <div className="modal-overlay" onClick={e => { if (e.target === e.currentTarget) setShowNcmModal(false); }}>
          <div className="modal" style={{ maxWidth: 680 }}>
            <div className="modal-header">
              <span className="modal-title">🔍 Pesquisar NCM</span>
              <button className="btn btn-outline btn-sm" onClick={() => setShowNcmModal(false)}><X size={14} /></button>
            </div>
            <div className="modal-body">
              <div className="search-wrap" style={{ marginBottom: 16 }}>
                <Search size={15} />
                <input
                  className="form-control"
                  autoFocus
                  placeholder="Digite o nome do produto (ex: filtro, amortecedor, pastilha...)"
                  value={ncmBusca}
                  onChange={e => pesquisarNcm(e.target.value)}
                />
              </div>
              {ncmCarregando && (
                <div style={{ textAlign: 'center', padding: 24 }}><div className="spinner" /></div>
              )}
              {!ncmCarregando && ncmBusca.length >= 3 && ncmResultados.length === 0 && (
                <div className="empty-state" style={{ padding: 24 }}>
                  <BookOpen size={32} /><p>Nenhum NCM encontrado para "{ncmBusca}"</p>
                </div>
              )}
              {ncmResultados.length > 0 && (
                <div style={{ maxHeight: 400, overflowY: 'auto' }}>
                  <table className="data-table">
                    <thead>
                      <tr>
                        <th style={{ width: 100 }}>Código NCM</th>
                        <th>Descrição</th>
                        <th style={{ width: 80 }}></th>
                      </tr>
                    </thead>
                    <tbody>
                      {ncmResultados.map(item => (
                        <tr key={item.codigo} style={{ cursor: 'pointer' }} onClick={() => selecionarNcm(item)}>
                          <td style={{ fontFamily: 'monospace', fontWeight: 700, color: 'var(--primary)' }}>{item.codigo}</td>
                          <td style={{ fontSize: 12 }}>{item.descricao}</td>
                          <td><button type="button" className="btn btn-primary btn-sm" onClick={() => selecionarNcm(item)}>Usar</button></td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
              {ncmBusca.length < 3 && (
                <p style={{ textAlign: 'center', color: 'var(--text-muted)', fontSize: 13, padding: 16 }}>
                  💡 Digite pelo menos 3 letras para pesquisar. Ex: <strong>filtro oleo</strong>, <strong>pastilha freio</strong>, <strong>amortecedor</strong>
                </p>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
