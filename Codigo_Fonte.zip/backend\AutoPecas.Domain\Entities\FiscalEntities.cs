namespace AutoPecas.Domain.Entities;

/// <summary>
/// Registro de certificado digital (A1 ou A3) no banco de dados.
/// </summary>
public class CertificadoDigital
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public Guid EmpresaId { get; set; }
    public TipoCertificado Tipo { get; set; }
    public string Thumbprint { get; set; } = string.Empty;
    public string? Subject { get; set; }
    public string? EmitidoPor { get; set; }
    public DateTime ValidoDe { get; set; }
    public DateTime ValidoAte { get; set; }
    public string CnpjCertificado { get; set; } = string.Empty;
    // A1
    public string? CaminhoPfx { get; set; }
    public string? SenhaPfxHash { get; set; }          // BCrypt — nunca a senha em texto
    // A3
    public string? StoreLocation { get; set; }          // CurrentUser | LocalMachine
    public string? StoreName { get; set; }              // My
    // Controle
    public bool Ativo { get; set; } = true;
    public bool Padrao { get; set; }
    public string? Observacao { get; set; }
    public DateTime CriadoEm { get; set; } = DateTime.UtcNow;
    public DateTime AtualizadoEm { get; set; } = DateTime.UtcNow;

    public virtual Empresa? Empresa { get; set; }
}

public enum TipoCertificado { A1, A3 }

public class Empresa
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public string RazaoSocial { get; set; } = string.Empty;
    public string? NomeFantasia { get; set; }
    public string Cnpj { get; set; } = string.Empty;
    public string? InscricaoEstadual { get; set; }
    public string? InscricaoMunicipal { get; set; }
    public string Cep { get; set; } = string.Empty;
    public string Logradouro { get; set; } = string.Empty;
    public string Numero { get; set; } = string.Empty;
    public string? Complemento { get; set; }
    public string Bairro { get; set; } = string.Empty;
    public string Municipio { get; set; } = string.Empty;
    public string? CodigoIbge { get; set; }
    public string Uf { get; set; } = "SP";
    public string? Telefone { get; set; }
    public string? Email { get; set; }
    public int RegimeTributario { get; set; } = 1;      // 1=Simples Nacional
    public string? CnaePrincipal { get; set; }
    public bool Ativo { get; set; } = true;
    public DateTime CriadoEm { get; set; } = DateTime.UtcNow;
    public DateTime AtualizadoEm { get; set; } = DateTime.UtcNow;

    public virtual ICollection<CertificadoDigital> Certificados { get; set; } = [];
}
