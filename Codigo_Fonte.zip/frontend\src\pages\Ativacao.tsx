import { useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { ShieldAlert, KeyRound } from 'lucide-react';

export default function Ativacao() {
  const { activate } = useAuth();
  const [cnpj, setCnpj] = useState('');
  const [token, setToken] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!cnpj || !token) return;
    
    setLoading(true);
    await activate(token, cnpj);
    setLoading(false);
  };

  return (
    <div style={{
      minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center',
      background: 'linear-gradient(135deg, #0f172a 0%, #1e293b 100%)', color: '#fff', padding: '20px'
    }}>
      <div className="card" style={{ 
        maxWidth: '480px', width: '100%', padding: '48px', 
        display: 'flex', flexDirection: 'column', gap: '24px',
        background: 'rgba(255, 255, 255, 0.05)', backdropFilter: 'blur(10px)',
        border: '1px solid rgba(255,255,255,0.1)',
        boxShadow: '0 25px 50px -12px rgba(0, 0, 0, 0.5)'
      }}>
        <div style={{ textAlign: 'center', marginBottom: '16px' }}>
          <div style={{ 
            width: '64px', height: '64px', borderRadius: '50%', background: 'var(--primary)', 
            display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 24px',
            boxShadow: '0 0 20px rgba(37, 99, 235, 0.5)'
          }}>
            <ShieldAlert size={32} color="#fff" />
          </div>
          <h1 style={{ fontSize: '24px', fontWeight: 700, color: '#fff', marginBottom: '8px' }}>Ativação do Sistema</h1>
          <p style={{ color: '#cbd5e1', fontSize: '15px' }}>
            Este software requer uma licença válida para funcionar. Insira seu CNPJ e o Token fornecido.
          </p>
        </div>

        <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
          <div className="form-group">
            <label style={{ color: '#cbd5e1' }}>CNPJ da Empresa</label>
            <input 
              type="text" 
              className="input-field" 
              placeholder="00.000.000/0001-00" 
              value={cnpj} onChange={e => setCnpj(e.target.value)}
              style={{ background: 'rgba(255,255,255,0.1)', color: '#fff', border: '1px solid rgba(255,255,255,0.2)' }}
            />
          </div>
          <div className="form-group">
            <label style={{ color: '#cbd5e1' }}>Token de Ativação</label>
            <div style={{ position: 'relative' }}>
              <KeyRound size={18} color="#94a3b8" style={{ position: 'absolute', left: '16px', top: '50%', transform: 'translateY(-50%)' }} />
              <input 
                type="text" 
                className="input-field" 
                placeholder="GSI-AUTO-XXXX" 
                value={token} onChange={e => setToken(e.target.value.toUpperCase())}
                style={{ background: 'rgba(255,255,255,0.1)', color: '#fff', border: '1px solid rgba(255,255,255,0.2)', paddingLeft: '44px' }}
              />
            </div>
          </div>

          <button 
            type="submit" 
            className="btn btn-primary" 
            style={{ padding: '14px', fontSize: '16px', marginTop: '12px' }}
            disabled={loading}
          >
            {loading ? 'Validando...' : 'Ativar Licença'}
          </button>
        </form>
      </div>
    </div>
  );
}
