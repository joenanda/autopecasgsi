namespace AutoPecas.Domain.Entities;

/// <summary>
/// Produto (peça automotiva) — entidade central do módulo de Estoque.
/// </summary>
public class Produto
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public Guid? CategoriaId { get; set; }
    public Guid? FornecedorPrincipalId { get; set; }

    // Identificação
    public string Sku { get; set; } = string.Empty;
    public string? CodigoBarras { get; set; }
    public string Descricao { get; set; } = string.Empty;
    public string? DescricaoComplementar { get; set; }
    public string? Marca { get; set; }

    // Classificação fiscal
    public string Ncm { get; set; } = "87089990";
    public string? Cest { get; set; }
    public int Origem { get; set; } = 0;
    public string UnidadeMedida { get; set; } = "PC";

    // Tributação ICMS (Simples Nacional)
    public string CstIcmsSn { get; set; } = "400";
    public decimal AliquotaIcms { get; set; }

    // IPI
    public string CstIpi { get; set; } = "99";
    public decimal AliquotaIpi { get; set; }

    // PIS / COFINS
    public string CstPis { get; set; } = "07";
    public decimal AliquotaPis { get; set; }
    public string CstCofins { get; set; } = "07";
    public decimal AliquotaCofins { get; set; }

    // Substituição Tributária
    public bool TemSt { get; set; }
    public decimal? MvaSt { get; set; }

    // Preços
    public decimal PrecoCusto { get; set; }
    public decimal PrecoCustoMedio { get; set; }
    public decimal PrecoVenda { get; set; }
    public decimal? MargemLucro { get; set; }

    // Estoque
    public decimal EstoqueMinimo { get; set; }
    public decimal EstoqueMaximo { get; set; }

    // Físico
    public decimal? PesoKg { get; set; }
    public decimal? LarguraCm { get; set; }
    public decimal? AlturaCm { get; set; }
    public decimal? ComprimentoCm { get; set; }

    // Controle
    public bool Ativo { get; set; } = true;
    public string? Observacao { get; set; }
    public string? ImagemUrl { get; set; }
    public DateTime CriadoEm { get; set; } = DateTime.UtcNow;
    public DateTime AtualizadoEm { get; set; } = DateTime.UtcNow;

    // Navegação
    public virtual Categoria? Categoria { get; set; }
    public virtual ICollection<ProdutoCodigoEquivalente> CodigosEquivalentes { get; set; } = [];
    public virtual ICollection<ProdutoAplicacao> Aplicacoes { get; set; } = [];
    public virtual ICollection<EstoqueSaldo> Saldos { get; set; } = [];
}
