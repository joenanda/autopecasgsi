namespace AutoPecas.Domain.Entities;

public class Licenca
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public string TokenAtivacao { get; set; } = string.Empty;
    public DateTime DataAtivacao { get; set; } = DateTime.Now;
    public string CnpjVinculado { get; set; } = string.Empty;
    public bool Ativo { get; set; } = true;
}
