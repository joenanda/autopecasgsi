import { useQuery } from '@tanstack/react-query';
import { Package, ShoppingCart, AlertCircle, TrendingUp, DollarSign, Clock } from 'lucide-react';
import { vendasApi, financeiroApi } from '../services/api';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from 'recharts';

const fmtBRL = (v: number) => v.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });

export default function Dashboard() {
  const { data: dash } = useQuery({ queryKey: ['dashboard'], queryFn: () => vendasApi.dashboard().then(r => r.data) });
  const { data: fin }  = useQuery({ queryKey: ['fin-resumo'], queryFn: () => financeiroApi.resumo().then(r => r.data) });

  const kpis = [
    {
      label: 'Vendas Hoje',
      value: fmtBRL(dash?.vendasHoje?.valor ?? 0),
      sub: `${dash?.vendasHoje?.qtd ?? 0} pedidos`,
      color: 'var(--primary)',
      icon: ShoppingCart,
    },
    {
      label: 'Vendas no Mês',
      value: fmtBRL(dash?.vendasMes?.valor ?? 0),
      sub: `${dash?.vendasMes?.qtd ?? 0} pedidos`,
      color: 'var(--success)',
      icon: TrendingUp,
    },
    {
      label: 'A Receber',
      value: fmtBRL(fin?.totalReceber ?? 0),
      sub: `${fin?.vencendoReceber ?? 0} vencem em 7 dias`,
      color: 'var(--accent)',
      icon: DollarSign,
    },
    {
      label: 'A Pagar',
      value: fmtBRL(fin?.totalPagar ?? 0),
      sub: `${fin?.vencendoPagar ?? 0} vencem em 7 dias`,
      color: 'var(--danger)',
      icon: Clock,
    },
    {
      label: 'Saldo em Caixa',
      value: fmtBRL(fin?.saldoCaixa ?? 0),
      sub: 'Saldo líquido: ' + fmtBRL(fin?.saldoLiquido ?? 0),
      color: '#8b5cf6',
      icon: DollarSign,
    },
    {
      label: 'Produtos Sem Estoque',
      value: String(dash?.produtosSemEstoque ?? 0),
      sub: 'Reposição necessária',
      color: 'var(--danger)',
      icon: Package,
    },
  ];

  // Mock de dados para o gráfico (em produção viria do backend)
  const chartData = Array.from({ length: 7 }, (_, i) => {
    const d = new Date();
    d.setDate(d.getDate() - (6 - i));
    return {
      dia: d.toLocaleDateString('pt-BR', { weekday: 'short' }),
      valor: Math.round(Math.random() * 5000 + 1000)
    };
  });

  return (
    <div>
      <p className="section-title">Bem-vindo ao ERP Auto Peças 🔧</p>
      <p className="section-subtitle">Resumo do dia — {new Date().toLocaleDateString('pt-BR', { dateStyle: 'full' })}</p>

      {/* KPIs */}
      <div className="kpi-grid">
        {kpis.map(k => (
          <div className="kpi-card" key={k.label} style={{ '--kpi-color': k.color } as React.CSSProperties}>
            <div className="kpi-label">{k.label}</div>
            <div className="kpi-value">{k.value}</div>
            <div className="kpi-sub">{k.sub}</div>
            <div className="kpi-icon"><k.icon /></div>
          </div>
        ))}
      </div>

      {/* Gráfico de vendas */}
      <div className="data-table-wrap" style={{ padding: '20px' }}>
        <div className="table-title" style={{ marginBottom: 16 }}>📊 Vendas — Últimos 7 dias</div>
        <ResponsiveContainer width="100%" height={220}>
          <BarChart data={chartData} margin={{ top: 4, right: 8, left: 0, bottom: 0 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
            <XAxis dataKey="dia" tick={{ fontSize: 12, fill: 'var(--text-secondary)' }} />
            <YAxis tick={{ fontSize: 12, fill: 'var(--text-secondary)' }} tickFormatter={v => `R$${(v/1000).toFixed(1)}k`} />
            <Tooltip formatter={(v) => [fmtBRL(Number(v) || 0), 'Vendas']} />
            <Bar dataKey="valor" fill="var(--primary)" radius={[4, 4, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </div>

      {/* Alertas */}
      {(dash?.produtosSemEstoque > 0 || fin?.vencendoReceber > 0) && (
        <div style={{ marginTop: 20, display: 'flex', flexDirection: 'column', gap: 10 }}>
          {dash?.produtosSemEstoque > 0 && (
            <div style={{
              background: '#fef2f2', border: '1px solid #fecaca', borderRadius: 'var(--radius)',
              padding: '12px 16px', display: 'flex', alignItems: 'center', gap: 10, color: '#991b1b'
            }}>
              <AlertCircle size={18} />
              <span style={{ fontSize: 14 }}><strong>{dash.produtosSemEstoque} produtos</strong> sem estoque. Verifique o módulo de Estoque.</span>
            </div>
          )}
          {fin?.vencendoReceber > 0 && (
            <div style={{
              background: '#fffbeb', border: '1px solid #fed7aa', borderRadius: 'var(--radius)',
              padding: '12px 16px', display: 'flex', alignItems: 'center', gap: 10, color: '#92400e'
            }}>
              <AlertCircle size={18} />
              <span style={{ fontSize: 14 }}><strong>{fin.vencendoReceber} títulos</strong> a receber vencem nos próximos 7 dias.</span>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
