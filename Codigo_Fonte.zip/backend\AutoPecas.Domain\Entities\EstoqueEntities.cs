namespace AutoPecas.Domain.Entities;

public class Categoria
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public Guid? PaiId { get; set; }
    public string Nome { get; set; } = string.Empty;
    public string? Descricao { get; set; }
    public bool Ativo { get; set; } = true;
    public DateTime CriadoEm { get; set; } = DateTime.UtcNow;

    public virtual Categoria? Pai { get; set; }
    public virtual ICollection<Categoria> Subcategorias { get; set; } = [];
    public virtual ICollection<Produto> Produtos { get; set; } = [];
}

public class ProdutoCodigoEquivalente
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public Guid ProdutoId { get; set; }
    public string Tipo { get; set; } = string.Empty;    // OEM, UNIVERSAL, PARALELO
    public string Codigo { get; set; } = string.Empty;
    public string? Fabricante { get; set; }
    public string? Observacao { get; set; }
    public DateTime CriadoEm { get; set; } = DateTime.UtcNow;
    public virtual Produto? Produto { get; set; }
}

public class MarcaVeiculo
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public string Nome { get; set; } = string.Empty;
    public virtual ICollection<ModeloVeiculo> Modelos { get; set; } = [];
}

public class ModeloVeiculo
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public Guid MarcaId { get; set; }
    public string Nome { get; set; } = string.Empty;
    public char Tipo { get; set; } = 'L';  // L=Leve, P=Pesado, M=Moto
    public virtual MarcaVeiculo? Marca { get; set; }
}

public class ProdutoAplicacao
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public Guid ProdutoId { get; set; }
    public Guid ModeloId { get; set; }
    public short? AnoInicio { get; set; }
    public short? AnoFim { get; set; }
    public string? Motorizacao { get; set; }
    public string? Observacao { get; set; }
    public DateTime CriadoEm { get; set; } = DateTime.UtcNow;
    public virtual Produto? Produto { get; set; }
    public virtual ModeloVeiculo? Modelo { get; set; }
}

public class EstoqueLocalizacao
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public string Codigo { get; set; } = string.Empty;  // Ex: A01-P02
    public string? Descricao { get; set; }
    public bool Ativo { get; set; } = true;
    public virtual ICollection<EstoqueSaldo> Saldos { get; set; } = [];
}

public class EstoqueSaldo
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public Guid ProdutoId { get; set; }
    public Guid? LocalizacaoId { get; set; }
    public decimal Quantidade { get; set; }
    public decimal CustoMedio { get; set; }
    public DateTime AtualizadoEm { get; set; } = DateTime.UtcNow;
    public virtual Produto? Produto { get; set; }
    public virtual EstoqueLocalizacao? Localizacao { get; set; }
}
