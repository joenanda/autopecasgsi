import { useState, useEffect } from 'react';
import { Settings, Building2, Shield, Download, RefreshCw, Upload, CheckCircle2 } from 'lucide-react';
import toast from 'react-hot-toast';

const CURRENT_VERSION = "v1.0.0";

export default function Configuracoes() {
  const [activeTab, setActiveTab] = useState<'empresa' | 'sistema'>('empresa');
  
  // States for System / Updates
  const [checkingUpdates, setCheckingUpdates] = useState(false);
  const [updateAvailable, setUpdateAvailable] = useState<any>(null);
  
  // States for Empresa
  const [empresa, setEmpresa] = useState({
    razaoSocial: '',
    nomeFantasia: '',
    cnpj: '',
    inscricaoEstadual: '',
    regimeTributario: 'Simples Nacional',
    endereco: '',
  });

  const checkUpdates = async () => {
    setCheckingUpdates(true);
    try {
      // Como o repositório é privado, uma chamada direta vai retornar 404 Not Found
      // Precisaremos que o usuário crie um Personal Access Token (PAT) no GitHub
      // ou torne o repositório público para a API aberta funcionar.
      const res = await fetch(`https://api.github.com/repos/joenanda/autopecasgsi/releases/latest`);
      
      if (res.ok) {
        const data = await res.json();
        if (data.tag_name !== CURRENT_VERSION) {
          setUpdateAvailable(data);
          toast.success("Nova atualização encontrada!");
        } else {
          toast.success("O sistema já está na última versão.");
        }
      } else if (res.status === 404) {
        toast.error("Repositório privado ou sem releases. Se for privado, será necessário gerar um Token no GitHub ou deixá-lo público.");
      } else {
        toast.error("Falha ao verificar atualizações.");
      }
    } catch (err) {
      toast.error("Erro de conexão com o GitHub.");
    } finally {
      setCheckingUpdates(false);
    }
  };

  useEffect(() => {
    fetch('http://localhost:5000/api/configuracoes/empresa')
      .then(res => res.json())
      .then(data => {
        if (data.id) {
          setEmpresa({
            razaoSocial: data.razaoSocial || '',
            nomeFantasia: data.nomeFantasia || '',
            cnpj: data.cnpj || '',
            inscricaoEstadual: data.inscricaoEstadual || '',
            regimeTributario: data.regimeTributario || 'Simples Nacional',
            endereco: data.logradouro || '',
          });
        }
      })
      .catch(() => console.error("Falha ao carregar dados da empresa"));
  }, []);

  const buscarCnpj = async (cnpj: string) => {
    const apenasNumeros = cnpj.replace(/\D/g, '');
    if (apenasNumeros.length !== 14) return;
    
    const toastId = toast.loading('Buscando CNPJ na Receita Federal...');
    try {
      const response = await fetch(`https://brasilapi.com.br/api/cnpj/v1/${apenasNumeros}`);
      if (response.ok) {
        const data = await response.json();
        setEmpresa({
          ...empresa,
          cnpj: data.cnpj,
          razaoSocial: data.razao_social,
          nomeFantasia: data.nome_fantasia || data.razao_social,
          endereco: `${data.logradouro}, ${data.numero}${data.complemento ? ' - ' + data.complemento : ''}`,
          // Outros campos se necessário
        });
        toast.success('CNPJ encontrado!', { id: toastId });
      } else {
        toast.error('CNPJ não encontrado ou inválido.', { id: toastId });
      }
    } catch {
      toast.error('Erro de conexão ao buscar CNPJ.', { id: toastId });
    }
  };

  const handleSaveEmpresa = async (e: React.FormEvent) => {
    e.preventDefault();
    
    const payload = {
      ...empresa,
      logradouro: empresa.endereco
    };

    try {
      const response = await fetch('http://localhost:5000/api/configuracoes/empresa', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      
      if (response.ok) {
        toast.success('Configurações salvas com sucesso!');
      } else {
        toast.error('Erro ao salvar no servidor.');
      }
    } catch {
      toast.error('Erro de conexão ao salvar.');
    }
  };

  return (
    <div className="settings-container" style={{ display: 'flex', flexDirection: 'column', gap: '24px' }}>
      
      {/* Tabs */}
      <div style={{ display: 'flex', gap: '32px', borderBottom: '1px solid var(--border-color)', paddingBottom: '16px' }}>
        <button 
          onClick={() => setActiveTab('empresa')}
          style={{
            background: 'none', border: 'none', padding: '8px 4px', fontSize: '15px', fontWeight: 600,
            color: activeTab === 'empresa' ? 'var(--primary-color)' : 'var(--text-muted)',
            borderBottom: activeTab === 'empresa' ? '2px solid var(--primary-color)' : '2px solid transparent',
            cursor: 'pointer', display: 'flex', alignItems: 'center', gap: '8px', transition: 'all 0.2s'
          }}
        >
          <Building2 size={18} /> Dados da Empresa
        </button>
        <button 
          onClick={() => setActiveTab('sistema')}
          style={{
            background: 'none', border: 'none', padding: '8px 4px', fontSize: '15px', fontWeight: 600,
            color: activeTab === 'sistema' ? 'var(--primary-color)' : 'var(--text-muted)',
            borderBottom: activeTab === 'sistema' ? '2px solid var(--primary-color)' : '2px solid transparent',
            cursor: 'pointer', display: 'flex', alignItems: 'center', gap: '8px', transition: 'all 0.2s'
          }}
        >
          <Settings size={18} /> Sistema e Atualizações
        </button>
      </div>

      <div className="card" style={{ padding: '32px' }}>
        
        {/* ABA: DADOS DA EMPRESA */}
        {activeTab === 'empresa' && (
          <form onSubmit={handleSaveEmpresa} style={{ display: 'flex', flexDirection: 'column', gap: '24px', maxWidth: '800px' }}>
            
            <div>
              <h3 style={{ fontSize: '18px', fontWeight: 600, marginBottom: '8px' }}>Informações Fiscais</h3>
              <p style={{ color: 'var(--text-muted)', fontSize: '14px', marginBottom: '24px' }}>
                Esses dados serão usados para a emissão de Notas Fiscais e relatórios gerenciais.
              </p>
              
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '20px' }}>
                <div className="form-group">
                  <label>Razão Social</label>
                  <input type="text" className="input-field" placeholder="Sua Empresa LTDA" 
                    value={empresa.razaoSocial} onChange={e => setEmpresa({...empresa, razaoSocial: e.target.value})} />
                </div>
                <div className="form-group">
                  <label>Nome Fantasia</label>
                  <input type="text" className="input-field" placeholder="Loja Auto Peças" 
                    value={empresa.nomeFantasia} onChange={e => setEmpresa({...empresa, nomeFantasia: e.target.value})} />
                </div>
                <div className="form-group">
                  <label>CNPJ</label>
                  <input type="text" className="input-field" placeholder="00.000.000/0001-00" 
                    value={empresa.cnpj} 
                    onChange={e => setEmpresa({...empresa, cnpj: e.target.value})}
                    onBlur={() => buscarCnpj(empresa.cnpj)} 
                  />
                  <small style={{color: 'var(--text-muted)', fontSize: '11px'}}>Digite e saia do campo para buscar</small>
                </div>
                <div className="form-group">
                  <label>Inscrição Estadual</label>
                  <input type="text" className="input-field" placeholder="Isento ou Número" 
                    value={empresa.inscricaoEstadual} onChange={e => setEmpresa({...empresa, inscricaoEstadual: e.target.value})} />
                </div>
              </div>
            </div>
            
            <hr style={{ border: 'none', borderTop: '1px solid var(--border-color)', margin: '8px 0' }} />
            
            <div>
              <h3 style={{ fontSize: '18px', fontWeight: 600, marginBottom: '8px', display: 'flex', alignItems: 'center', gap: '8px' }}>
                <Shield size={18} color="var(--primary-color)"/> Certificado Digital
              </h3>
              <p style={{ color: 'var(--text-muted)', fontSize: '14px', marginBottom: '16px' }}>
                Faça o upload do seu certificado A1 (.pfx) ou selecione um A3 conectado via USB.
              </p>
              
              <label style={{ 
                border: '2px dashed var(--border-color)', borderRadius: '12px', padding: '32px', 
                textAlign: 'center', background: 'var(--surface-color)', cursor: 'pointer',
                display: 'block', transition: 'all 0.2s'
              }} className="hover-bg">
                <Upload size={32} color="var(--text-muted)" style={{ margin: '0 auto 12px' }} />
                <h4 style={{ fontWeight: 600, marginBottom: '4px' }}>Clique para selecionar o certificado .pfx</h4>
                <p style={{ fontSize: '13px', color: 'var(--text-muted)' }}>Tamanho máximo 2MB</p>
                <input type="file" accept=".pfx" style={{ display: 'none' }} onChange={(e) => {
                  if (e.target.files?.length) {
                    toast.success(`Certificado ${e.target.files[0].name} selecionado!`);
                  }
                }} />
              </label>
            </div>

            <div style={{ display: 'flex', justifyContent: 'flex-end', marginTop: '16px' }}>
              <button type="submit" className="btn btn-primary">Salvar Configurações</button>
            </div>
          </form>
        )}


        {/* ABA: SISTEMA / ATUALIZAÇÕES */}
        {activeTab === 'sistema' && (
          <div style={{ display: 'flex', flexDirection: 'column', gap: '32px', maxWidth: '800px' }}>
            
            <div>
              <h3 style={{ fontSize: '18px', fontWeight: 600, marginBottom: '8px' }}>Sobre o Sistema</h3>
              
              <div style={{ 
                background: 'var(--surface-color)', borderRadius: '12px', padding: '24px', 
                border: '1px solid var(--border-color)', display: 'flex', alignItems: 'center', justifyContent: 'space-between'
              }}>
                <div>
                  <h4 style={{ fontSize: '16px', fontWeight: 600 }}>ERP Auto Peças</h4>
                  <p style={{ color: 'var(--text-muted)', fontSize: '14px', marginTop: '4px' }}>
                    Versão Atual: <strong style={{ color: 'var(--text-color)' }}>{CURRENT_VERSION}</strong>
                  </p>
                </div>
                
                <div style={{ display: 'flex', alignItems: 'center', gap: '8px', color: '#10b981', fontSize: '14px', fontWeight: 500 }}>
                  <CheckCircle2 size={18} /> Sistema Atualizado
                </div>
              </div>
            </div>

            <div>
              <h3 style={{ fontSize: '18px', fontWeight: 600, marginBottom: '8px' }}>Atualizações Automáticas</h3>
              <p style={{ color: 'var(--text-muted)', fontSize: '14px', marginBottom: '16px' }}>
                Verifique por novas atualizações diretamente no seu repositório: <strong>github.com/joenanda/autopecasgsi</strong>
              </p>
              
              <button 
                className="btn btn-outline" 
                onClick={checkUpdates}
                disabled={checkingUpdates}
                style={{ display: 'inline-flex', alignItems: 'center', gap: '8px' }}
              >
                <RefreshCw size={18} className={checkingUpdates ? 'spin' : ''} /> 
                {checkingUpdates ? 'Buscando atualizações...' : 'Verificar Atualizações no GitHub'}
              </button>

              {updateAvailable && (
                <div style={{ 
                  marginTop: '24px', padding: '24px', background: '#f0fdf4', border: '1px solid #bbf7d0', 
                  borderRadius: '12px', display: 'flex', alignItems: 'center', justifyContent: 'space-between'
                }}>
                  <div>
                    <h4 style={{ color: '#166534', fontWeight: 600, fontSize: '16px' }}>Nova Atualização Encontrada!</h4>
                    <p style={{ color: '#15803d', fontSize: '14px', marginTop: '4px' }}>
                      A versão <strong>{updateAvailable.tag_name}</strong> já está disponível para download.
                    </p>
                  </div>
                  <a 
                    href={updateAvailable.assets?.[0]?.browser_download_url || updateAvailable.html_url} 
                    target="_blank" rel="noopener noreferrer"
                    className="btn btn-primary"
                    style={{ background: '#16a34a', borderColor: '#16a34a' }}
                  >
                    <Download size={18} /> Baixar Instalador
                  </a>
                </div>
              )}
            </div>

            <hr style={{ border: 'none', borderTop: '1px solid var(--border-color)', margin: '16px 0' }} />

            <div>
              <h3 style={{ fontSize: '18px', fontWeight: 600, marginBottom: '8px', color: '#ef4444' }}>Zona de Perigo</h3>
              <p style={{ color: 'var(--text-muted)', fontSize: '14px', marginBottom: '16px' }}>
                Ações críticas para o funcionamento do sistema e banco de dados local.
              </p>
              <button className="btn" style={{ background: '#fee2e2', color: '#b91c1c', border: 'none', fontWeight: 600 }}>
                Fazer Backup do Banco de Dados
              </button>
            </div>
            
          </div>
        )}
      </div>
    </div>
  );
}
