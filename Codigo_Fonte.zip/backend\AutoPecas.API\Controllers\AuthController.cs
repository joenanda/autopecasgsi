using AutoPecas.Domain.Entities;
using AutoPecas.Infrastructure.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Security.Cryptography;
using System.Text;

namespace AutoPecas.API.Controllers;

[ApiController]
[Route("api/[controller]")]
public class AuthController : ControllerBase
{
    private readonly AutoPecasDbContext _context;
    private readonly IConfiguration _config;
    private const string MASTER_TOKEN = "GSI-AUTO-2026-MASTER"; // Fallback / Master key

    public AuthController(AutoPecasDbContext context, IConfiguration config)
    {
        _context = context;
        _config = config;
    }

    [HttpGet("status")]
    public async Task<IActionResult> GetStatus()
    {
        var licenca = await _context.Licencas.FirstOrDefaultAsync(l => l.Ativo);
        bool hasUsers = await _context.Usuarios.AnyAsync();
        
        return Ok(new {
            Ativado = licenca != null,
            PrecisaConfigurarAdmin = !hasUsers
        });
    }

    [HttpPost("ativar")]
    public async Task<IActionResult> AtivarSistema([FromBody] AtivarRequest req)
    {
        var licencaExistente = await _context.Licencas.FirstOrDefaultAsync(l => l.Ativo);
        if (licencaExistente != null)
            return BadRequest(new { message = "O sistema já está ativado." });

        // Validação da Licença (Token baseado no CNPJ ou Master Key)
        bool tokenValido = false;
        
        if (req.Token == MASTER_TOKEN)
        {
            tokenValido = true;
        }
        else
        {
            // Validação por hash do CNPJ: MD5(CNPJ + "GSI") (Simples para demonstração)
            string cnpjNumeros = new string(req.Cnpj.Where(char.IsDigit).ToArray());
            if (cnpjNumeros.Length == 14)
            {
                using (var md5 = MD5.Create())
                {
                    byte[] inputBytes = Encoding.ASCII.GetBytes(cnpjNumeros + "GSI");
                    byte[] hashBytes = md5.ComputeHash(inputBytes);
                    string expectedToken = Convert.ToHexString(hashBytes).Substring(0, 10).ToUpper();
                    
                    if (req.Token.ToUpper() == expectedToken)
                        tokenValido = true;
                }
            }
        }

        if (!tokenValido)
            return BadRequest(new { message = "Token de ativação inválido." });

        var novaLicenca = new Licenca
        {
            Id = Guid.NewGuid(),
            TokenAtivacao = req.Token,
            CnpjVinculado = req.Cnpj,
            DataAtivacao = DateTime.Now,
            Ativo = true
        };

        _context.Licencas.Add(novaLicenca);
        await _context.SaveChangesAsync();

        return Ok(new { message = "Sistema ativado com sucesso!" });
    }

    [HttpPost("login")]
    public async Task<IActionResult> Login([FromBody] LoginRequest req)
    {
        // Se for primeiro acesso e não tiver usuários, cria o admin
        if (!await _context.Usuarios.AnyAsync())
        {
            _context.Usuarios.Add(new Usuario
            {
                Nome = "Administrador",
                Login = "admin",
                SenhaHash = HashPassword("admin123"),
                Role = "Admin"
            });
            await _context.SaveChangesAsync();
        }

        var reqSenhaHash = HashPassword(req.Senha);
        var user = await _context.Usuarios.FirstOrDefaultAsync(u => u.Login == req.Login && u.SenhaHash == reqSenhaHash && u.Ativo);

        if (user == null)
            return Unauthorized(new { message = "Usuário ou senha inválidos." });

        var tokenHandler = new JwtSecurityTokenHandler();
        var key = Encoding.ASCII.GetBytes(_config["Jwt:Key"] ?? "chave-super-secreta-erp-auto-pecas-2026-min-32-chars-long");
        
        var tokenDescriptor = new SecurityTokenDescriptor
        {
            Subject = new ClaimsIdentity(new[]
            {
                new Claim(ClaimTypes.NameIdentifier, user.Id.ToString()),
                new Claim(ClaimTypes.Name, user.Nome),
                new Claim(ClaimTypes.Role, user.Role)
            }),
            Expires = DateTime.UtcNow.AddHours(12),
            SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256Signature)
        };

        var token = tokenHandler.CreateToken(tokenDescriptor);

        return Ok(new {
            Token = tokenHandler.WriteToken(token),
            User = new { user.Id, user.Nome, user.Role }
        });
    }

    private string HashPassword(string password)
    {
        using var sha256 = SHA256.Create();
        var bytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(password));
        return Convert.ToBase64String(bytes);
    }
}

public class AtivarRequest
{
    public string Cnpj { get; set; } = string.Empty;
    public string Token { get; set; } = string.Empty;
}

public class LoginRequest
{
    public string Login { get; set; } = string.Empty;
    public string Senha { get; set; } = string.Empty;
}
