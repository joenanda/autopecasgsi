﻿namespace AutoPecas.Domain;

public class Class1
{

}
