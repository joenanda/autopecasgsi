using AutoPecas.Domain.Entities;
using AutoPecas.Infrastructure.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace AutoPecas.API.Controllers;

[ApiController]
[Route("api/[controller]")]
public class CategoriasController : ControllerBase
{
    private readonly AutoPecasDbContext _db;

    public CategoriasController(AutoPecasDbContext db)
    {
        _db = db;
    }

    [HttpGet]
    public async Task<IActionResult> ListarTodas()
    {
        var categorias = await _db.Categorias
            .Where(c => c.Ativo)
            .OrderBy(c => c.Nome)
            .ToListAsync();
            
        return Ok(categorias);
    }

    [HttpPost]
    public async Task<IActionResult> Criar([FromBody] CategoriaDTO dto)
    {
        if (string.IsNullOrWhiteSpace(dto.Nome))
            return BadRequest(new { mensagem = "Nome da categoria é obrigatório." });

        var cat = new Categoria
        {
            Id = Guid.NewGuid(),
            Nome = dto.Nome,
            Ativo = true,
            CriadoEm = DateTime.UtcNow
        };

        _db.Categorias.Add(cat);
        await _db.SaveChangesAsync();

        return Created($"/api/categorias/{cat.Id}", cat);
    }
}

public class CategoriaDTO
{
    public string Nome { get; set; } = string.Empty;
}
