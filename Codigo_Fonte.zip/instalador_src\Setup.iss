[Setup]
AppName=ERP Auto Peças
AppVersion=1.0.0
DefaultDirName={pf}\ERP Auto Pecas
DefaultGroupName=ERP Auto Peças
OutputDir=C:\PROJETOS\AUTO PECAS
OutputBaseFilename=Instalar_ERP_AutoPecas
Compression=lzma2
SolidCompression=yes
ArchitecturesInstallIn64BitMode=x64

[Files]
Source: "C:\PROJETOS\ERP_Instalavel\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs
Source: "C:\PROJETOS\AUTO PECAS\instalador_src\ExecutarERP.vbs"; DestDir: "{app}"; Flags: ignoreversion
Source: "C:\PROJETOS\AUTO PECAS\instalador_src\PararERP.vbs"; DestDir: "{app}"; Flags: ignoreversion

[Icons]
Name: "{group}\ERP Auto Peças"; Filename: "{app}\ExecutarERP.vbs"
Name: "{group}\Parar ERP Auto Peças"; Filename: "{app}\PararERP.vbs"
Name: "{commondesktop}\ERP Auto Peças"; Filename: "{app}\ExecutarERP.vbs"

[Run]
Filename: "{app}\ExecutarERP.vbs"; Description: "Iniciar ERP Auto Peças agora"; Flags: postinstall shellexec skipifsilent
