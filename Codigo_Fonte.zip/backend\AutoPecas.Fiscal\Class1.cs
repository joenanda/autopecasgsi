﻿namespace AutoPecas.Fiscal;

public class Class1
{

}
