using AutoPecas.Fiscal.Services;
using AutoPecas.Infrastructure.Data;
using Microsoft.EntityFrameworkCore;
using Microsoft.OpenApi.Models;


var builder = WebApplication.CreateBuilder(args);

// ============================================================
//  Banco de Dados — SQLite via EF Core
// ============================================================
var appData = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
var dbFolder = Path.Combine(appData, "ERP_AutoPecas");
if (!Directory.Exists(dbFolder))
    Directory.CreateDirectory(dbFolder);
var dbPath = Path.Combine(dbFolder, "autopecas.db");

builder.Services.AddDbContext<AutoPecasDbContext>(options =>
    options.UseSqlite($"Data Source={dbPath}")
);

// ============================================================
//  Módulo Fiscal — Serviços de Certificados e Impostos
// ============================================================
builder.Services.AddScoped<CertificadoService>();
builder.Services.AddScoped<MotorImpostosService>();


// ============================================================
//  Controllers e JSON
// ============================================================
builder.Services.AddControllers()
    .AddJsonOptions(opts =>
    {
        opts.JsonSerializerOptions.PropertyNamingPolicy = System.Text.Json.JsonNamingPolicy.CamelCase;
        opts.JsonSerializerOptions.WriteIndented = true;
    });



// ============================================================
//  Autenticação JWT
// ============================================================
var jwtKey = builder.Configuration["Jwt:Key"] ?? "chave-super-secreta-erp-auto-pecas-2026-min-32-chars-long";
var keyBytes = System.Text.Encoding.ASCII.GetBytes(jwtKey);

builder.Services.AddAuthentication(opts =>
{
    opts.DefaultAuthenticateScheme = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme;
    opts.DefaultChallengeScheme = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme;
})
.AddJwtBearer(opts =>
{
    opts.RequireHttpsMetadata = false; // Como é local/offline
    opts.SaveToken = true;
    opts.TokenValidationParameters = new Microsoft.IdentityModel.Tokens.TokenValidationParameters
    {
        ValidateIssuerSigningKey = true,
        IssuerSigningKey = new Microsoft.IdentityModel.Tokens.SymmetricSecurityKey(keyBytes),
        ValidateIssuer = false,
        ValidateAudience = false
    };
});

// ============================================================
//  Swagger / OpenAPI
// ============================================================
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(c =>
{
    c.SwaggerDoc("v1", new OpenApiInfo
    {
        Title = "ERP Auto Peças — API",
        Version = "v1",
        Description = "API REST do sistema ERP para loja de autopeças. Módulos: Estoque, Vendas, Fiscal (NF-e/NFC-e), Financeiro.",
        Contact = new OpenApiContact { Name = "Administrador", Email = "admin@autopecas.local" }
    });
});

// ============================================================
//  CORS — Permite acesso do Frontend React (localhost)
// ============================================================
var corsOrigins = builder.Configuration.GetSection("Cors:Origins").Get<string[]>()
                  ?? ["http://localhost:5173"];

builder.Services.AddCors(options =>
{
    options.AddPolicy("LocalhostPolicy", policy =>
        policy.WithOrigins(corsOrigins)
              .AllowAnyHeader()
              .AllowAnyMethod()
              .AllowCredentials()
    );
});

// ============================================================
//  Health Checks
// ============================================================
builder.Services.AddHealthChecks();

var app = builder.Build();

// ============================================================
//  Pipeline HTTP
// ============================================================
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI(c =>
    {
        c.SwaggerEndpoint("/swagger/v1/swagger.json", "ERP Auto Peças v1");
        c.RoutePrefix = "swagger";
        c.DisplayRequestDuration();
    });
}

app.UseCors("LocalhostPolicy");
app.UseStaticFiles();
app.UseAuthentication();
app.UseAuthorization();
app.MapControllers();
app.MapHealthChecks("/health");
app.MapFallbackToFile("index.html");

// ============================================================
//  Aplicar Migrations + Seed de dados iniciais
// ============================================================
using (var scope = app.Services.CreateScope())
{
    var db = scope.ServiceProvider.GetRequiredService<AutoPecasDbContext>();
    try
    {
        db.Database.Migrate();
        app.Logger.LogInformation("✅ Banco de dados atualizado com sucesso.");

        // Seed: Localização de estoque padrão
        if (!db.EstoqueLocalizacoes.Any())
        {
            db.EstoqueLocalizacoes.Add(new AutoPecas.Domain.Entities.EstoqueLocalizacao
            {
                Codigo = "GERAL",
                Descricao = "Estoque Geral",
                Ativo = true
            });
            db.SaveChanges();
            app.Logger.LogInformation("✅ Localização de estoque padrão criada.");
        }

        // Seed: Usuário administrador padrão
        if (!db.Usuarios.Any())
        {
            db.Usuarios.Add(new AutoPecas.Domain.Entities.Usuario
            {
                Nome = "Administrador",
                Login = "admin",
                SenhaHash = BCrypt.Net.BCrypt.HashPassword("admin123"),
                Role = "Admin",
                Ativo = true
            });
            db.SaveChanges();
            app.Logger.LogInformation("✅ Usuário admin criado.");
        }
    }
    catch (Exception ex)
    {
        app.Logger.LogError(ex, "❌ Falha ao aplicar migrations/seed.");
    }
}

app.Logger.LogInformation("🚀 ERP Auto Peças API iniciada em {Urls}", string.Join(", ", app.Urls));
app.Run();
