import { useState, useRef, useEffect } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { Search, Plus, Trash2, Printer, CheckCircle, X, ShoppingCart } from 'lucide-react';
import toast from 'react-hot-toast';
import { produtosApi, clientesApi, vendasApi } from '../services/api';

const fmtBRL = (v: number) => v.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });

interface ItemCarrinho {
  produtoId: string;
  sku: string;
  descricao: string;
  quantidade: number;
  precoUnitario: number;
  descontoPercentual: number;
  total: number;
}

interface FormaPag {
  formaPagamento: string;
  codigoNfe: string;
  valor: number;
  parcelas: number;
}

const FORMAS_PAG = [
  { label: 'Dinheiro', codigo: '01' },
  { label: 'Cartão Crédito', codigo: '03' },
  { label: 'Cartão Débito', codigo: '04' },
  { label: 'PIX', codigo: '17' },
  { label: 'Crediário', codigo: '99' },
];

export default function PDV() {
  const [busca, setBusca] = useState('');
  const [carrinho, setCarrinho] = useState<ItemCarrinho[]>([]);
  const [clienteId, setClienteId] = useState<string>('');
  const [buscaCliente, setBuscaCliente] = useState('');
  const [pagamentos, setPagamentos] = useState<FormaPag[]>([]);
  const [valorRecebido, setValorRecebido] = useState('');
  const [formaPagSel, setFormaPagSel] = useState(FORMAS_PAG[0]);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => { inputRef.current?.focus(); }, []);

  const { data: clientes } = useQuery({
    queryKey: ['clientes-pdv', buscaCliente],
    queryFn: () => clientesApi.listar({ busca: buscaCliente }).then(r => r.data.items),
    enabled: buscaCliente.length > 1,
  });

  const totalCarrinho = carrinho.reduce((s, i) => s + i.total, 0);
  const totalPago     = pagamentos.reduce((s, p) => s + p.valor, 0);
  const troco         = totalPago - totalCarrinho;

  async function buscarProduto() {
    if (!busca.trim()) return;
    try {
      const { data } = await produtosApi.buscarPorCodigo(busca);
      adicionarItem(data);
      setBusca('');
    } catch {
      toast.error(`Produto "${busca}" não encontrado!`);
    }
    inputRef.current?.focus();
  }

  function adicionarItem(prod: { id: string; sku: string; descricao: string; precoVenda: number }) {
    setCarrinho(prev => {
      const ex = prev.find(i => i.produtoId === prod.id);
      if (ex) return prev.map(i =>
        i.produtoId === prod.id
          ? { ...i, quantidade: i.quantidade + 1, total: (i.quantidade + 1) * i.precoUnitario * (1 - i.descontoPercentual / 100) }
          : i
      );
      return [...prev, {
        produtoId: prod.id, sku: prod.sku, descricao: prod.descricao,
        quantidade: 1, precoUnitario: prod.precoVenda, descontoPercentual: 0,
        total: prod.precoVenda
      }];
    });
  }

  function removerItem(id: string) { setCarrinho(p => p.filter(i => i.produtoId !== id)); }
  function alterarQtd(id: string, q: number) {
    if (q <= 0) { removerItem(id); return; }
    setCarrinho(p => p.map(i => i.produtoId === id
      ? { ...i, quantidade: q, total: q * i.precoUnitario * (1 - i.descontoPercentual / 100) } : i
    ));
  }

  function adicionarPagamento() {
    const v = parseFloat(valorRecebido.replace(',', '.')) || 0;
    if (v <= 0) return;
    setPagamentos(prev => [...prev, { formaPagamento: formaPagSel.label, codigoNfe: formaPagSel.codigo, valor: v, parcelas: 1 }]);
    setValorRecebido('');
  }

  const vendaMutation = useMutation({
    mutationFn: (data: unknown) => vendasApi.criar(data),
    onSuccess: (res) => {
      toast.success(`✅ Venda #${res.data.numero} finalizada! Total: ${fmtBRL(res.data.valorTotal)}`);
      setCarrinho([]);
      setPagamentos([]);
      setClienteId('');
    },
    onError: () => toast.error('Erro ao finalizar venda. Verifique a conexão com a API.'),
  });

  function finalizarVenda() {
    if (carrinho.length === 0) { toast.error('Carrinho vazio!'); return; }
    if (totalPago < totalCarrinho) { toast.error('Valor pago insuficiente!'); return; }
    vendaMutation.mutate({
      clienteId: clienteId || '00000000-0000-0000-0000-000000000000',
      tipo: 'PDV',
      itens: carrinho.map(i => ({
        produtoId: i.produtoId, quantidade: i.quantidade,
        precoUnitario: i.precoUnitario, descontoPercentual: i.descontoPercentual
      })),
      pagamentos,
    });
  }

  return (
    <div>
      <div className="flex-between mb-16">
        <div>
          <p className="section-title">PDV — Ponto de Venda</p>
          <p className="section-subtitle">Balcão de atendimento</p>
        </div>
      </div>

      <div className="pdv-layout">
        {/* Painel Esquerdo — Produtos */}
        <div className="pdv-cart">
          {/* Busca de produto */}
          <div className="pdv-search-bar">
            <div style={{ display: 'flex', gap: 8 }}>
              <div className="search-wrap" style={{ flex: 1 }}>
                <Search size={16} />
                <input
                  ref={inputRef}
                  className="form-control"
                  placeholder="Digite código de barras, SKU ou nome..."
                  value={busca}
                  onChange={e => setBusca(e.target.value)}
                  onKeyDown={e => e.key === 'Enter' && buscarProduto()}
                />
              </div>
              <button className="btn btn-primary" onClick={buscarProduto}>
                <Search size={16} />
              </button>
            </div>
            {/* Cliente */}
            <div style={{ marginTop: 10, display: 'flex', gap: 8 }}>
              <div className="search-wrap" style={{ flex: 1 }}>
                <Search size={16} />
                <input
                  className="form-control"
                  placeholder="Buscar cliente (opcional)..."
                  value={buscaCliente}
                  onChange={e => setBuscaCliente(e.target.value)}
                />
              </div>
            </div>
            {clientes && clientes.length > 0 && buscaCliente && (
              <div style={{
                background: 'var(--bg-surface)', border: '1px solid var(--border)',
                borderRadius: 'var(--radius-sm)', marginTop: 4, boxShadow: 'var(--shadow)'
              }}>
                {clientes.slice(0, 5).map((c: {id: string; nomeRazao: string; cpfCnpj: string}) => (
                  <div key={c.id} style={{ padding: '8px 12px', cursor: 'pointer', fontSize: 13 }}
                    onClick={() => { setClienteId(c.id); setBuscaCliente(c.nomeRazao); }}>
                    <strong>{c.nomeRazao}</strong> — {c.cpfCnpj}
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Itens do carrinho */}
          <div className="pdv-items">
            {carrinho.length === 0 ? (
              <div className="empty-state" style={{ paddingTop: 40 }}>
                <ShoppingCart size={40} />
                <p>Escaneie ou digite o código do produto</p>
              </div>
            ) : (
              carrinho.map(item => (
                <div className="pdv-item" key={item.produtoId}>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ fontSize: 13, fontWeight: 600, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{item.descricao}</div>
                    <div style={{ fontSize: 11, color: 'var(--text-muted)' }}>{item.sku} — {fmtBRL(item.precoUnitario)}/un</div>
                  </div>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                    <button className="btn btn-outline btn-sm" onClick={() => alterarQtd(item.produtoId, item.quantidade - 1)}>-</button>
                    <span style={{ width: 30, textAlign: 'center', fontSize: 14, fontWeight: 700 }}>{item.quantidade}</span>
                    <button className="btn btn-outline btn-sm" onClick={() => alterarQtd(item.produtoId, item.quantidade + 1)}>+</button>
                  </div>
                  <div style={{ minWidth: 70, textAlign: 'right', fontSize: 14, fontWeight: 700, color: 'var(--primary)' }}>
                    {fmtBRL(item.total)}
                  </div>
                  <button className="btn btn-danger btn-sm" onClick={() => removerItem(item.produtoId)}>
                    <Trash2 size={13} />
                  </button>
                </div>
              ))
            )}
          </div>

          {/* Totais */}
          <div className="pdv-totals">
            <div className="pdv-total-row"><span>Subtotal</span><span>{fmtBRL(totalCarrinho)}</span></div>
            <div className="pdv-total-row"><span>Desconto</span><span>R$ 0,00</span></div>
            <div className="pdv-total-final"><span>TOTAL</span><span>{fmtBRL(totalCarrinho)}</span></div>
            <div style={{ display: 'flex', gap: 8, marginTop: 12 }}>
              <button className="btn btn-outline" style={{ flex: 1 }} onClick={() => setCarrinho([])}>
                <X size={14} /> Limpar
              </button>
              <button className="btn btn-primary" style={{ flex: 2 }} disabled={carrinho.length === 0}>
                <CheckCircle size={14} /> Finalizar Venda
              </button>
            </div>
          </div>
        </div>

        {/* Painel Direito — Pagamento */}
        <div className="pdv-cart">
          <div style={{ padding: '16px', borderBottom: '1px solid var(--border)' }}>
            <div style={{ fontSize: 15, fontWeight: 700 }}>💳 Pagamento</div>
          </div>
          <div style={{ flex: 1, padding: 16, overflow: 'auto' }}>
            {/* Forma de pagamento */}
            <div className="form-group">
              <label className="form-label">Forma de Pagamento</label>
              <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
                {FORMAS_PAG.map(f => (
                  <button key={f.codigo} className={`btn btn-sm ${formaPagSel.codigo === f.codigo ? 'btn-primary' : 'btn-outline'}`}
                    onClick={() => setFormaPagSel(f)}>
                    {f.label}
                  </button>
                ))}
              </div>
            </div>
            <div style={{ display: 'flex', gap: 8, marginBottom: 16 }}>
              <input className="form-control" placeholder="Valor recebido" value={valorRecebido}
                onChange={e => setValorRecebido(e.target.value)}
                onKeyDown={e => e.key === 'Enter' && adicionarPagamento()}
              />
              <button className="btn btn-success btn-sm" onClick={adicionarPagamento}><Plus size={14} /></button>
            </div>

            {pagamentos.map((p, i) => (
              <div key={i} style={{ display: 'flex', justifyContent: 'space-between', padding: '6px 0', fontSize: 13 }}>
                <span>{p.formaPagamento}</span>
                <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
                  <strong>{fmtBRL(p.valor)}</strong>
                  <button className="btn btn-danger btn-sm" onClick={() => setPagamentos(prev => prev.filter((_, j) => j !== i))}>
                    <X size={11} />
                  </button>
                </div>
              </div>
            ))}

            <div className="divider" />

            <div className="pdv-total-row"><span>Total</span><strong>{fmtBRL(totalCarrinho)}</strong></div>
            <div className="pdv-total-row"><span>Pago</span><strong style={{ color: 'var(--success)' }}>{fmtBRL(totalPago)}</strong></div>
            {troco > 0 && (
              <div className="pdv-total-row" style={{ color: 'var(--success)', fontWeight: 700, fontSize: 16 }}>
                <span>TROCO</span><strong>{fmtBRL(troco)}</strong>
              </div>
            )}
            {totalPago < totalCarrinho && totalPago > 0 && (
              <div className="pdv-total-row" style={{ color: 'var(--danger)' }}>
                <span>Falta</span><strong>{fmtBRL(totalCarrinho - totalPago)}</strong>
              </div>
            )}
          </div>

          <div style={{ padding: 16 }}>
            <button className="btn btn-success" style={{ width: '100%', padding: '14px' }}
              onClick={finalizarVenda}
              disabled={vendaMutation.isPending || carrinho.length === 0 || totalPago < totalCarrinho}>
              {vendaMutation.isPending ? <div className="spinner" /> : <><CheckCircle size={16} /> Confirmar Venda</>}
            </button>
            <button className="btn btn-outline" style={{ width: '100%', marginTop: 8 }}>
              <Printer size={14} /> Imprimir / NFC-e
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
