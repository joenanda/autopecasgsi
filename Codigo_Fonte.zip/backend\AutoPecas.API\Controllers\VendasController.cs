using AutoPecas.Domain.Entities;
using AutoPecas.Fiscal.Services;
using AutoPecas.Infrastructure.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace AutoPecas.API.Controllers;

[ApiController]
[Route("api/[controller]")]
[Produces("application/json")]
public class VendasController : ControllerBase
{
    private readonly AutoPecasDbContext _db;
    private readonly MotorImpostosService _motor;
    private readonly ILogger<VendasController> _logger;

    public VendasController(AutoPecasDbContext db, MotorImpostosService motor, ILogger<VendasController> logger)
    {
        _db = db; _motor = motor; _logger = logger;
    }

    // GET /api/vendas — lista pedidos
    [HttpGet]
    public async Task<IActionResult> Listar(
        [FromQuery] string? status, [FromQuery] DateTime? de, [FromQuery] DateTime? ate,
        [FromQuery] int pagina = 1, [FromQuery] int tamanho = 30)
    {
        var q = _db.Set<PedidoVenda>().Include(p => p.Cliente).AsNoTracking();
        if (!string.IsNullOrEmpty(status)) q = q.Where(p => p.Status == status.ToUpper());
        if (de.HasValue)  q = q.Where(p => p.DataPedido >= de.Value);
        if (ate.HasValue) q = q.Where(p => p.DataPedido <= ate.Value.AddDays(1));
        var total = await q.CountAsync();
        var items = await q.OrderByDescending(p => p.DataPedido)
            .Skip((pagina - 1) * tamanho).Take(tamanho)
            .Select(p => new {
                p.Id, p.Numero, p.Tipo, p.Status, p.DataPedido,
                p.ValorTotal, Cliente = p.Cliente != null ? p.Cliente.NomeRazao : ""
            }).ToListAsync();
        return Ok(new { items, total, pagina, tamanho });
    }

    // GET /api/vendas/{id} — detalhe
    [HttpGet("{id:guid}")]
    public async Task<IActionResult> ObterPorId(Guid id)
    {
        var p = await _db.Set<PedidoVenda>()
            .Include(x => x.Cliente)
            .Include(x => x.Itens).ThenInclude(i => i.Produto)
            .Include(x => x.Pagamentos)
            .AsNoTracking().FirstOrDefaultAsync(x => x.Id == id);
        return p == null ? NotFound() : Ok(p);
    }

    // POST /api/vendas — criar pedido/venda PDV
    [HttpPost]
    public async Task<IActionResult> Criar([FromBody] CriarPedidoRequest req)
    {
        var cliente = await _db.Set<Cliente>().FindAsync(req.ClienteId);
        if (cliente == null) return BadRequest(new { mensagem = "Cliente não encontrado." });

        var pedido = new PedidoVenda
        {
            Tipo      = req.Tipo ?? "PDV",
            Status    = "APROVADO",
            ClienteId = req.ClienteId,
            Observacao = req.Observacao
        };

        short seq = 0;
        decimal totalProdutos = 0, totalSt = 0, totalIpi = 0, totalDesconto = 0;

        foreach (var itemReq in req.Itens)
        {
            var produto = await _db.Produtos.FindAsync(itemReq.ProdutoId);
            if (produto == null) continue;

            var imposto = _motor.CalcularImpostosItem(
                produto, itemReq.Quantidade, itemReq.PrecoUnitario,
                itemReq.DescontoPercentual, req.UfDestino ?? "SP",
                cliente.ContribuinteIcms);

            seq++;
            var item = new ItemPedidoVenda
            {
                PedidoId         = pedido.Id,
                ProdutoId        = produto.Id,
                Sequencia        = seq,
                Descricao        = produto.Descricao,
                Ncm              = produto.Ncm,
                Cest             = produto.Cest,
                UnidadeMedida    = produto.UnidadeMedida,
                Quantidade       = imposto.Quantidade,
                PrecoUnitario    = imposto.PrecoUnitario,
                DescontoPercentual = itemReq.DescontoPercentual,
                DescontoValor    = imposto.ValorDesconto,
                ValorTotal       = imposto.ValorProduto,
                Csosn            = imposto.Csosn,
                Cfop             = imposto.Cfop,
                ValorSt          = imposto.ValorSt,
                ValorIpi         = imposto.ValorIpi,
                ValorPis         = imposto.ValorPis,
                ValorCofins      = imposto.ValorCofins
            };
            pedido.Itens.Add(item);
            totalProdutos += imposto.ValorProduto;
            totalSt       += imposto.ValorSt;
            totalIpi      += imposto.ValorIpi;
            totalDesconto += imposto.ValorDesconto;
        }

        pedido.ValorProdutos = totalProdutos;
        pedido.ValorDesconto = totalDesconto;
        pedido.ValorTotal    = totalProdutos + totalSt + totalIpi + (req.ValorFrete ?? 0);
        pedido.ValorFrete    = req.ValorFrete ?? 0;

        // Pagamentos
        foreach (var pag in req.Pagamentos)
        {
            pedido.Pagamentos.Add(new PagamentoPedido
            {
                PedidoId      = pedido.Id,
                FormaPagamento = pag.FormaPagamento,
                CodigoNfe     = pag.CodigoNfe ?? "01",
                Valor         = pag.Valor,
                Parcelas      = pag.Parcelas,
                Status        = "CONFIRMADO",
                ConfirmadoEm  = DateTime.UtcNow
            });
        }

        _db.Set<PedidoVenda>().Add(pedido);

        // Baixa de estoque
        foreach (var item in pedido.Itens)
        {
            var saldo = await _db.EstoqueSaldos.FirstOrDefaultAsync(s => s.ProdutoId == item.ProdutoId);
            if (saldo != null) saldo.Quantidade -= item.Quantidade;
        }

        // Gera conta a receber (se não for à vista)
        var totalPago = pedido.Pagamentos.Sum(p => p.Valor);
        if (totalPago < pedido.ValorTotal)
        {
            var cr = new ContaReceber
            {
                ClienteId     = pedido.ClienteId,
                PedidoId      = pedido.Id,
                Descricao     = $"Venda #{pedido.Numero}",
                ValorOriginal = pedido.ValorTotal - totalPago,
                DataVencimento = DateOnly.FromDateTime(DateTime.Today.AddDays(30)),
                Status        = "ABERTO"
            };
            _db.Set<ContaReceber>().Add(cr);
        }

        await _db.SaveChangesAsync();
        _logger.LogInformation("Pedido #{Numero} criado. Total: R$ {Total:N2}", pedido.Numero, pedido.ValorTotal);
        return CreatedAtAction(nameof(ObterPorId), new { id = pedido.Id }, new { pedido.Id, pedido.Numero, pedido.ValorTotal });
    }

    // POST /api/vendas/{id}/cancelar
    [HttpPost("{id:guid}/cancelar")]
    public async Task<IActionResult> Cancelar(Guid id, [FromBody] CancelarRequest req)
    {
        var pedido = await _db.Set<PedidoVenda>()
            .Include(p => p.Itens).FirstOrDefaultAsync(p => p.Id == id);
        if (pedido == null) return NotFound();
        if (pedido.Status == "CANCELADO") return BadRequest(new { mensagem = "Pedido já cancelado." });
        if (pedido.Status == "FATURADO")  return BadRequest(new { mensagem = "Pedido faturado. Cancele a NF-e primeiro." });

        pedido.Status = "CANCELADO";
        pedido.AtualizadoEm = DateTime.UtcNow;

        // Estorno de estoque
        foreach (var item in pedido.Itens)
        {
            var saldo = await _db.EstoqueSaldos.FirstOrDefaultAsync(s => s.ProdutoId == item.ProdutoId);
            if (saldo != null) saldo.Quantidade += item.Quantidade;
        }
        await _db.SaveChangesAsync();
        return Ok(new { mensagem = "Pedido cancelado com sucesso." });
    }

    // GET /api/vendas/dashboard — resumo do dia
    [HttpGet("dashboard")]
    public async Task<IActionResult> Dashboard()
    {
        var hoje = DateTime.Today;
        var amanha = hoje.AddDays(1);
        var mesInicio = new DateTime(hoje.Year, hoje.Month, 1);

        var vendasHoje = await _db.Set<PedidoVenda>()
            .Where(p => p.DataPedido >= hoje && p.DataPedido < amanha && p.Status != "CANCELADO")
            .Select(p => new { p.ValorTotal }).ToListAsync();

        var vendasMes = await _db.Set<PedidoVenda>()
            .Where(p => p.DataPedido >= mesInicio && p.Status != "CANCELADO")
            .Select(p => new { p.ValorTotal }).ToListAsync();

        var contasVencer = await _db.Set<ContaReceber>()
            .Where(c => c.Status == "ABERTO" && c.DataVencimento <= DateOnly.FromDateTime(hoje.AddDays(7)))
            .CountAsync();

        var produtosSemEstoque = await _db.EstoqueSaldos
            .Where(s => s.Quantidade <= 0).CountAsync();

        return Ok(new
        {
            vendasHoje   = new { qtd = vendasHoje.Count, valor = vendasHoje.Sum(v => v.ValorTotal) },
            vendasMes    = new { qtd = vendasMes.Count, valor = vendasMes.Sum(v => v.ValorTotal) },
            contasVencer,
            produtosSemEstoque
        });
    }
}

// ---- DTOs ----
public record CriarPedidoRequest
{
    public Guid ClienteId { get; init; }
    public string? Tipo { get; init; }
    public string? UfDestino { get; init; }
    public decimal? ValorFrete { get; init; }
    public string? Observacao { get; init; }
    public List<ItemPedidoReq> Itens { get; init; } = [];
    public List<PagamentoReq> Pagamentos { get; init; } = [];
}
public record ItemPedidoReq
{
    public Guid ProdutoId { get; init; }
    public decimal Quantidade { get; init; }
    public decimal PrecoUnitario { get; init; }
    public decimal DescontoPercentual { get; init; }
}
public record PagamentoReq
{
    public string FormaPagamento { get; init; } = string.Empty;
    public string? CodigoNfe { get; init; }
    public decimal Valor { get; init; }
    public short Parcelas { get; init; } = 1;
}
public record CancelarRequest { public string? Motivo { get; init; } }
