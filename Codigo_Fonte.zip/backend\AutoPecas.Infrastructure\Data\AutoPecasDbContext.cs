using AutoPecas.Domain.Entities;
using Microsoft.EntityFrameworkCore;

namespace AutoPecas.Infrastructure.Data;

/// <summary>
/// DbContext principal do ERP Auto Peças.
/// Mapeado para o PostgreSQL com schemas separados por módulo.
/// </summary>
public class AutoPecasDbContext : DbContext
{
    public AutoPecasDbContext(DbContextOptions<AutoPecasDbContext> options) : base(options) { }

    // =========================================================
    //  DbSets — Cadastros Base / Segurança
    // =========================================================
    public DbSet<Empresa> Empresas => Set<Empresa>();
    public DbSet<CertificadoDigital> CertificadosDigitais => Set<CertificadoDigital>();
    public DbSet<Usuario> Usuarios => Set<Usuario>();
    public DbSet<Licenca> Licencas => Set<Licenca>();

    // =========================================================
    //  DbSets — Vendas
    // =========================================================
    public DbSet<Cliente> Clientes => Set<Cliente>();
    public DbSet<Fornecedor> Fornecedores => Set<Fornecedor>();
    public DbSet<PedidoVenda> Pedidos => Set<PedidoVenda>();
    public DbSet<ItemPedidoVenda> ItensPedido => Set<ItemPedidoVenda>();
    public DbSet<PagamentoPedido> PagamentosPedido => Set<PagamentoPedido>();

    // =========================================================
    //  DbSets — Fiscal
    // =========================================================
    public DbSet<NotaFiscal> NotasFiscais => Set<NotaFiscal>();
    public DbSet<ItemNotaFiscal> ItensNfe => Set<ItemNotaFiscal>();

    // =========================================================
    //  DbSets — Financeiro
    // =========================================================
    public DbSet<ContaReceber> ContasReceber => Set<ContaReceber>();
    public DbSet<ContaPagar> ContasPagar => Set<ContaPagar>();
    public DbSet<Caixa> Caixas => Set<Caixa>();
    public DbSet<MovimentoCaixa> MovimentosCaixa => Set<MovimentoCaixa>();

    // =========================================================
    //  DbSets — Estoque
    // =========================================================
    public DbSet<Categoria> Categorias => Set<Categoria>();
    public DbSet<Produto> Produtos => Set<Produto>();
    public DbSet<ProdutoCodigoEquivalente> ProdutoCodigosEquivalentes => Set<ProdutoCodigoEquivalente>();
    public DbSet<MarcaVeiculo> MarcasVeiculo => Set<MarcaVeiculo>();
    public DbSet<ModeloVeiculo> ModelosVeiculo => Set<ModeloVeiculo>();
    public DbSet<ProdutoAplicacao> ProdutoAplicacoes => Set<ProdutoAplicacao>();
    public DbSet<EstoqueLocalizacao> EstoqueLocalizacoes => Set<EstoqueLocalizacao>();
    public DbSet<EstoqueSaldo> EstoqueSaldos => Set<EstoqueSaldo>();

    // =========================================================
    //  Fluent API
    // =========================================================
    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        base.OnModelCreating(modelBuilder);

        // Schemas separados por módulo
        modelBuilder.Entity<Empresa>().ToTable("empresas");
        modelBuilder.Entity<CertificadoDigital>().ToTable("certificados_digitais", schema: "fiscal");
        modelBuilder.Entity<Categoria>().ToTable("categorias", schema: "estoque");
        modelBuilder.Entity<Produto>().ToTable("produtos", schema: "estoque");
        modelBuilder.Entity<ProdutoCodigoEquivalente>().ToTable("produto_codigos_equivalentes", schema: "estoque");
        modelBuilder.Entity<MarcaVeiculo>().ToTable("marcas_veiculo", schema: "estoque");
        modelBuilder.Entity<ModeloVeiculo>().ToTable("modelos_veiculo", schema: "estoque");
        modelBuilder.Entity<ProdutoAplicacao>().ToTable("produto_aplicacoes", schema: "estoque");
        modelBuilder.Entity<EstoqueLocalizacao>().ToTable("localizacoes", schema: "estoque");
        modelBuilder.Entity<EstoqueSaldo>().ToTable("saldos", schema: "estoque");
        // Vendas
        modelBuilder.Entity<Cliente>().ToTable("clientes", schema: "vendas");
        modelBuilder.Entity<Fornecedor>().ToTable("fornecedores", schema: "estoque");
        modelBuilder.Entity<PedidoVenda>().ToTable("pedidos", schema: "vendas");
        modelBuilder.Entity<ItemPedidoVenda>().ToTable("itens_pedido", schema: "vendas");
        modelBuilder.Entity<PagamentoPedido>().ToTable("pagamentos_pedido", schema: "vendas");
        // Fiscal
        modelBuilder.Entity<NotaFiscal>().ToTable("notas_fiscais", schema: "fiscal");
        modelBuilder.Entity<ItemNotaFiscal>().ToTable("itens_nota_fiscal", schema: "fiscal");
        // Financeiro
        modelBuilder.Entity<ContaReceber>().ToTable("contas_receber", schema: "financeiro");
        modelBuilder.Entity<ContaPagar>().ToTable("contas_pagar", schema: "financeiro");
        modelBuilder.Entity<Caixa>().ToTable("caixas", schema: "financeiro");
        modelBuilder.Entity<MovimentoCaixa>().ToTable("movimentos_caixa", schema: "financeiro");

        // ---- Relacionamentos Vendas ----
        modelBuilder.Entity<PedidoVenda>(e => {
            e.HasKey(x => x.Id);
            e.Property(x => x.ValorTotal).HasPrecision(14, 2);
            e.HasOne(x => x.Cliente).WithMany().HasForeignKey(x => x.ClienteId);
            e.HasMany(x => x.Itens).WithOne(x => x.Pedido).HasForeignKey(x => x.PedidoId).OnDelete(DeleteBehavior.Cascade);
            e.HasMany(x => x.Pagamentos).WithOne(x => x.Pedido).HasForeignKey(x => x.PedidoId).OnDelete(DeleteBehavior.Cascade);
        });
        modelBuilder.Entity<Cliente>(e => { e.HasKey(x => x.Id); e.Property(x => x.NomeRazao).HasMaxLength(150).IsRequired(); });
        modelBuilder.Entity<Fornecedor>(e => { e.HasKey(x => x.Id); e.HasIndex(x => x.CnpjCpf).IsUnique(); });
        modelBuilder.Entity<ContaReceber>(e => { e.HasKey(x => x.Id); e.Ignore(x => x.Saldo); e.HasOne(x => x.Cliente).WithMany().HasForeignKey(x => x.ClienteId).IsRequired(false); });
        modelBuilder.Entity<ContaPagar>(e => { e.HasKey(x => x.Id); e.Ignore(x => x.Saldo); e.HasOne(x => x.Fornecedor).WithMany().HasForeignKey(x => x.FornecedorId).IsRequired(false); });
        modelBuilder.Entity<Caixa>(e => { e.HasKey(x => x.Id); e.HasIndex(x => x.Nome).IsUnique(); });
        modelBuilder.Entity<MovimentoCaixa>(e => { e.HasKey(x => x.Id); e.HasOne(x => x.Caixa).WithMany().HasForeignKey(x => x.CaixaId); });
        modelBuilder.Entity<NotaFiscal>(e => { e.HasKey(x => x.Id); e.HasMany(x => x.Itens).WithOne(x => x.NotaFiscal).HasForeignKey(x => x.NotaFiscalId).OnDelete(DeleteBehavior.Cascade); });
        modelBuilder.Entity<ItemNotaFiscal>(e => { e.HasKey(x => x.Id); });

        // ---- Empresa ----
        modelBuilder.Entity<Empresa>(e =>
        {
            e.HasKey(x => x.Id);
            e.Property(x => x.Cnpj).HasMaxLength(14).IsRequired();
            e.HasIndex(x => x.Cnpj).IsUnique();
            e.Property(x => x.RazaoSocial).HasMaxLength(150).IsRequired();
            e.Property(x => x.Uf).HasMaxLength(2).HasDefaultValue("SP");
        });

        // ---- CertificadoDigital ----
        modelBuilder.Entity<CertificadoDigital>(e =>
        {
            e.HasKey(x => x.Id);
            e.Property(x => x.Thumbprint).HasMaxLength(40).IsRequired();
            e.Property(x => x.Tipo).HasConversion<string>();
            e.HasIndex(x => new { x.EmpresaId, x.Thumbprint }).IsUnique();
            e.HasOne(x => x.Empresa)
                .WithMany(x => x.Certificados)
                .HasForeignKey(x => x.EmpresaId);
        });

        // ---- Categoria (auto-referência) ----
        modelBuilder.Entity<Categoria>(e =>
        {
            e.HasKey(x => x.Id);
            e.HasOne(x => x.Pai)
                .WithMany(x => x.Subcategorias)
                .HasForeignKey(x => x.PaiId)
                .IsRequired(false);
        });

        // ---- Produto ----
        modelBuilder.Entity<Produto>(e =>
        {
            e.HasKey(x => x.Id);
            e.Property(x => x.Sku).HasMaxLength(50).IsRequired();
            e.HasIndex(x => x.Sku).IsUnique();
            e.Property(x => x.CodigoBarras).HasMaxLength(30);
            e.Property(x => x.Descricao).HasMaxLength(200).IsRequired();
            e.Property(x => x.Ncm).HasMaxLength(8).HasDefaultValue("87089990");
            e.Property(x => x.UnidadeMedida).HasMaxLength(6).HasDefaultValue("PC");
            e.Property(x => x.PrecoVenda).HasPrecision(12, 2);
            e.Property(x => x.PrecoCusto).HasPrecision(12, 4);
            e.Property(x => x.PrecoCustoMedio).HasPrecision(12, 4);
            e.Property(x => x.EstoqueMinimo).HasPrecision(10, 3);
            e.Property(x => x.EstoqueMaximo).HasPrecision(10, 3);
            e.HasOne(x => x.Categoria)
                .WithMany(x => x.Produtos)
                .HasForeignKey(x => x.CategoriaId)
                .IsRequired(false);
            e.HasMany(x => x.CodigosEquivalentes)
                .WithOne(x => x.Produto)
                .HasForeignKey(x => x.ProdutoId)
                .OnDelete(DeleteBehavior.Cascade);
            e.HasMany(x => x.Aplicacoes)
                .WithOne(x => x.Produto)
                .HasForeignKey(x => x.ProdutoId)
                .OnDelete(DeleteBehavior.Cascade);
            e.HasMany(x => x.Saldos)
                .WithOne(x => x.Produto)
                .HasForeignKey(x => x.ProdutoId);
        });

        // ---- ProdutoCodigoEquivalente ----
        modelBuilder.Entity<ProdutoCodigoEquivalente>(e =>
        {
            e.HasKey(x => x.Id);
            e.HasIndex(x => x.Codigo);
            e.HasIndex(x => new { x.ProdutoId, x.Tipo, x.Codigo }).IsUnique();
        });

        // ---- EstoqueSaldo ----
        modelBuilder.Entity<EstoqueSaldo>(e =>
        {
            e.HasKey(x => x.Id);
            e.HasIndex(x => new { x.ProdutoId, x.LocalizacaoId }).IsUnique();
            e.Property(x => x.Quantidade).HasPrecision(12, 3);
            e.Property(x => x.CustoMedio).HasPrecision(12, 4);
        });
    }
}
