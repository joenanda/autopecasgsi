using AutoPecas.Domain.Entities;
using AutoPecas.Infrastructure.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace AutoPecas.API.Controllers;

[ApiController]
[Route("api/[controller]")]
[Produces("application/json")]
public class FinanceiroController : ControllerBase
{
    private readonly AutoPecasDbContext _db;
    public FinanceiroController(AutoPecasDbContext db) => _db = db;

    // ===== CONTAS A RECEBER =====
    [HttpGet("receber")]
    public async Task<IActionResult> ListarReceber(
        [FromQuery] string? status, [FromQuery] DateTime? vencDe, [FromQuery] DateTime? vencAte,
        [FromQuery] int pagina = 1, [FromQuery] int tamanho = 30)
    {
        var q = _db.Set<ContaReceber>().Include(c => c.Cliente).AsNoTracking();
        if (!string.IsNullOrEmpty(status)) q = q.Where(c => c.Status == status.ToUpper());
        if (vencDe.HasValue)  q = q.Where(c => c.DataVencimento >= DateOnly.FromDateTime(vencDe.Value));
        if (vencAte.HasValue) q = q.Where(c => c.DataVencimento <= DateOnly.FromDateTime(vencAte.Value));
        // Auto-marcar vencidos
        var total = await q.CountAsync();
        var items = await q.OrderBy(c => c.DataVencimento).Skip((pagina - 1) * tamanho).Take(tamanho).ToListAsync();
        return Ok(new { items, total });
    }

    [HttpPost("receber/{id:guid}/receber")]
    public async Task<IActionResult> ReceberPagamento(Guid id, [FromBody] ReceberPagamentoRequest req)
    {
        var cr = await _db.Set<ContaReceber>().FindAsync(id);
        if (cr == null) return NotFound();
        if (cr.Status == "PAGO") return BadRequest(new { mensagem = "Conta já quitada." });

        var caixa = await _db.Set<Caixa>().FirstOrDefaultAsync(c => c.Ativo);
        cr.ValorPago    += req.ValorPago;
        cr.ValorDesconto = req.Desconto;
        cr.ValorJuros    = req.Juros;
        cr.ValorMulta    = req.Multa;
        cr.DataPagamento = DateOnly.FromDateTime(DateTime.Today);
        cr.FormaPagamento = req.FormaPagamento;
        cr.Status         = cr.Saldo <= 0.01m ? "PAGO" : "PARCIAL";
        cr.AtualizadoEm   = DateTime.UtcNow;

        if (caixa != null)
        {
            var mov = new MovimentoCaixa
            {
                CaixaId       = caixa.Id,
                Tipo          = 'E',
                Valor         = req.ValorPago,
                Descricao     = cr.Descricao,
                SaldoAnterior = caixa.SaldoAtual,
                ContaReceberId = cr.Id
            };
            caixa.SaldoAtual += req.ValorPago;
            mov.SaldoPosterior = caixa.SaldoAtual;
            _db.Set<MovimentoCaixa>().Add(mov);
        }
        await _db.SaveChangesAsync();
        return Ok(new { cr.Status, cr.Saldo });
    }

    // ===== CONTAS A PAGAR =====
    [HttpGet("pagar")]
    public async Task<IActionResult> ListarPagar(
        [FromQuery] string? status, [FromQuery] DateTime? vencDe, [FromQuery] DateTime? vencAte,
        [FromQuery] int pagina = 1, [FromQuery] int tamanho = 30)
    {
        var q = _db.Set<ContaPagar>().Include(c => c.Fornecedor).AsNoTracking();
        if (!string.IsNullOrEmpty(status)) q = q.Where(c => c.Status == status.ToUpper());
        if (vencDe.HasValue)  q = q.Where(c => c.DataVencimento >= DateOnly.FromDateTime(vencDe.Value));
        if (vencAte.HasValue) q = q.Where(c => c.DataVencimento <= DateOnly.FromDateTime(vencAte.Value));
        var total = await q.CountAsync();
        var items = await q.OrderBy(c => c.DataVencimento).Skip((pagina - 1) * tamanho).Take(tamanho).ToListAsync();
        return Ok(new { items, total });
    }

    [HttpPost("pagar")]
    public async Task<IActionResult> CriarContaPagar([FromBody] CriarContaPagarRequest req)
    {
        var cp = new ContaPagar
        {
            FornecedorId    = req.FornecedorId,
            Descricao       = req.Descricao,
            NumeroDocumento = req.NumeroDocumento,
            ValorOriginal   = req.ValorOriginal,
            DataEmissao     = DateOnly.FromDateTime(req.DataEmissao ?? DateTime.Today),
            DataVencimento  = DateOnly.FromDateTime(req.DataVencimento),
            NumeroParcela   = req.NumeroParcela,
            TotalParcelas   = req.TotalParcelas,
            Status          = "ABERTO"
        };
        _db.Set<ContaPagar>().Add(cp);
        await _db.SaveChangesAsync();
        return CreatedAtAction(null, null, cp);
    }

    [HttpPost("pagar/{id:guid}/pagar")]
    public async Task<IActionResult> PagarConta(Guid id, [FromBody] ReceberPagamentoRequest req)
    {
        var cp = await _db.Set<ContaPagar>().FindAsync(id);
        if (cp == null) return NotFound();
        if (cp.Status == "PAGO") return BadRequest(new { mensagem = "Conta já paga." });
        var caixa = await _db.Set<Caixa>().FirstOrDefaultAsync(c => c.Ativo);
        cp.ValorPago += req.ValorPago;
        cp.ValorDesconto = req.Desconto;
        cp.ValorJuros = req.Juros;
        cp.DataPagamento = DateOnly.FromDateTime(DateTime.Today);
        cp.FormaPagamento = req.FormaPagamento;
        cp.Status = cp.Saldo <= 0.01m ? "PAGO" : "PARCIAL";
        cp.AtualizadoEm = DateTime.UtcNow;
        if (caixa != null)
        {
            var mov = new MovimentoCaixa
            {
                CaixaId = caixa.Id, Tipo = 'S', Valor = req.ValorPago,
                Descricao = cp.Descricao, SaldoAnterior = caixa.SaldoAtual,
                ContaPagarId = cp.Id
            };
            caixa.SaldoAtual -= req.ValorPago;
            mov.SaldoPosterior = caixa.SaldoAtual;
            _db.Set<MovimentoCaixa>().Add(mov);
        }
        await _db.SaveChangesAsync();
        return Ok(new { cp.Status, cp.Saldo });
    }

    // ===== CAIXA =====
    [HttpGet("caixa/saldo")]
    public async Task<IActionResult> SaldoCaixa()
    {
        var caixas = await _db.Set<Caixa>().Where(c => c.Ativo).ToListAsync();
        var movimentos = await _db.Set<MovimentoCaixa>()
            .Where(m => m.DataMovimento >= DateTime.Today)
            .OrderByDescending(m => m.DataMovimento).Take(20).ToListAsync();
        return Ok(new { caixas, movimentos });
    }

    // ===== RESUMO FINANCEIRO =====
    [HttpGet("resumo")]
    public async Task<IActionResult> ResumoFinanceiro()
    {
        var hoje = DateOnly.FromDateTime(DateTime.Today);
        var proximos7 = hoje.AddDays(7);
        var totalReceber = await _db.Set<ContaReceber>().Where(c => c.Status == "ABERTO").SumAsync(c => c.ValorOriginal - c.ValorPago);
        var totalPagar   = await _db.Set<ContaPagar>().Where(c => c.Status == "ABERTO").SumAsync(c => c.ValorOriginal - c.ValorPago);
        var vencendoReceber = await _db.Set<ContaReceber>().Where(c => c.Status == "ABERTO" && c.DataVencimento <= proximos7).CountAsync();
        var vencendoPagar   = await _db.Set<ContaPagar>().Where(c => c.Status == "ABERTO" && c.DataVencimento <= proximos7).CountAsync();
        var saldoCaixa = await _db.Set<Caixa>().Where(c => c.Ativo).SumAsync(c => c.SaldoAtual);
        return Ok(new { totalReceber, totalPagar, vencendoReceber, vencendoPagar, saldoCaixa, saldoLiquido = saldoCaixa + totalReceber - totalPagar });
    }
}

public record ReceberPagamentoRequest
{
    public decimal ValorPago { get; init; }
    public decimal Desconto { get; init; }
    public decimal Juros { get; init; }
    public decimal Multa { get; init; }
    public string FormaPagamento { get; init; } = "DINHEIRO";
}
public record CriarContaPagarRequest
{
    public Guid? FornecedorId { get; init; }
    public string Descricao { get; init; } = string.Empty;
    public string? NumeroDocumento { get; init; }
    public decimal ValorOriginal { get; init; }
    public DateTime? DataEmissao { get; init; }
    public DateTime DataVencimento { get; init; }
    public short NumeroParcela { get; init; } = 1;
    public short TotalParcelas { get; init; } = 1;
}
