Set WshShell = CreateObject("WScript.Shell")

' Kill any existing instance of the API
WshShell.Run "cmd /c taskkill /IM AutoPecas.API.exe /F > nul 2>&1", 0, True

' Start the API server silently
WshShell.Run "cmd /c AutoPecas.API.exe --urls=http://localhost:5000", 0, False

' Wait 5 seconds and open the browser
WScript.Sleep 5000
WshShell.Run "http://localhost:5000"
