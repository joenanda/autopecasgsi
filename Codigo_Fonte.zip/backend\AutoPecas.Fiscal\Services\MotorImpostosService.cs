using AutoPecas.Domain.Entities;

namespace AutoPecas.Fiscal.Services;

/// <summary>
/// Motor de cálculo de impostos para SP — Simples Nacional.
/// Calcula ICMS (CSOSN), IPI, PIS, COFINS e ST para itens de pedido/NF-e.
/// </summary>
public class MotorImpostosService
{
    // CFOP padrão para venda dentro do estado (SP → SP)
    public const string CfopVendaInternaConsumidor    = "5102"; // Venda de mercadoria para consumidor final
    public const string CfopVendaInternaContribuinte  = "5101"; // Venda de mercadoria entre contribuintes
    public const string CfopVendaInterestadual        = "6102"; // Venda fora do estado

    /// <summary>
    /// Calcula os impostos de um item para Simples Nacional (SP).
    /// Retorna os valores preenchidos para o XML da NF-e.
    /// </summary>
    public ItemImpostoCalculado CalcularImpostosItem(
        Produto produto,
        decimal quantidade,
        decimal precoUnitario,
        decimal descontoPercentual = 0,
        string ufDestino = "SP",
        bool destinatarioContribuinte = false)
    {
        var valorBruto  = quantidade * precoUnitario;
        var valorDesconto = valorBruto * (descontoPercentual / 100m);
        var valorProduto  = valorBruto - valorDesconto;

        var resultado = new ItemImpostoCalculado
        {
            Quantidade      = quantidade,
            PrecoUnitario   = precoUnitario,
            ValorDesconto   = valorDesconto,
            ValorProduto    = valorProduto,
            Cfop            = DeterminarCfop(ufDestino, destinatarioContribuinte),
            Csosn           = produto.CstIcmsSn,
            Origem          = produto.Origem,
        };

        // ---- ICMS Simples Nacional ----
        // CSOSN 400 / 500: Tributado pelo Simples, sem destacar ICMS na NF
        // CSOSN 102 / 103: Não tributado / imune / isento
        // A maioria das peças em SP para consumidor = CSOSN 400
        resultado.BaseCalculoIcms = 0;
        resultado.AliquotaIcms    = 0;
        resultado.ValorIcms       = 0;

        // ---- Substituição Tributária (ST) ----
        if (produto.TemSt && produto.MvaSt.HasValue && ufDestino == "SP")
        {
            var baseCalcSt = valorProduto * (1 + produto.MvaSt.Value / 100m);
            var aliqIcmsSt = 0.12m; // Alíquota interna SP para autopeças (12%)
            var valorIcmsSt = baseCalcSt * aliqIcmsSt;

            // Para Simples Nacional, o valor da ST é apenas a diferença
            resultado.BaseCalculoSt  = Math.Round(baseCalcSt, 2);
            resultado.AliquotaSt     = aliqIcmsSt * 100; // Em percentual
            resultado.ValorSt        = Math.Round(valorIcmsSt, 2);
            resultado.Csosn          = "500"; // Cobrado anteriormente por ST
        }

        // ---- IPI ----
        if (produto.AliquotaIpi > 0)
        {
            resultado.CstIpi           = produto.CstIpi;
            resultado.BaseCalculoIpi   = valorProduto;
            resultado.AliquotaIpi      = produto.AliquotaIpi * 100; // Percentual
            resultado.ValorIpi         = Math.Round(valorProduto * produto.AliquotaIpi, 2);
        }
        else
        {
            resultado.CstIpi = "53"; // Saída não tributada (sem IPI)
        }

        // ---- PIS / COFINS (Simples Nacional: CST 07 = operação sem incidência) ----
        resultado.CstPis      = produto.CstPis;
        resultado.CstCofins   = produto.CstCofins;
        resultado.ValorPis    = 0;
        resultado.ValorCofins = 0;

        // ---- Valor aproximado de tributos (Lei 12.741 / De Olho no Imposto) ----
        // Estimativa: ~8,35% para autopeças no Simples Nacional
        resultado.ValorTributosAprox = Math.Round(valorProduto * 0.0835m, 2);

        return resultado;
    }

    private static string DeterminarCfop(string ufDestino, bool contribuinte)
    {
        var isInterestadual = ufDestino.ToUpper() != "SP";
        if (isInterestadual) return "6102";
        return contribuinte ? CfopVendaInternaContribuinte : CfopVendaInternaConsumidor;
    }
}

/// <summary>DTO com os valores de impostos calculados para um item.</summary>
public class ItemImpostoCalculado
{
    public decimal Quantidade       { get; set; }
    public decimal PrecoUnitario    { get; set; }
    public decimal ValorDesconto    { get; set; }
    public decimal ValorProduto     { get; set; }
    public string  Cfop             { get; set; } = "5102";
    // ICMS
    public string  Csosn            { get; set; } = "400";
    public int     Origem           { get; set; }
    public decimal BaseCalculoIcms  { get; set; }
    public decimal AliquotaIcms     { get; set; }
    public decimal ValorIcms        { get; set; }
    // ST
    public decimal BaseCalculoSt    { get; set; }
    public decimal AliquotaSt       { get; set; }
    public decimal ValorSt          { get; set; }
    // IPI
    public string? CstIpi           { get; set; }
    public decimal BaseCalculoIpi   { get; set; }
    public decimal AliquotaIpi      { get; set; }
    public decimal ValorIpi         { get; set; }
    // PIS / COFINS
    public string? CstPis           { get; set; } = "07";
    public string? CstCofins        { get; set; } = "07";
    public decimal ValorPis         { get; set; }
    public decimal ValorCofins      { get; set; }
    // Tributos aprox. (Lei 12.741)
    public decimal ValorTributosAprox { get; set; }
}
