import { BrowserRouter, Routes, Route, NavLink, useLocation, Navigate } from 'react-router-dom';
import { Toaster } from 'react-hot-toast';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import {
  LayoutDashboard, Package, ShoppingCart, FileText,
  DollarSign, Settings, Wrench, ChevronRight, LogOut
} from 'lucide-react';

import Dashboard from './pages/Dashboard';
import Estoque from './pages/Estoque';
import PDV from './pages/PDV';
import Clientes from './pages/Clientes';
import Financeiro from './pages/Financeiro';
import NotasFiscais from './pages/NotasFiscais';
import Configuracoes from './pages/Configuracoes';
import Login from './pages/Login';
import Ativacao from './pages/Ativacao';
import { AuthProvider, useAuth } from './contexts/AuthContext';

const qc = new QueryClient({ defaultOptions: { queries: { retry: 1, staleTime: 30000 } } });

const navGroups = [
  {
    label: 'Principal',
    items: [
      { to: '/', icon: LayoutDashboard, label: 'Dashboard', exact: true },
    ]
  },
  {
    label: 'Operações',
    items: [
      { to: '/pdv', icon: ShoppingCart, label: 'PDV / Balcão' },
      { to: '/estoque', icon: Package, label: 'Estoque' },
      { to: '/clientes', icon: Wrench, label: 'Clientes' },
    ]
  },
  {
    label: 'Fiscal',
    items: [
      { to: '/notas-fiscais', icon: FileText, label: 'Notas Fiscais' },
    ]
  },
  {
    label: 'Financeiro',
    items: [
      { to: '/financeiro', icon: DollarSign, label: 'Financeiro' },
    ]
  },
  {
    label: 'Sistema',
    items: [
      { to: '/configuracoes', icon: Settings, label: 'Configurações' },
    ]
  }
];

function PageTitle() {
  const loc = useLocation();
  const map: Record<string, string> = {
    '/': 'Dashboard',
    '/pdv': 'PDV — Ponto de Venda',
    '/estoque': 'Estoque',
    '/clientes': 'Clientes',
    '/notas-fiscais': 'Notas Fiscais',
    '/financeiro': 'Financeiro',
    '/configuracoes': 'Configurações',
  };
  return <>{map[loc.pathname] ?? 'ERP Auto Peças'}</>;
}

function ProtectedRoute({ children }: { children: React.ReactNode }) {
  const { isActivated, token, loading } = useAuth();
  const location = useLocation();

  if (loading) return <div style={{ minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', background: '#0f172a', color: '#fff' }}>Carregando...</div>;
  if (!isActivated) return <Navigate to="/ativacao" replace state={{ from: location }} />;
  if (!token) return <Navigate to="/login" replace state={{ from: location }} />;
  
  return <>{children}</>;
}

function MainAppLayout() {
  const { logout, user } = useAuth();
  
  return (
    <div className="app-layout">
      {/* Sidebar */}
      <aside className="sidebar">
        <div className="sidebar-logo">
          <h1>🔧 Auto<span>Peças</span></h1>
          <p>Sistema de Gestão ERP</p>
        </div>

        <nav className="sidebar-nav">
          {navGroups.map(g => (
            <div className="nav-section" key={g.label}>
              <div className="nav-section-label">{g.label}</div>
              {g.items.map(item => (
                <NavLink
                  key={item.to}
                  to={item.to}
                  end={item.to === '/'}
                  className={({ isActive }) => `nav-item ${isActive ? 'active' : ''}`}
                >
                  <item.icon size={16} />
                  {item.label}
                  <ChevronRight size={12} style={{ marginLeft: 'auto', opacity: .4 }} />
                </NavLink>
              ))}
            </div>
          ))}
        </nav>

        <div className="sidebar-footer">
          <div className="nav-item" style={{ color: '#64748b', cursor: 'pointer' }} onClick={logout}>
            <LogOut size={16} />
            <span style={{ fontSize: 12 }}>Sair ({user?.nome})</span>
          </div>
          <div style={{ textAlign: 'center', marginTop: 12 }}>
            <span style={{ fontSize: 10, color: 'var(--text-muted)' }}>Auto Peças ERP v1.0.1</span>
          </div>
        </div>
      </aside>

      {/* Main */}
      <div className="main-content">
        <header className="header">
          <h2 className="header-title">
            <PageTitle />
          </h2>
          <div className="header-actions">
            <span style={{ fontSize: 12, color: 'var(--text-muted)' }}>
              {new Date().toLocaleDateString('pt-BR', { weekday: 'long', day: '2-digit', month: 'long' })}
            </span>
          </div>
        </header>

        <div className="page-content">
          <Routes>
            <Route path="/" element={<Dashboard />} />
            <Route path="/pdv" element={<PDV />} />
            <Route path="/estoque" element={<Estoque />} />
            <Route path="/clientes" element={<Clientes />} />
            <Route path="/notas-fiscais" element={<NotasFiscais />} />
            <Route path="/financeiro" element={<Financeiro />} />
            <Route path="/configuracoes" element={<Configuracoes />} />
          </Routes>
        </div>
      </div>
    </div>
  );
}

function AppRoutes() {
  const { isActivated, token, loading } = useAuth();
  
  if (loading) return <div style={{ minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', background: '#0f172a', color: '#fff' }}>Carregando...</div>;

  return (
    <Routes>
      <Route path="/ativacao" element={!isActivated ? <Ativacao /> : <Navigate to="/login" replace />} />
      <Route path="/login" element={isActivated && !token ? <Login /> : <Navigate to="/" replace />} />
      <Route path="/*" element={
        <ProtectedRoute>
          <MainAppLayout />
        </ProtectedRoute>
      } />
    </Routes>
  );
}

export default function App() {
  return (
    <QueryClientProvider client={qc}>
      <AuthProvider>
        <BrowserRouter>
          <AppRoutes />
          <Toaster position="top-right" toastOptions={{
            style: { fontFamily: 'Inter, sans-serif', fontSize: '14px' },
            success: { iconTheme: { primary: '#22c55e', secondary: '#fff' } }
          }} />
        </BrowserRouter>
      </AuthProvider>
    </QueryClientProvider>
  );
}
