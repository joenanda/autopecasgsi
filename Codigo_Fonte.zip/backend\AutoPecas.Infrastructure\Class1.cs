﻿namespace AutoPecas.Infrastructure;

public class Class1
{

}
