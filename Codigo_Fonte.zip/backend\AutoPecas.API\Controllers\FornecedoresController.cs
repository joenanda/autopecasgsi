using AutoPecas.Domain.Entities;
using AutoPecas.Infrastructure.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace AutoPecas.API.Controllers;

[ApiController]
[Route("api/[controller]")]
public class FornecedoresController : ControllerBase
{
    private readonly AutoPecasDbContext _db;

    public FornecedoresController(AutoPecasDbContext db)
    {
        _db = db;
    }

    [HttpGet]
    public async Task<IActionResult> ListarTodos()
    {
        var lista = await _db.Fornecedores
            .Where(x => x.Ativo)
            .OrderBy(x => x.RazaoSocial)
            .ToListAsync();
            
        return Ok(lista);
    }
}
