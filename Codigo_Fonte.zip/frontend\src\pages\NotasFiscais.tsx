import { useQuery } from '@tanstack/react-query';
import { FileText, CheckCircle, XCircle, Clock } from 'lucide-react';
import { vendasApi } from '../services/api';

const fmtBRL = (v: number) => Number(v || 0).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });

interface Pedido { id: string; numero: number; tipo: string; status: string; dataPedido: string; valorTotal: number; cliente: string; }
const statusBadge: Record<string, string> = { APROVADO: 'badge-success', FATURADO: 'badge-info', CANCELADO: 'badge-danger', ORCAMENTO: 'badge-warning' };

export default function NotasFiscais() {
  const { data } = useQuery({
    queryKey: ['vendas-nfe'],
    queryFn: () => vendasApi.listar({ status: 'APROVADO', tamanho: 50 }).then(r => r.data),
  });

  const pedidos: Pedido[] = data?.items ?? [];

  return (
    <div>
      <p className="section-title">Notas Fiscais</p>
      <p className="section-subtitle">Emissão de NF-e (Modelo 55) e NFC-e (Modelo 65) — SEFAZ-SP</p>

      <div style={{
        background: 'linear-gradient(135deg, #eff6ff 0%, #dbeafe 100%)',
        border: '1.5px solid #93c5fd', borderRadius: 'var(--radius-lg)',
        padding: '20px 24px', marginBottom: 24
      }}>
        <div style={{ fontSize: 15, fontWeight: 700, color: '#1e40af', marginBottom: 6 }}>
          🔒 Configuração do Certificado Digital
        </div>
        <p style={{ fontSize: 13, color: '#1e40af', lineHeight: 1.6 }}>
          Para emitir NF-e, configure seu certificado digital em <strong>Configurações → Fiscal → Certificado Digital</strong>.
          Suportamos <strong>A1 (arquivo .pfx)</strong> e <strong>A3 (token USB)</strong> via Windows Store (MS-CAPI).
          O sistema está configurado para o ambiente de <strong>Homologação</strong> — altere para Produção quando estiver pronto.
        </p>
      </div>

      <div className="kpi-grid" style={{ gridTemplateColumns: 'repeat(4, 1fr)', marginBottom: 24 }}>
        {[
          { label: 'Autorizadas', value: '0', icon: CheckCircle, color: 'var(--success)' },
          { label: 'Pendentes', value: String(pedidos.length), icon: Clock, color: 'var(--accent)' },
          { label: 'Rejeitadas', value: '0', icon: XCircle, color: 'var(--danger)' },
          { label: 'Canceladas', value: '0', icon: XCircle, color: 'var(--text-muted)' },
        ].map(k => (
          <div className="kpi-card" key={k.label} style={{ '--kpi-color': k.color } as React.CSSProperties}>
            <div className="kpi-label">{k.label}</div>
            <div className="kpi-value">{k.value}</div>
            <div className="kpi-icon"><k.icon /></div>
          </div>
        ))}
      </div>

      <div className="data-table-wrap">
        <div className="table-header">
          <span className="table-title">Vendas Aguardando NF-e</span>
        </div>
        <table className="data-table">
          <thead>
            <tr>
              <th>Nº Pedido</th>
              <th>Cliente</th>
              <th>Tipo</th>
              <th>Data</th>
              <th style={{ textAlign: 'right' }}>Valor Total</th>
              <th>Status</th>
              <th>Ações</th>
            </tr>
          </thead>
          <tbody>
            {pedidos.length === 0 ? (
              <tr><td colSpan={7} style={{ textAlign: 'center', padding: 40, color: 'var(--text-muted)' }}>
                <FileText size={32} style={{ marginBottom: 8, opacity: .4 }} /><br />
                Nenhuma venda pendente de faturamento
              </td></tr>
            ) : pedidos.map(p => (
              <tr key={p.id}>
                <td style={{ fontFamily: 'monospace', fontWeight: 700 }}>#{String(p.numero).padStart(6, '0')}</td>
                <td>{p.cliente || 'Consumidor Final'}</td>
                <td><span className="badge badge-info">{p.tipo}</span></td>
                <td style={{ fontSize: 13 }}>{new Date(p.dataPedido).toLocaleDateString('pt-BR')}</td>
                <td style={{ textAlign: 'right', fontWeight: 700 }}>{fmtBRL(p.valorTotal)}</td>
                <td><span className={`badge ${statusBadge[p.status] ?? 'badge-default'}`}>{p.status}</span></td>
                <td>
                  <div style={{ display: 'flex', gap: 4 }}>
                    <button className="btn btn-primary btn-sm" title="Emitir NF-e">
                      <FileText size={12} /> NF-e
                    </button>
                    <button className="btn btn-outline btn-sm" title="Emitir NFC-e">
                      NFC-e
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div style={{ marginTop: 24, padding: '20px 24px', background: 'var(--bg-surface)', borderRadius: 'var(--radius-lg)', border: '1px solid var(--border)' }}>
        <div style={{ fontSize: 14, fontWeight: 700, marginBottom: 12 }}>🔧 Status da Integração SEFAZ-SP</div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 12 }}>
          {[
            { label: 'Servidor SEFAZ (Homologação)', status: 'configurar' },
            { label: 'Certificado Digital', status: 'configurar' },
            { label: 'Última Sincronização', status: '—' },
          ].map(s => (
            <div key={s.label} style={{ display: 'flex', justifyContent: 'space-between', fontSize: 13 }}>
              <span style={{ color: 'var(--text-secondary)' }}>{s.label}</span>
              <span style={{ fontWeight: 600, color: s.status === 'configurar' ? 'var(--warning)' : 'var(--text-primary)' }}>
                {s.status === 'configurar' ? '⚠ Configurar' : s.status}
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
