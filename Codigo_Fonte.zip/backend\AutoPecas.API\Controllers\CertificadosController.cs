using AutoPecas.Fiscal.Services;
using Microsoft.AspNetCore.Mvc;

namespace AutoPecas.API.Controllers;

/// <summary>
/// Controller de Certificados Digitais — módulo Fiscal.
/// Gerencia certificados A1 (PFX) e A3 (token USB via MS-CAPI).
/// </summary>
[ApiController]
[Route("api/fiscal/[controller]")]
[Produces("application/json")]
public class CertificadosController : ControllerBase
{
    private readonly CertificadoService _certService;
    private readonly ILogger<CertificadosController> _logger;

    public CertificadosController(CertificadoService certService, ILogger<CertificadosController> logger)
    {
        _certService = certService;
        _logger = logger;
    }

    // =========================================================
    //  GET /api/fiscal/certificados/a3/listar
    //  Lista todos os certificados com chave privada no Windows Store
    // =========================================================
    /// <summary>
    /// Lista certificados A3 disponíveis no repositório do Windows (MS-CAPI).
    /// O token USB deve estar conectado para que o certificado apareça.
    /// </summary>
    [HttpGet("a3/listar")]
    [ProducesResponseType<IEnumerable<CertificadoInfo>>(200)]
    public IActionResult ListarCertificadosA3()
    {
        try
        {
            var certificados = _certService.ListarCertificadosA3Disponiveis();
            return Ok(certificados);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Erro ao listar certificados A3 do Windows Store.");
            return StatusCode(500, new { mensagem = "Erro ao acessar o repositório de certificados do Windows.", detalhe = ex.Message });
        }
    }

    // =========================================================
    //  POST /api/fiscal/certificados/a1/validar
    //  Valida um arquivo PFX (A1) enviado via upload
    // =========================================================
    /// <summary>
    /// Recebe um arquivo .pfx e sua senha, valida e retorna as informações do certificado.
    /// Use para verificar o certificado antes de cadastrá-lo no sistema.
    /// </summary>
    [HttpPost("a1/validar")]
    [ProducesResponseType<CertificadoInfo>(200)]
    [ProducesResponseType(400)]
    public async Task<IActionResult> ValidarArquivoPfx(IFormFile arquivo, [FromForm] string senha)
    {
        if (arquivo is null || arquivo.Length == 0)
            return BadRequest(new { mensagem = "Arquivo PFX não enviado." });

        if (string.IsNullOrWhiteSpace(senha))
            return BadRequest(new { mensagem = "Senha do certificado não informada." });

        if (!arquivo.FileName.EndsWith(".pfx", StringComparison.OrdinalIgnoreCase))
            return BadRequest(new { mensagem = "O arquivo deve ter extensão .pfx" });

        using var ms = new MemoryStream();
        await arquivo.CopyToAsync(ms);
        var pfxBytes = ms.ToArray();

        try
        {
            var info = _certService.ValidarArquivoPfx(pfxBytes, senha);
            return Ok(info);
        }
        catch (InvalidOperationException ex)
        {
            return BadRequest(new { mensagem = ex.Message });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Erro inesperado ao validar PFX.");
            return StatusCode(500, new { mensagem = "Erro interno ao processar o certificado." });
        }
    }
}
