import { createContext, useContext, useState, useEffect } from 'react';
import type { ReactNode } from 'react';
import toast from 'react-hot-toast';

interface User {
  id: string;
  nome: string;
  role: string;
}

interface AuthContextData {
  user: User | null;
  token: string | null;
  isActivated: boolean;
  needsAdmin: boolean;
  login: (token: string, user: User) => void;
  logout: () => void;
  checkStatus: () => Promise<void>;
  activate: (token: string, cnpj: string) => Promise<boolean>;
  loading: boolean;
}

const AuthContext = createContext<AuthContextData>({} as AuthContextData);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [token, setToken] = useState<string | null>(null);
  const [isActivated, setIsActivated] = useState<boolean>(true); // assume true ate checar
  const [needsAdmin, setNeedsAdmin] = useState<boolean>(false);
  const [loading, setLoading] = useState<boolean>(true);

  useEffect(() => {
    const savedToken = localStorage.getItem('@ERP:token');
    const savedUser = localStorage.getItem('@ERP:user');

    if (savedToken && savedUser) {
      setToken(savedToken);
      setUser(JSON.parse(savedUser));
    }
    
    checkStatus().finally(() => setLoading(false));
  }, []);

  const checkStatus = async () => {
    try {
      const response = await fetch('http://localhost:5000/api/auth/status');
      if (response.ok) {
        const data = await response.json();
        setIsActivated(data.ativado);
        setNeedsAdmin(data.precisaConfigurarAdmin);
      } else {
        // Se a API não responder corretamente, pode estar fora do ar
      }
    } catch (err) {
      console.error("Erro ao verificar status do sistema");
    }
  };

  const activate = async (activationToken: string, cnpj: string): Promise<boolean> => {
    try {
      const response = await fetch('http://localhost:5000/api/auth/ativar', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ cnpj, token: activationToken })
      });
      
      const data = await response.json();
      
      if (response.ok) {
        toast.success(data.message || 'Sistema ativado com sucesso!');
        await checkStatus();
        return true;
      } else {
        toast.error(data.message || 'Erro ao ativar o sistema.');
        return false;
      }
    } catch {
      toast.error('Erro de conexão ao tentar ativar.');
      return false;
    }
  };

  const login = (jwt: string, userData: User) => {
    localStorage.setItem('@ERP:token', jwt);
    localStorage.setItem('@ERP:user', JSON.stringify(userData));
    setToken(jwt);
    setUser(userData);
  };

  const logout = () => {
    localStorage.removeItem('@ERP:token');
    localStorage.removeItem('@ERP:user');
    setToken(null);
    setUser(null);
  };

  return (
    <AuthContext.Provider value={{ user, token, isActivated, needsAdmin, login, logout, checkStatus, activate, loading }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  return context;
}
