import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Plus, Search, Edit, X, Check, Users, Building2, ExternalLink } from 'lucide-react';
import toast from 'react-hot-toast';
import { clientesApi } from '../services/api';

interface Cliente { id: string; tipoPessoa: string; nomeRazao: string; cpfCnpj?: string; telefone?: string; celular?: string; email?: string; cidade?: string; uf?: string; ativo: boolean; limiteCredito: number; }
const emptyForm = { tipoPessoa: 'F', nomeRazao: '', nomeFantasia: '', cpfCnpj: '', rgIe: '', cep: '', logradouro: '', numero: '', complemento: '', bairro: '', municipio: '', uf: 'SP', telefone: '', celular: '', email: '', limiteCredito: '', contribuinteIcms: false };

export default function Clientes() {
  const qc = useQueryClient();
  const [busca, setBusca] = useState('');
  const [pagina, setPagina] = useState(1);
  const [showModal, setShowModal] = useState(false);
  const [editId, setEditId] = useState<string | null>(null);
  const [form, setForm] = useState<typeof emptyForm>(emptyForm);
  const [buscandoCnpj, setBuscandoCnpj] = useState(false);
  const [buscandoIe, setBuscandoIe] = useState(false);

  const f = (k: keyof typeof emptyForm, v: string | boolean) => setForm(p => ({ ...p, [k]: v }));

  // ── Busca CNPJ via BrasilAPI (Receita Federal) ──────────────
  async function buscarCnpj() {
    if (form.tipoPessoa !== 'J' || !form.cpfCnpj) return;
    const cnpjNum = form.cpfCnpj.replace(/\D/g, '');
    if (cnpjNum.length !== 14) return;

    setBuscandoCnpj(true);
    const toastId = toast.loading('Buscando CNPJ na Receita Federal...');
    try {
      const res = await fetch(`https://brasilapi.com.br/api/cnpj/v1/${cnpjNum}`);
      if (!res.ok) throw new Error();
      const data = await res.json();

      setForm(prev => ({
        ...prev,
        nomeRazao:   data.razao_social   || prev.nomeRazao,
        nomeFantasia: data.nome_fantasia  || prev.nomeFantasia,
        cep:          data.cep            || prev.cep,
        logradouro:   data.logradouro     || prev.logradouro,
        numero:       data.numero         || prev.numero,
        complemento:  data.complemento   || prev.complemento,
        bairro:       data.bairro         || prev.bairro,
        municipio:    data.municipio      || prev.municipio,
        uf:           data.uf             || prev.uf,
        telefone:     data.ddd_telefone_1 || prev.telefone,
      }));
      toast.success('Dados preenchidos com sucesso!', { id: toastId });

      // Após preencher, já tenta buscar a IE automaticamente
      await buscarIePorCnpj(cnpjNum, data.uf || form.uf);
    } catch {
      toast.error('Não foi possível buscar o CNPJ. Verifique o número.', { id: toastId });
    } finally {
      setBuscandoCnpj(false);
    }
  }

  // ── Busca Inscrição Estadual via cnpja.com ──────────────────
  async function buscarIePorCnpj(cnpjNum: string, uf: string) {
    setBuscandoIe(true);
    try {
      const res = await fetch(`https://open.cnpja.com/office/${cnpjNum}`);
      if (!res.ok) return;
      const data = await res.json();

      // Procura o registro do estado da empresa
      const registros: any[] = data.registrations ?? [];
      const reg = registros.find((r: any) =>
        r.state === uf.toUpperCase() && r.enabled !== false
      ) || registros[0];

      if (reg?.number) {
        setForm(prev => ({ ...prev, rgIe: reg.number }));
        toast.success(`IE encontrada: ${reg.number}`, { icon: '🏛️', duration: 4000 });
      }
    } catch {
      // silencioso — IE não é obrigatória
    } finally {
      setBuscandoIe(false);
    }
  }

  // ── Abre o Sintegra manualmente para consulta ───────────────
  function abrirSintegra() {
    const cnpjNum = form.cpfCnpj.replace(/\D/g, '');
    const url = cnpjNum
      ? `https://www.sintegra.gov.br/`
      : 'https://www.sintegra.gov.br/';
    window.open(url, '_blank');
    toast('Sintegra aberto! Use o CNPJ para consultar a IE no site.', { icon: '🔗', duration: 5000 });
  }

  const { data, isLoading } = useQuery({
    queryKey: ['clientes', busca, pagina],
    queryFn: () => clientesApi.listar({ busca, pagina }).then(r => r.data),
    placeholderData: prev => prev,
  });

  const salvarMutation = useMutation({
    mutationFn: (d: unknown) => editId ? clientesApi.atualizar(editId, d) : clientesApi.criar(d),
    onSuccess: () => {
      toast.success(editId ? 'Cliente atualizado!' : 'Cliente cadastrado!');
      qc.invalidateQueries({ queryKey: ['clientes'] });
      setShowModal(false);
    },
    onError: () => toast.error('Erro ao salvar cliente'),
  });

  function openNew() { setEditId(null); setForm(emptyForm); setShowModal(true); }
  function openEdit(c: Cliente) {
    setEditId(c.id);
    setForm({ ...emptyForm, tipoPessoa: c.tipoPessoa, nomeRazao: c.nomeRazao, cpfCnpj: c.cpfCnpj ?? '', telefone: c.telefone ?? '', celular: c.celular ?? '', email: c.email ?? '', municipio: c.cidade ?? '', uf: c.uf ?? 'SP', limiteCredito: String(c.limiteCredito) });
    setShowModal(true);
  }

  const clientes: Cliente[] = data?.items ?? [];

  return (
    <div>
      <div className="flex-between mb-20">
        <div>
          <p className="section-title">Clientes</p>
          <p className="section-subtitle">{data?.total ?? 0} clientes cadastrados</p>
        </div>
        <button className="btn btn-primary" onClick={openNew}><Plus size={15} /> Novo Cliente</button>
      </div>

      <div className="data-table-wrap">
        <div className="table-header">
          <span className="table-title">Clientes</span>
          <div className="search-wrap" style={{ width: 300 }}>
            <Search size={15} />
            <input className="form-control" placeholder="Buscar por nome, CPF, CNPJ..." value={busca} onChange={e => { setBusca(e.target.value); setPagina(1); }} />
          </div>
        </div>
        {isLoading ? (
          <div className="empty-state"><div className="spinner" /></div>
        ) : clientes.length === 0 ? (
          <div className="empty-state"><Users size={40} /><p>Nenhum cliente encontrado</p>
            <button className="btn btn-primary" style={{ marginTop: 12 }} onClick={openNew}><Plus size={14} /> Cadastrar cliente</button></div>
        ) : (
          <table className="data-table">
            <thead><tr><th>Nome / Razão Social</th><th>CPF / CNPJ</th><th>IE</th><th>Telefone</th><th>Cidade/UF</th><th>Ações</th></tr></thead>
            <tbody>
              {clientes.map(c => (
                <tr key={c.id}>
                  <td><div style={{ fontWeight: 600 }}>{c.nomeRazao}</div><div style={{ fontSize: 11, color: 'var(--text-muted)' }}>{c.tipoPessoa === 'J' ? 'Pessoa Jurídica' : 'Pessoa Física'}</div></td>
                  <td style={{ fontFamily: 'monospace', fontSize: 13 }}>{c.cpfCnpj ?? '—'}</td>
                  <td style={{ fontSize: 12, color: 'var(--text-secondary)' }}>{'—'}</td>
                  <td style={{ fontSize: 13 }}>{c.celular ?? c.telefone ?? '—'}</td>
                  <td style={{ fontSize: 13 }}>{c.uf ?? '—'}</td>
                  <td><button className="btn btn-outline btn-sm" onClick={() => openEdit(c)}><Edit size={13} /></button></td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      {showModal && (
        <div className="modal-overlay" onClick={e => { if (e.target === e.currentTarget) setShowModal(false); }}>
          <div className="modal" style={{ maxWidth: 720 }}>
            <div className="modal-header">
              <span className="modal-title">{editId ? 'Editar Cliente' : 'Novo Cliente'}</span>
              <button className="btn btn-outline btn-sm" onClick={() => setShowModal(false)}><X size={14} /></button>
            </div>
            <form onSubmit={e => { e.preventDefault(); salvarMutation.mutate({ ...form, limiteCredito: parseFloat(String(form.limiteCredito)) || 0 }); }}>
              <div className="modal-body">

                {/* Tipo e CNPJ */}
                <div className="form-grid form-grid-2">
                  <div className="form-group"><label className="form-label">Tipo de Pessoa</label>
                    <select className="form-control" value={form.tipoPessoa} onChange={e => f('tipoPessoa', e.target.value)}>
                      <option value="F">Pessoa Física</option>
                      <option value="J">Pessoa Jurídica</option>
                    </select>
                  </div>
                  <div className="form-group">
                    <label className="form-label">
                      {form.tipoPessoa === 'J' ? 'CNPJ' : 'CPF'}
                      {form.tipoPessoa === 'J' && <span style={{ fontSize: 11, color: 'var(--primary)', marginLeft: 6 }}>↑ Digite e saia do campo para buscar</span>}
                    </label>
                    <div style={{ display: 'flex', gap: 6 }}>
                      <input
                        className="form-control"
                        value={form.cpfCnpj}
                        onBlur={buscarCnpj}
                        onChange={e => f('cpfCnpj', e.target.value)}
                        disabled={buscandoCnpj}
                        placeholder={form.tipoPessoa === 'J' ? '00.000.000/0001-00' : '000.000.000-00'}
                        style={{ flex: 1 }}
                      />
                      {(buscandoCnpj || buscandoIe) && <div className="spinner" style={{ marginTop: 8 }} />}
                    </div>
                  </div>
                </div>

                {/* Nome e IE */}
                <div className="form-grid form-grid-2">
                  <div className="form-group"><label className="form-label">Nome / Razão Social *</label>
                    <input className="form-control" required value={form.nomeRazao} onChange={e => f('nomeRazao', e.target.value)} />
                  </div>
                  <div className="form-group">
                    <label className="form-label" style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                      <span>Inscrição Estadual (IE)</span>
                      {form.tipoPessoa === 'J' && (
                        <button type="button" className="btn btn-outline btn-sm" style={{ padding: '2px 8px', fontSize: 11 }} onClick={abrirSintegra}>
                          <ExternalLink size={11} /> Sintegra
                        </button>
                      )}
                    </label>
                    <input
                      className="form-control"
                      value={form.rgIe}
                      onChange={e => f('rgIe', e.target.value)}
                      placeholder={buscandoIe ? 'Buscando IE...' : form.tipoPessoa === 'J' ? 'Auto-preenchida ou manual' : 'RG'}
                      disabled={buscandoIe}
                    />
                  </div>
                </div>

                {/* Nome Fantasia */}
                {form.tipoPessoa === 'J' && (
                  <div className="form-group">
                    <label className="form-label">Nome Fantasia</label>
                    <input className="form-control" value={form.nomeFantasia} onChange={e => f('nomeFantasia', e.target.value)} />
                  </div>
                )}

                {/* Contatos */}
                <div className="form-grid form-grid-3">
                  <div className="form-group"><label className="form-label">Telefone</label>
                    <input className="form-control" value={form.telefone} onChange={e => f('telefone', e.target.value)} /></div>
                  <div className="form-group"><label className="form-label">Celular / WhatsApp</label>
                    <input className="form-control" value={form.celular} onChange={e => f('celular', e.target.value)} /></div>
                  <div className="form-group"><label className="form-label">E-mail</label>
                    <input className="form-control" type="email" value={form.email} onChange={e => f('email', e.target.value)} /></div>
                </div>

                {/* Endereço */}
                <div style={{ background: 'var(--bg-base)', padding: '12px 16px', borderRadius: 'var(--radius)', marginBottom: 16 }}>
                  <div style={{ fontSize: 12, fontWeight: 700, color: 'var(--text-secondary)', marginBottom: 12, textTransform: 'uppercase' }}>📍 Endereço</div>
                  <div className="form-grid form-grid-3">
                    <div className="form-group" style={{ margin: 0 }}><label className="form-label">CEP</label>
                      <input className="form-control" value={form.cep} onChange={e => f('cep', e.target.value)} /></div>
                    <div className="form-group" style={{ margin: 0, gridColumn: '2/4' }}><label className="form-label">Logradouro</label>
                      <input className="form-control" value={form.logradouro} onChange={e => f('logradouro', e.target.value)} /></div>
                    <div className="form-group" style={{ margin: 0 }}><label className="form-label">Número</label>
                      <input className="form-control" value={form.numero} onChange={e => f('numero', e.target.value)} /></div>
                    <div className="form-group" style={{ margin: 0 }}><label className="form-label">Bairro</label>
                      <input className="form-control" value={form.bairro} onChange={e => f('bairro', e.target.value)} /></div>
                    <div className="form-group" style={{ margin: 0 }}><label className="form-label">Município</label>
                      <input className="form-control" value={form.municipio} onChange={e => f('municipio', e.target.value)} /></div>
                  </div>
                </div>

                {/* Fiscal */}
                <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
                  <input type="checkbox" id="contribuinte" checked={form.contribuinteIcms} onChange={e => f('contribuinteIcms', e.target.checked)} />
                  <label htmlFor="contribuinte" style={{ fontSize: 13, cursor: 'pointer' }}><Building2 size={13} style={{ verticalAlign: 'middle', marginRight: 4 }} />Contribuinte de ICMS</label>
                  <div style={{ marginLeft: 'auto' }}>
                    <label className="form-label" style={{ fontSize: 11, marginBottom: 2 }}>Limite de Crédito (R$)</label>
                    <input className="form-control" type="number" step="0.01" min="0" value={form.limiteCredito} onChange={e => f('limiteCredito', e.target.value)} style={{ width: 140 }} />
                  </div>
                </div>

              </div>
              <div className="modal-footer">
                <button type="button" className="btn btn-outline" onClick={() => setShowModal(false)}>Cancelar</button>
                <button type="submit" className="btn btn-primary" disabled={salvarMutation.isPending}>
                  {salvarMutation.isPending ? <div className="spinner" /> : <><Check size={14} /> Salvar Cliente</>}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
