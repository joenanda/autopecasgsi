import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Plus, TrendingUp, TrendingDown, DollarSign, Check, X } from 'lucide-react';
import toast from 'react-hot-toast';
import { financeiroApi } from '../services/api';

const fmtBRL = (v: number) => Number(v || 0).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
const fmtData = (d: string) => d ? new Date(d + 'T00:00:00').toLocaleDateString('pt-BR') : '—';

interface ContaReceber { id: string; descricao: string; clienteNome?: string; valorOriginal: number; saldo: number; dataVencimento: string; status: string; formaPagamento?: string; }
interface ContaPagar   { id: string; descricao: string; fornecedorNome?: string; valorOriginal: number; saldo: number; dataVencimento: string; status: string; numeroDocumento?: string; }

const statusBadge: Record<string, string> = { ABERTO: 'badge-warning', PARCIAL: 'badge-info', PAGO: 'badge-success', CANCELADO: 'badge-default', VENCIDO: 'badge-danger' };

export default function Financeiro() {
  const qc = useQueryClient();
  const [aba, setAba] = useState<'receber' | 'pagar' | 'caixa'>('receber');
  const [showReceber, setShowReceber] = useState<string | null>(null);
  const [showPagar, setShowPagar] = useState<string | null>(null);
  const [showNovaPagar, setShowNovaPagar] = useState(false);
  const [valorPago, setValorPago] = useState('');
  const [novaPagar, setNovaPagar] = useState({ descricao: '', valorOriginal: '', dataVencimento: '', numeroDocumento: '' });

  const { data: resumo } = useQuery({ queryKey: ['fin-resumo'], queryFn: () => financeiroApi.resumo().then(r => r.data) });
  const { data: receber } = useQuery({ queryKey: ['receber'], queryFn: () => financeiroApi.receber().then(r => r.data) });
  const { data: pagar }   = useQuery({ queryKey: ['pagar'],   queryFn: () => financeiroApi.pagar().then(r => r.data) });
  const { data: caixa }   = useQuery({ queryKey: ['caixa'],   queryFn: () => financeiroApi.saldoCaixa().then(r => r.data) });

  const receberMutation = useMutation({
    mutationFn: ({ id, valor }: { id: string; valor: number }) =>
      financeiroApi.receberPagamento(id, { valorPago: valor, desconto: 0, juros: 0, multa: 0, formaPagamento: 'DINHEIRO' }),
    onSuccess: () => { toast.success('Pagamento registrado!'); qc.invalidateQueries({ queryKey: ['receber'] }); qc.invalidateQueries({ queryKey: ['caixa'] }); setShowReceber(null); },
    onError: () => toast.error('Erro ao registrar pagamento'),
  });

  const pagarMutation = useMutation({
    mutationFn: ({ id, valor }: { id: string; valor: number }) =>
      financeiroApi.pagarConta(id, { valorPago: valor, desconto: 0, juros: 0, multa: 0, formaPagamento: 'DINHEIRO' }),
    onSuccess: () => { toast.success('Pagamento efetuado!'); qc.invalidateQueries({ queryKey: ['pagar'] }); qc.invalidateQueries({ queryKey: ['caixa'] }); setShowPagar(null); },
    onError: () => toast.error('Erro ao pagar conta'),
  });

  const novaPagarMutation = useMutation({
    mutationFn: (d: unknown) => financeiroApi.criarContaPagar(d),
    onSuccess: () => { toast.success('Conta a pagar cadastrada!'); qc.invalidateQueries({ queryKey: ['pagar'] }); setShowNovaPagar(false); },
    onError: () => toast.error('Erro ao salvar conta'),
  });

  const contasReceber: ContaReceber[] = receber?.items ?? [];
  const contasPagar:   ContaPagar[]   = pagar?.items   ?? [];

  return (
    <div>
      <p className="section-title">Financeiro</p>
      <p className="section-subtitle">Controle de contas, caixa e fluxo de caixa</p>

      {/* Resumo */}
      <div className="kpi-grid" style={{ gridTemplateColumns: 'repeat(3, 1fr)', marginBottom: 24 }}>
        <div className="kpi-card" style={{ '--kpi-color': 'var(--success)' } as React.CSSProperties}>
          <div className="kpi-label">A Receber</div>
          <div className="kpi-value">{fmtBRL(resumo?.totalReceber ?? 0)}</div>
          <div className="kpi-sub">{resumo?.vencendoReceber ?? 0} vencem em 7 dias</div>
          <div className="kpi-icon"><TrendingUp /></div>
        </div>
        <div className="kpi-card" style={{ '--kpi-color': 'var(--danger)' } as React.CSSProperties}>
          <div className="kpi-label">A Pagar</div>
          <div className="kpi-value">{fmtBRL(resumo?.totalPagar ?? 0)}</div>
          <div className="kpi-sub">{resumo?.vencendoPagar ?? 0} vencem em 7 dias</div>
          <div className="kpi-icon"><TrendingDown /></div>
        </div>
        <div className="kpi-card" style={{ '--kpi-color': 'var(--primary)' } as React.CSSProperties}>
          <div className="kpi-label">Saldo em Caixa</div>
          <div className="kpi-value">{fmtBRL(resumo?.saldoCaixa ?? 0)}</div>
          <div className="kpi-sub">Líquido: {fmtBRL(resumo?.saldoLiquido ?? 0)}</div>
          <div className="kpi-icon"><DollarSign /></div>
        </div>
      </div>

      {/* Abas */}
      <div style={{ display: 'flex', gap: 4, marginBottom: 16, background: 'var(--bg-surface)', padding: 4, borderRadius: 'var(--radius)', border: '1px solid var(--border)', width: 'fit-content' }}>
        {(['receber', 'pagar', 'caixa'] as const).map(t => (
          <button key={t} className={`btn btn-sm ${aba === t ? 'btn-primary' : 'btn-outline'}`} style={{ border: 'none' }} onClick={() => setAba(t)}>
            {t === 'receber' ? '💰 A Receber' : t === 'pagar' ? '💳 A Pagar' : '🏦 Caixa'}
          </button>
        ))}
      </div>

      {/* A Receber */}
      {aba === 'receber' && (
        <div className="data-table-wrap">
          <div className="table-header"><span className="table-title">Contas a Receber</span></div>
          <table className="data-table">
            <thead><tr><th>Descrição / Cliente</th><th style={{ textAlign: 'right' }}>Valor</th><th style={{ textAlign: 'right' }}>Saldo</th><th>Vencimento</th><th>Status</th><th>Ação</th></tr></thead>
            <tbody>
              {contasReceber.length === 0 ? (
                <tr><td colSpan={6} style={{ textAlign: 'center', padding: 40, color: 'var(--text-muted)' }}>Nenhuma conta a receber</td></tr>
              ) : contasReceber.map(c => (
                <tr key={c.id}>
                  <td><div style={{ fontWeight: 500 }}>{c.descricao}</div>{c.clienteNome && <div style={{ fontSize: 11, color: 'var(--text-muted)' }}>{c.clienteNome}</div>}</td>
                  <td style={{ textAlign: 'right' }}>{fmtBRL(c.valorOriginal)}</td>
                  <td style={{ textAlign: 'right', fontWeight: 700 }}>{fmtBRL(c.saldo)}</td>
                  <td>{fmtData(c.dataVencimento)}</td>
                  <td><span className={`badge ${statusBadge[c.status] ?? 'badge-default'}`}>{c.status}</span></td>
                  <td>{c.status !== 'PAGO' && c.status !== 'CANCELADO' && (
                    <button className="btn btn-success btn-sm" onClick={() => { setShowReceber(c.id); setValorPago(String(c.saldo)); }}>
                      <Check size={12} /> Receber
                    </button>
                  )}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* A Pagar */}
      {aba === 'pagar' && (
        <div className="data-table-wrap">
          <div className="table-header">
            <span className="table-title">Contas a Pagar</span>
            <button className="btn btn-primary btn-sm" onClick={() => setShowNovaPagar(true)}><Plus size={14} /> Nova Conta</button>
          </div>
          <table className="data-table">
            <thead><tr><th>Descrição</th><th>Documento</th><th style={{ textAlign: 'right' }}>Valor</th><th>Vencimento</th><th>Status</th><th>Ação</th></tr></thead>
            <tbody>
              {contasPagar.length === 0 ? (
                <tr><td colSpan={6} style={{ textAlign: 'center', padding: 40, color: 'var(--text-muted)' }}>Nenhuma conta a pagar</td></tr>
              ) : contasPagar.map(c => (
                <tr key={c.id}>
                  <td style={{ fontWeight: 500 }}>{c.descricao}</td>
                  <td style={{ fontSize: 12 }}>{c.numeroDocumento ?? '—'}</td>
                  <td style={{ textAlign: 'right', fontWeight: 700 }}>{fmtBRL(c.saldo)}</td>
                  <td>{fmtData(c.dataVencimento)}</td>
                  <td><span className={`badge ${statusBadge[c.status] ?? 'badge-default'}`}>{c.status}</span></td>
                  <td>{c.status !== 'PAGO' && (
                    <button className="btn btn-danger btn-sm" onClick={() => { setShowPagar(c.id); setValorPago(String(c.saldo)); }}>
                      <DollarSign size={12} /> Pagar
                    </button>
                  )}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* Caixa */}
      {aba === 'caixa' && (
        <div style={{ display: 'grid', gap: 16 }}>
          {(caixa?.caixas ?? []).map((c: { id: string; nome: string; tipo: string; saldoAtual: number }) => (
            <div key={c.id} className="kpi-card" style={{ '--kpi-color': 'var(--primary)' } as React.CSSProperties}>
              <div className="kpi-label">{c.tipo} — {c.nome}</div>
              <div className="kpi-value">{fmtBRL(c.saldoAtual)}</div>
            </div>
          ))}
          <div className="data-table-wrap">
            <div className="table-header"><span className="table-title">Últimos Movimentos Hoje</span></div>
            <table className="data-table">
              <thead><tr><th>Descrição</th><th>Tipo</th><th style={{ textAlign: 'right' }}>Valor</th><th style={{ textAlign: 'right' }}>Saldo Após</th></tr></thead>
              <tbody>
                {(caixa?.movimentos ?? []).length === 0 ? (
                  <tr><td colSpan={4} style={{ textAlign: 'center', padding: 30, color: 'var(--text-muted)' }}>Sem movimentos hoje</td></tr>
                ) : (caixa?.movimentos ?? []).map((m: { id: string; descricao: string; tipo: string; valor: number; saldoPosterior: number }) => (
                  <tr key={m.id}>
                    <td>{m.descricao}</td>
                    <td><span className={`badge ${m.tipo === 'E' ? 'badge-success' : 'badge-danger'}`}>{m.tipo === 'E' ? 'Entrada' : 'Saída'}</span></td>
                    <td style={{ textAlign: 'right', color: m.tipo === 'E' ? 'var(--success)' : 'var(--danger)', fontWeight: 700 }}>{fmtBRL(m.valor)}</td>
                    <td style={{ textAlign: 'right' }}>{fmtBRL(m.saldoPosterior)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Modal Receber */}
      {showReceber && (
        <div className="modal-overlay">
          <div className="modal" style={{ maxWidth: 400 }}>
            <div className="modal-header"><span className="modal-title">Registrar Recebimento</span><button className="btn btn-outline btn-sm" onClick={() => setShowReceber(null)}><X size={14} /></button></div>
            <div className="modal-body">
              <div className="form-group"><label className="form-label">Valor Recebido</label>
                <input className="form-control" type="number" step="0.01" value={valorPago} onChange={e => setValorPago(e.target.value)} autoFocus /></div>
            </div>
            <div className="modal-footer">
              <button className="btn btn-outline" onClick={() => setShowReceber(null)}>Cancelar</button>
              <button className="btn btn-success" disabled={receberMutation.isPending} onClick={() => receberMutation.mutate({ id: showReceber, valor: parseFloat(valorPago) || 0 })}>
                {receberMutation.isPending ? <div className="spinner" /> : <><Check size={14} /> Confirmar</>}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Modal Pagar */}
      {showPagar && (
        <div className="modal-overlay">
          <div className="modal" style={{ maxWidth: 400 }}>
            <div className="modal-header"><span className="modal-title">Efetuar Pagamento</span><button className="btn btn-outline btn-sm" onClick={() => setShowPagar(null)}><X size={14} /></button></div>
            <div className="modal-body">
              <div className="form-group"><label className="form-label">Valor Pago</label>
                <input className="form-control" type="number" step="0.01" value={valorPago} onChange={e => setValorPago(e.target.value)} autoFocus /></div>
            </div>
            <div className="modal-footer">
              <button className="btn btn-outline" onClick={() => setShowPagar(null)}>Cancelar</button>
              <button className="btn btn-danger" disabled={pagarMutation.isPending} onClick={() => pagarMutation.mutate({ id: showPagar, valor: parseFloat(valorPago) || 0 })}>
                {pagarMutation.isPending ? <div className="spinner" /> : <><DollarSign size={14} /> Pagar</>}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Modal Nova Conta a Pagar */}
      {showNovaPagar && (
        <div className="modal-overlay">
          <div className="modal" style={{ maxWidth: 500 }}>
            <div className="modal-header"><span className="modal-title">Nova Conta a Pagar</span><button className="btn btn-outline btn-sm" onClick={() => setShowNovaPagar(false)}><X size={14} /></button></div>
            <form onSubmit={e => { e.preventDefault(); novaPagarMutation.mutate({ ...novaPagar, valorOriginal: parseFloat(novaPagar.valorOriginal) || 0 }); }}>
              <div className="modal-body">
                <div className="form-group"><label className="form-label">Descrição *</label><input className="form-control" required value={novaPagar.descricao} onChange={e => setNovaPagar(p => ({ ...p, descricao: e.target.value }))} /></div>
                <div className="form-grid form-grid-2">
                  <div className="form-group"><label className="form-label">Valor *</label><input className="form-control" type="number" step="0.01" required value={novaPagar.valorOriginal} onChange={e => setNovaPagar(p => ({ ...p, valorOriginal: e.target.value }))} /></div>
                  <div className="form-group"><label className="form-label">Vencimento *</label><input className="form-control" type="date" required value={novaPagar.dataVencimento} onChange={e => setNovaPagar(p => ({ ...p, dataVencimento: e.target.value }))} /></div>
                  <div className="form-group"><label className="form-label">N° Documento</label><input className="form-control" value={novaPagar.numeroDocumento} onChange={e => setNovaPagar(p => ({ ...p, numeroDocumento: e.target.value }))} /></div>
                </div>
              </div>
              <div className="modal-footer">
                <button type="button" className="btn btn-outline" onClick={() => setShowNovaPagar(false)}>Cancelar</button>
                <button type="submit" className="btn btn-primary" disabled={novaPagarMutation.isPending}>{novaPagarMutation.isPending ? <div className="spinner" /> : <><Check size={14} /> Salvar</>}</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
