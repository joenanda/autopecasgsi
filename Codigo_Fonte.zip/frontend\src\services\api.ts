import axios from 'axios';

const api = axios.create({
  baseURL: 'http://localhost:5000',
  headers: { 'Content-Type': 'application/json' },
});

// ---- Produtos ----
export const produtosApi = {
  listar: (params?: Record<string, string | number | boolean>) => api.get('/api/produtos', { params }),
  buscarPorCodigo: (codigo: string) => api.get(`/api/produtos/buscar-por-codigo`, { params: { codigo } }),
  obter: (id: string) => api.get(`/api/produtos/${id}`),
  criar: (data: unknown) => api.post('/api/produtos', data),
  atualizar: (id: string, data: unknown) => api.put(`/api/produtos/${id}`, data),
  inativar: (id: string) => api.delete(`/api/produtos/${id}`),
  importarXml: (file: File) => {
    const formData = new FormData();
    formData.append('arquivo', file);
    return api.post('/api/produtos/importar-xml', formData, {
      headers: { 'Content-Type': 'multipart/form-data' }
    });
  },
  importarCsv: (file: File) => {
    const formData = new FormData();
    formData.append('arquivo', file);
    return api.post('/api/produtos/importar-csv', formData, {
      headers: { 'Content-Type': 'multipart/form-data' }
    });
  },
};

// ---- Categorias ----
export const categoriasApi = {
  listar: () => api.get('/api/categorias'),
};

// ---- Clientes ----
export const clientesApi = {
  listar: (params?: Record<string, string | number>) => api.get('/api/clientes', { params }),
  obter: (id: string) => api.get(`/api/clientes/${id}`),
  criar: (data: unknown) => api.post('/api/clientes', data),
  atualizar: (id: string, data: unknown) => api.put(`/api/clientes/${id}`, data),
};

// ---- Vendas ----
export const vendasApi = {
  listar: (params?: Record<string, string | number>) => api.get('/api/vendas', { params }),
  obter: (id: string) => api.get(`/api/vendas/${id}`),
  criar: (data: unknown) => api.post('/api/vendas', data),
  cancelar: (id: string, motivo: string) => api.post(`/api/vendas/${id}/cancelar`, { motivo }),
  dashboard: () => api.get('/api/vendas/dashboard'),
};

// ---- Financeiro ----
export const financeiroApi = {
  resumo: () => api.get('/api/financeiro/resumo'),
  saldoCaixa: () => api.get('/api/financeiro/caixa/saldo'),
  receber: (params?: Record<string, string>) => api.get('/api/financeiro/receber', { params }),
  pagar: (params?: Record<string, string>) => api.get('/api/financeiro/pagar', { params }),
  receberPagamento: (id: string, data: unknown) => api.post(`/api/financeiro/receber/${id}/receber`, data),
  pagarConta: (id: string, data: unknown) => api.post(`/api/financeiro/pagar/${id}/pagar`, data),
  criarContaPagar: (data: unknown) => api.post('/api/financeiro/pagar', data),
};

// ---- Fiscal ----
export const fiscalApi = {
  listarCertificadosA3: () => api.get('/api/fiscal/certificados/a3/listar'),
};

export default api;
